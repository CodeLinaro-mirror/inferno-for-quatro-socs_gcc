/* B-84263 missing file*/

#define XAPBINUTILS_VERSION "1.2.0a"
#define XAPBINUTILS_DATE "2010-06-23"
