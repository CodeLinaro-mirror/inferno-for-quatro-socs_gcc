# This shell script emits a C file. -*- C -*-
#   Copyright 2003 Free Software Foundation, Inc.
#   This file has been modified by Cambridge Consultants Limited

#
# This file is part of GLD, the Gnu Linker.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#

# This file is sourced from elf32.em, and defines extra xap4-elf
# specific routines.
#
# Define some shell vars to insert bits of code into the standard elf
# parse_args and list_options functions.
#
cat >>e${EMULATION_NAME}.c <<EOF

/* Flag for the emulation-specific "--no-relax" option.  */
static bfd_boolean disable_relaxation = FALSE;

static void
elf_xap2_before_allocation (void)
{
    gld${EMULATION_NAME}_before_allocation ();  
  /* Enable relaxation by default if the "--no-relax" option was not
     specified. */

  if (!disable_relaxation)
    command_line.relax = TRUE;
 
}

EOF

# Define some shell vars to insert bits of code into the standard elf
# parse_args and list_options functions.
#
PARSE_AND_LIST_PROLOGUE='
#define OPTION_NO_RELAX			301
'

PARSE_AND_LIST_LONGOPTS='
  { "no-relax", no_argument, NULL, OPTION_NO_RELAX},
'

PARSE_AND_LIST_OPTIONS='
  fprintf (file, _("  --no-relax\t\tDo not perform link-time instruction relaxation\n"));
'

PARSE_AND_LIST_ARGS_CASES='
    case OPTION_NO_RELAX:
      disable_relaxation = TRUE;
      break;
'

LDEMUL_BEFORE_ALLOCATION=elf_xap2_before_allocation