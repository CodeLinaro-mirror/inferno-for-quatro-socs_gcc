SCRIPT_NAME=xap2
OUTPUT_FORMAT="elf32-xap2"
TEXT_START_ADDR=0
MAXPAGESIZE=0x1000
NONPAGED_TEXT_START_ADDR=0x1000
ARCH=xap2
TEMPLATE_NAME=elf32
EXTRA_EM_FILE=xap2elf
EMBEDDED=yes

# AM: ld/genscripts.sh says:
#   ld/genscripts.sh:# To force a logically empty LIB_PATH, do LIBPATH=":".
# This seems to be a misspelling (and works on binutils-2.15 (buggy on 2.9.1))

LIB_PATH=":"

# AM: the next few lines take a lead from the ld/emulparams/mn10200.sh
# although the exact details differ:
# AM: Do we really still need them?
# SSC: left in for when we support C++ on the XAP2 (!)

CTOR_START='_CTOR_LIST = .;'
CTOR_END='_CTOR_END = .;'
DTOR_START='_DTOR_LIST = .;'
DTOR_END='LONG(0);'
