/* Table of opcodes for the Cambridge Consultants XAP2.
   Modelled-on: opcodes/sparc-opc.c
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

This file is part of the BFD library.

BFD is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2, or (at your option) any later
version.

BFD is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this software; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.	*/

#include <stdio.h>
#include <stdlib.h>
#include "ansidecl.h"
#include "opcode/xap2.h"

/* general registers */
const char *xap2_genregs[4] =
{
    "ah", "al", "x", "y"
};

/* for the disassembler */
const char *xap2_flagnames[16] =
{
    "z",  "n",  "s",  "c",  "u",  "i",  "b",  "t",
};

/* [SSC] Probably redundant for XAP2 */
/* Length in bits of the immediate */
/* verify0 and verify1 may be null. If not, then they are set to represent any restrictions
   on the immediate value (eg verify0 = 3 means bits 0 and 1 must be 1.)*/
extern int xap2_get_immediate_length(enum xap_arg_location location, int* verify0 ATTRIBUTE_UNUSED, int* verify1 ATTRIBUTE_UNUSED)
{

    switch (location)
    {
    case OpIMM1:    		   return 8;
    case OpIMM2_OpIMM1: 	   return 16;
    case OpIMM3_OpIMM2_OpIMM1: return 24;
    case OpIMMX:               return 4;
    
    default:
        /*invalid location*/
        fprintf (stderr, "Internal error: invalid argument location [length] %d", location);
        fflush(stdout);
        fflush(stderr);
        abort();
    }

}

/* Inserts a value into an instruction in the indicated location */
/* Returns false if the location code is not understood */
extern bfd_boolean put_value_in_insn(unsigned long long *pinsn, unsigned long long value, enum xap_arg_location location)
{
  unsigned long long opcode = *pinsn;
  unsigned long long imm[3];
    
  /* If the immediate is has to be split over one or more prefix     */
  /* instructions, calculate the value going in each instruction.    */
  /* Each bit of immediate is sign-extended into the shift register; */
  /* this bit of code runs it backwards.                             */
	
  if(location == OpIMM3_OpIMM2_OpIMM1 ||
     location == OpIMM2_OpIMM1)
    {
      int sr = value;
      imm[0] = sr & 0xff;
        
      sr = (sr - SEXT(imm[0], 8)) >> 8;
      imm[1] = sr & 0xff;
        
      sr = (sr - SEXT(imm[1], 8)) >> 8;
      imm[2] = sr & 0xff;
    }
  else
    {
      /* supress warnings about uninitialised variables (these are only    */
      /* actually used in the cases where they are set above, but the      */
      /* compiler can't figure this out which causes problems with -Werror */
      imm[0] = 0;
      imm[1] = 0;
      imm[2] = 0;
    }
    
  /* Where goes this argument go? */
  switch (location)
    {
    case OpREG:
      opcode |= XAP2_MKREG(value);
      break;
        
    case OpREGX:
      opcode |= XAP2_MKREGX(value);
      break;
        
    case OpIMM1:
      opcode |= XAP2_MKOPIMM1(value);
      break;
	
    case OpIMM2_OpIMM1:
      opcode |= XAP2_MKOPIMM2(imm[1]) | XAP2_MKOPIMM1(imm[0]);
      break;
		
    case OpIMM3_OpIMM2_OpIMM1:
      opcode |= XAP2_MKOPIMM3(imm[2]) | XAP2_MKOPIMM2(imm[1]) | XAP2_MKOPIMM1(imm[0]);
      break;

    case OpIMMX:
      opcode |= XAP2_MKOPIMMX(value);
      break;
		
    default:
      /*invalid location*/
      fprintf (stderr, "Internal error: invalid argument location [put_into_insn] %d", location);
      fflush(stdout);
      fflush(stderr);
      abort();
    }

  *pinsn = opcode;
  return TRUE;
}

/* Extracts a value from an instruction at the indicated location */
extern unsigned long long get_value_from_insn(unsigned long long opcode, enum xap_arg_location location)
{
    long val = -1;
    
    /* Where goes is this argument from? */
    switch (location)
    {
    case OpREG:
        val = XAP2_REG(opcode);
        break;
        
    case OpREGX:
    	val = XAP2_REGX(opcode);
        break;
        
    case OpIMM1:
        val = SEXT(XAP2_OPIMM1(opcode), 8);
        break;
        
    case OpIMM2_OpIMM1:
        val = (SEXT(XAP2_OPIMM2(opcode), 8) << 8) +
              (SEXT(XAP2_OPIMM1(opcode), 8));
        break;
    case OpIMM3_OpIMM2_OpIMM1:
        val = (SEXT(XAP2_OPIMM3(opcode), 8) << 16) +
        	  (SEXT(XAP2_OPIMM2(opcode), 8) << 8)  +
        	  (SEXT(XAP2_OPIMM1(opcode), 8));
        break;
    
    case OpIMMX:
    	val = XAP2_OPIMMX(opcode);
        break;
    	
    default:
        /*invalid location*/
        fprintf (stderr, "Internal error: invalid argument location [get_from_insn] %d", location);
        fflush(stdout);
        fflush(stderr);
        abort();
    }

    return val;
}

/* Attempts to relax a fixed-up instruction */
unsigned int xap2_tryrelax(unsigned long long *pinsn, unsigned int orig_size)
{
	int i;
	unsigned short words[3] = { (unsigned short) *pinsn & 0xffff,           /* lo word */
					            (unsigned short)(*pinsn >> 16) & 0xffff,
					            (unsigned short)(*pinsn >> 32) & 0xffff };  /* ho word */
					            
	if(!( (orig_size == 2) || (orig_size == 4) || (orig_size == 6) ))
	{
		fprintf(stderr, "Internal error: invalid size [xap2_tryrelax]\n");
		fflush(stdout);
		fflush(stderr);
		abort();
	}
	
	if(orig_size == 2) /* can't relax! */
		return 2;
	
	/* Unsigned arithmetic instructions are formed of a modifier word (0x0009)
	   followed optionally by a prefix word then the instruction word.  We can
	   eliminate the prefix word if it carries no information*/
	if(orig_size == 6 && words[2] == 0x0009)
	{
		if(words[1] == 0)
		{
			*pinsn = 0x90000 | words[0];
			return 4;
		}
		else
			return 6;
	}
	
	/* For all other instructions, go through from highest- to lowest-order word
	   and see if they can be removed */
	   
	for(i = (orig_size / 2) - 1; i > 0; i--)
	{
		if(words[i] == 0)
		{
			words[i] = 0;
			orig_size -= 2;
		}
		else
			break;
	}
	
	*pinsn = (unsigned long long) words[2] << 32 |
		     (unsigned long long) words[1] << 16  |
		     (unsigned long long) words[0];

	return orig_size;
}
