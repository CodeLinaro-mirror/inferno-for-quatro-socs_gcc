/* Disassemble Cambridge Consultants XAP2 instructions.
   Modelled-on: opcodes/sparc-dis.c
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */


#include <stdio.h>

#include "ansidecl.h"
#include "sysdep.h"
#include "opcode/xap2.h"
#include "dis-asm.h"
#include "libiberty.h"
#include "elf-bfd.h"
#include "elf/xap2.h"

#include <inttypes.h>

/* The sorted opcode table.  */
static const struct xap2_opcode **sorted_opcodes;

/* For faster lookup, after insns are sorted they are hashed.  */
/* ??? I think there is room for even more improvement.  */
/* FIXME: [AM] not clear that a hash table is even useful any more.     */
#define HASH_SIZE 256

/* [AM] take care here: 16-bit compact instructions are spotted earlier */
/* (see the call to xap2_16to32) *if* they're allowed.  If they're not  */
/* then the length-bit is treated as just an opcode extension bit.      */
#define HASH_INSN(INSN) \
  /* (XAP2_PRI(INSN)== 63 ? (XAP2_SEC(INSN) | 128) : XAP2_PRI(INSN)) */ \
  /* XAP2_OP(INSN) */ \
  INSN & 0xf0

struct opcode_hash {
  struct opcode_hash *next;
  const struct xap2_opcode *opcode;
};
static struct opcode_hash *opcode_hash_table[HASH_SIZE];

static void build_hash_table
  PARAMS ((const struct xap2_opcode **, struct opcode_hash **, int));
static int compare_opcodes PARAMS ((const PTR, const PTR));

/* the SEXT macro is declared in include/opcode/xap2.h */

/* Right-extend a value which is N bits long from MSB. */
/* FIXME: KLS: this code fails if int rightshift is not signed!          */
#define REX(value, bits) \
	((int)(value) | \
		(((int)(value) & (1 << ((8 * sizeof (int)) - bits))) ? \
		((1 << ((8 * sizeof (int)) - bits)) - 1) : \
		0))

/* Macros used to extract instruction fields.  Not all fields have
   macros defined here, only those which are actually used.  */
/* These are now largely defined as XAP2_A etc in xap2.h.  The following
   two macros should be moved there someday.                 */

#define X_IMM(i,n,start) (((i) >> (start)) & ((1 << (n)) - 1))
#define X_SIMM(i,n,start) SEXT (X_IMM ((i), (n), (start)), (n))
#define X_RIMM(i,n,start) REX (X_IMM ((i), (n), (start)) << (((8 * sizeof(int)) - (n))), (n))

/* extern void qsort (); */

void
print_xap_disassembler_options (FILE *stream ATTRIBUTE_UNUSED)
{
}

/* Program side address */
static void print_pcrel_address(int memaddr, int offset, disassemble_info *info)
{
    bfd_vma target = (offset + memaddr) & 0xffffff;
    bfd_vma symaddr = 0;

    bfd *abfd = info->get_bfd_from_info_func(info);
    asection *sec = info->get_sec_from_info_func(info);

    asymbol *sym;

    sym = info->find_symbol_for_address_func (target, info, NULL);

    if (offset > 0)
        (*info->fprintf_func) (info->stream, "+0x%X", offset & 0xffffff);
    else if (offset == 0)
        (*info->fprintf_func) (info->stream, "0x0");
    else if (offset < 0)
        (*info->fprintf_func) (info->stream, "-0x%X", (-offset) & 0xffffff);

    (*info->fprintf_func) (info->stream, " <");

    if (sym != NULL || sec != NULL)
    {
        if (sym != NULL)
        {
            info->print_symname_func (abfd, info, sym);
            symaddr = bfd_asymbol_value(sym);
        }
        else if (sec != NULL)
        {
            (*info->fprintf_func) (info->stream, "%s", bfd_get_section_name(abfd, sec));
            symaddr = bfd_get_section_vma(abfd, sec);
        }

        if (target < symaddr)
            (*info->fprintf_func) (info->stream, "-0x%lX:", (symaddr-target) & 0xffffff);
        else if (target > symaddr)
            (*info->fprintf_func) (info->stream, "+0x%lX:", (target-symaddr) & 0xffffff);
        else
            (*info->fprintf_func) (info->stream, ":");
    }

    (*info->fprintf_func) (info->stream, "0x%lX[p]>", target & 0xffffff);
}

/* Data side address */
static void print_abs_address(int offset, disassemble_info *info)
{
    bfd_vma target = offset & 0xffff;
    bfd_vma symaddr = 0;

    bfd *abfd = info->get_bfd_from_info_func(info);
    asection *sec = info->get_sec_from_info_func(info);

    asymbol *sym;

    sym = info->find_symbol_for_address_func (target, info, NULL);

    (*info->fprintf_func) (info->stream, "0x%lX <", target);

    /* Target is in real memory - print out nearest symbol + offset */
    if(target < 0xffe0)
      {
        if (sym != NULL || sec != NULL)
          {
            if (sym != NULL)
              {
                info->print_symname_func (abfd, info, sym);
                symaddr = bfd_asymbol_value(sym);
              }
            else if (sec != NULL)
              {
                (*info->fprintf_func) (info->stream, "%s", bfd_get_section_name(abfd, sec));
                symaddr = bfd_get_section_vma(abfd, sec);
              }
            
            if (target < symaddr)
              (*info->fprintf_func) (info->stream, "-0x%lX", (symaddr-target) & 0xffff);
            else if (target > symaddr)
              (*info->fprintf_func) (info->stream, "+0x%lX", (target-symaddr) & 0xffff);
          }
      }
    /* Memory mapped register or scratchpad */
    else
      {
        const char *regname;
        switch(target)
          {
          case 0xffe0: regname = "register ah"; break;
          case 0xffe1: regname = "register al"; break;
          case 0xffe2: regname = "register uxh"; break;
          case 0xffe3: regname = "register uxl"; break;
          case 0xffe4: regname = "register uy"; break;
          case 0xffe5: regname = "register ixh"; break;
          case 0xffe6: regname = "register ixl"; break;
          case 0xffe7: regname = "register iy"; break;
          default: regname = "(scratchpad)";
          }
            (*info->fprintf_func) (info->stream, regname);
      }
    (*info->fprintf_func) (info->stream, ">");

}

/* Print one instruction from MEMADDR on INFO->STREAM.

   On the XAP2 we borrow the the following SPARC trick:

   We suffix the instruction with a comment that gives the absolute
   address involved, as well as its symbolic form, if the instruction
   is preceded by a findable `movhi' and it either uses ld/st with
   an immediate displacement to that register, or it is an `ori'
   instruction on that register.  */

int
print_insn_xap2 (bfd_vma memaddr, disassemble_info *info)
{
  Elf_Internal_Ehdr *header;
  FILE *stream = info->stream;
  bfd_byte buffer[6];
  int status;
  
  /* Buffer for storing multiword instructions */
  static unsigned long long insn = 0;
  static int isize = 0;

  register struct opcode_hash *op;
  /* Nonzero of opcode table has been initialized.  */
  static int opcodes_initialized = 0;
  /* bfd mach number of last call.  */
  static unsigned long current_mach = 0;

  /* AM: Hmm, do we really need this for xap2? */
  if (!opcodes_initialized
      || info->mach != current_mach)
    {
      int i;

      if (!opcodes_initialized)
	sorted_opcodes = (const struct xap2_opcode **)
	  xmalloc (xap2_num_opcodes * sizeof (struct xap2_opcode *));
      /* Reset the sorted table so we can resort it.  */
      for (i = 0; i < xap2_num_opcodes; ++i)
	sorted_opcodes[i] = &xap2_opcodes[i];
      qsort ((char *) sorted_opcodes, xap2_num_opcodes,
	     sizeof (sorted_opcodes[0]), compare_opcodes);

      build_hash_table (sorted_opcodes, opcode_hash_table, xap2_num_opcodes);
      current_mach = info->mach;
      opcodes_initialized = 1;
    }

  header = elf_elfheader (info->section->owner);

  /* Read the current instruction, shifting along any prefixes which may
     be in the buffer from last time. */
  
  status = info->read_memory_func (memaddr, buffer, 2, info);
  if (status == 0)
  {
      insn = (insn << 16) | (bfd_getb16(buffer) & 0xffff);
      isize += 2;
  }
  
  if (status != 0)
  {
      info->memory_error_func (status, memaddr, info);
      return -1;
    }

  info->bytes_per_chunk = 2;
  info->display_endian = info->endian;
  info->insn_info_valid = 1;			/* We do return this info */
  info->branch_delay_insns = 0;                 /* Seems to need to be set */
  info->insn_type = dis_nonbranch;		/* Assume non branch insn */
  info->target = 0;				/* Assume no target known */

  /* Get any prefixes/modifiers.  We want the disassembly to have one word per
     line, so we save the prefixes in insn and write each one out to the
     disassembly */
  if ( ((insn & 0xffff) == 0x0009) || ((insn & 0xff) == 0x00) )
  {
    if((insn & 0xffff) == 0x0009)          /* unsigned modifier */
      (*info->fprintf_func) (stream, "**unsigned");

    if((insn & 0x00ff) == 0x0000) /* prefix */
        /* B-84562 mingw gcc compiler doesn't grok %llX
           Try the C99 print format specifier.
        */    
           
      (*info->fprintf_func) (stream, "**prefx    0x%" PRIX64,(insn >> 8) & 0xff);
    
    /* We have consumed 2 bytes.  Get the next word of the instruction */
    return 2;
  }

  /* Expand 32-bit unsigned arithmetic instructions to 48-bits.  All other 
     expansions are implicit as normally it is just a case of filling higher
     order words with 0 - which happens anyway */
  if((insn & 0xffff0000) == 0x00090000)
  {
	  insn = 0x000900000000LL | (insn & 0xffff);
  }
  
  
recog_insn:
  for (op = opcode_hash_table[HASH_INSN (insn)]; op; op = op->next)
    {
      CONST struct xap2_opcode *opcode = op->opcode;

      /* If the insn isn't supported by the current architecture, skip it.  */
      if( (opcode->iflags & XF_XAP2VANILLA && current_mach != bfd_mach_xap2_base) ||
          (opcode->iflags & XF_XAP2PLUS && current_mach != bfd_mach_xap2_plus) )
          continue;

          
      if ((opcode->match & insn) == opcode->match
	  && (opcode->xxlose & insn) == 0 && !(opcode->iflags & XF_SYNONYM))
	{

	  {
	    register CONST char *s;

	    (*info->fprintf_func) (stream, opcode->name);

        int i = 10 - strlen(opcode->name);
	    do (*info->fprintf_func) (stream, " "); while (--i >= 0);

	    for (s = opcode->argstring; *s != '\0'; ++s)
        {
            /* % followed by 0 to 9 means a parameter is inserted here */
            if (*s != '%' || (*s == '%' && (s[1] < '1' || s[1] > '9')))
            {
                (*info->fprintf_func) (stream, "%c", *s);
                continue;
            }

            /* *s == '%' */
            ++s;

            /* *s == '1' to '9' */
            int arg_num = *s - '0' - 1; /* arg_num from 0 to 8 */
        
            if (arg_num < 0 || arg_num > 8)
            {
                fprintf (stderr, "Internal error: invalid argument number %d", opcode->arg_type[arg_num]);
                abort();
            }

            //printf("INSN=%04X%04X\n", (int)(insn>>32), (int)insn);
            unsigned argval = get_value_from_insn(insn, opcode->arg_location[arg_num]);
            //printf("argval=%x\n",argval);

            /* What is this argument? */
            switch (opcode->arg_type[arg_num])
            {
            case General_Reg:
                (*info->fprintf_func) (stream, "%s", xap2_genregs[argval]);
                break;

            case Unsigned_Immediate_Hex:
                (*info->fprintf_func) (stream, "0x%X", argval & 0xffff);
                break;

            case Signed_Immediate_Hex:
            {
                int len = xap2_get_immediate_length(opcode->arg_location[arg_num], 0, 0);
                int imm = SEXT (argval, len);
                if (imm >= 0)
                    (*info->fprintf_func) (stream, "+0x%X", (imm) & 0xffff);
                else if (imm < 0)
                    (*info->fprintf_func) (stream, "-0x%X", (-imm) & 0xffff);
                break;
            }

            case Signed_Immediate_Offset:
            {
                int len = xap2_get_immediate_length(opcode->arg_location[arg_num], 0, 0);
                int offset = SEXT (argval, len);
                if (offset > 0)
                    (*info->fprintf_func) (stream, "+0x%X", (offset) & 0xffff);
                else if (offset == 0)
                    (*info->fprintf_func) (stream, "0x0");
                else if (offset < 0)
                    (*info->fprintf_func) (stream, "-0x%X", (-offset) & 0xffff);
                break;
            }

            case Abs_Relocatable_Immediate:
            {
/*                 info->target = argval; */
/*                 (*info->print_address_func) (info->target, info); */
/*                 break; */
                int len = 16;
                int imm = SEXT (argval, len);
                info->target = memaddr + imm;
                print_abs_address(imm, info);
                break;
            }

            case Pcrel_Relocatable_Immediate:
            {
                int len = 24;
                int imm = SEXT (argval, len);
                info->target = memaddr + imm;
                print_pcrel_address(memaddr, imm, info);
                break;
            }

            default:
            {
                /*invalid argument type*/
                fprintf (stderr, "Internal error: invalid argument type %d", opcode->arg_type[arg_num]);
                abort();
            }

	        }
        }
      }
      //fprintf(stderr, "isize=%d\n", isize);
      
      /* reset persistent state */
      insn = 0;
      isize = 0;
	  return 2; /* we always consume 2 bytes */
	}
    }

  goto notopcode;  /* Get rid of compiler warning */

notopcode:
  /* If it was a multiword insn, there might have been rogue modifiers/prefixes.
     In this case we can still attempt to disassemble the instruction */
  if(isize > 2)
  {
	insn &= 0xffff;
	isize = 2;
	goto recog_insn;
  }
  
  /* If we get here the instruction is definitely invalid. */
  
  info->insn_type = dis_noninsn;	/* Mark as non-valid instruction */
  (*info->fprintf_func) (stream, "**Unknown**");

  /* reset persistent state */
  insn = 0;
  isize = 0;
  
  /* we always consume 2 bytes */
  return 2;
}

/* Compare opcodes A and B.  */

static int
compare_opcodes (a, b)
     const PTR a;
     const PTR b;
{
  struct xap2_opcode *op0 = * (struct xap2_opcode **) a;
  struct xap2_opcode *op1 = * (struct xap2_opcode **) b;
  unsigned long long match0 = op0->match, match1 = op1->match;
  unsigned long long lose0 = op0->xxlose, lose1 = op1->xxlose;
  register unsigned int i;

  /* If one (and only one) insn isn't supported by the current architecture,
     prefer the one that is.  If neither are supported, but they're both for
     the same architecture, continue processing.  Otherwise (both unsupported
     and for different architectures), prefer lower numbered arch's (fudged
     by comparing the bitmasks).  */
#ifdef never
  if (op0->architecture & current_arch_mask)
    {
      if (! (op1->architecture & current_arch_mask))
	return -1;
    }
  else
    {
      if (op1->architecture & current_arch_mask)
	return 1;
      else if (op0->architecture != op1->architecture)
	return op0->architecture - op1->architecture;
    }
#endif

  /* If a bit is set in both match and lose, there is something
     wrong with the opcode table.  */
  if (match0 & lose0)
    {
      fprintf (stderr, "Internal error:  bad xap2-opcode.h: \"%s\", %#.8llx, %#.8llx\n",
	       op0->name, match0, lose0);
      op0->xxlose &= ~op0->match;
      lose0 = op0->xxlose;
    }

  if (match1 & lose1)
    {
      fprintf (stderr, "Internal error: bad xap2-opcode.h: \"%s\", %#.8llx, %#.8llx\n",
	       op1->name, match1, lose1);
      op1->xxlose &= ~op1->match;
      lose1 = op1->xxlose;
    }

  /* Because the bits that are variable in one opcode are constant in
     another, it is important to order the opcodes in the right order.  */
  for (i = 0; i < 48; ++i)
    {
      unsigned long long x = 1 << i;
      int x0 = (match0 & x) != 0;
      int x1 = (match1 & x) != 0;

      if (x0 != x1)
	return x1 - x0;
    }

  for (i = 0; i < 48; ++i)
    {
      unsigned long long x = 1 << i;
      int x0 = (lose0 & x) != 0;
      int x1 = (lose1 & x) != 0;

      if (x0 != x1)
	return x1 - x0;
    }

#ifdef never
  /* They are functionally equal.  So as long as the opcode table is
     valid, we can put whichever one first we want, on aesthetic grounds.  */

  /* Our first aesthetic ground is that aliases defer to real insns.  */
  {
    int alias_diff = (op0->iflags & XF_ALIAS) - (op1->iflags & XF_ALIAS);
    if (alias_diff != 0)
      /* Put the one that isn't an alias first.  */
      return alias_diff;
  }

  /* Except for aliases, two "identical" instructions had
     better have the same opcode.  This is a sanity check on the table.  */
  i = strcmp (op0->name, op1->name);
  if (i)
    {
      if (op0->iflags & XF_ALIAS) /* If they're both aliases, be arbitrary. */
	return i;
      else
	fprintf (stderr,
		 "Internal error: bad xap2-opcode.h: \"%s\" == \"%s\"\n",
		 op0->name, op1->name);
    }
#endif

  /* Fewer arguments are preferred.  */
  {
    int length_diff = strlen (op0->argstring) - strlen (op1->argstring);
    if (length_diff != 0)
      /* Put the one with fewer arguments first.  */
      return length_diff;
  }

  /* They are, as far as we can tell, identical.
     Since qsort may have rearranged the table partially, there is
     no way to tell which one was first in the opcode table as
     written, so just say there are equal.  */
  /* ??? This is no longer true now that we sort a vector of pointers,
     not the table itself.  */
  return 0;
}

/* Build a hash table from the opcode table.
   OPCODE_TABLE is a sorted list of pointers into the opcode table.  */

static void
build_hash_table (opcode_table, hash_table, num_opcodes)
     const struct xap2_opcode **opcode_table;
     struct opcode_hash **hash_table;
     int num_opcodes;
{
  register int i;
  int hash_count[HASH_SIZE];
  static struct opcode_hash *hash_buf = NULL;

  /* Start at the end of the table and work backwards so that each
     chain is sorted.  */

  memset (hash_table, 0, HASH_SIZE * sizeof (hash_table[0]));
  memset (hash_count, 0, HASH_SIZE * sizeof (hash_count[0]));
  if (hash_buf != NULL)
    free (hash_buf);
  hash_buf = (struct opcode_hash *) xmalloc (sizeof (struct opcode_hash) * num_opcodes);
  for (i = num_opcodes - 1; i >= 0; --i)
    {
      register int hash = HASH_INSN (opcode_table[i]->match);
      register struct opcode_hash *h = &hash_buf[i];
      h->next = hash_table[hash];
      h->opcode = opcode_table[i];
      hash_table[hash] = h;
      ++hash_count[hash];
    }

#if 0 /* for debugging */
  {
    int min_count = num_opcodes, max_count = 0;
    int total;

    for (i = 0; i < HASH_SIZE; ++i)
      {
        if (hash_count[i] < min_count)
	  min_count = hash_count[i];
	if (hash_count[i] > max_count)
	  max_count = hash_count[i];
	total += hash_count[i];
      }

    printf ("Opcode hash table stats: min %d, max %d, ave %f\n",
	    min_count, max_count, (double) total / HASH_SIZE);
  }
#endif
}
