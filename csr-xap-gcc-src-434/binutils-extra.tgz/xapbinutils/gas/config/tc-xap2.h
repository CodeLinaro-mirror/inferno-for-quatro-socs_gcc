/* tc-xap2.h - Macros and type defines for the Cambridge Consultants XAP2.
   Modelled-on: gas/config/tc-sparc.h
   
   Copyright 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998,
   1999, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2,
   or (at your option) any later version.

   GAS is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
   the GNU General Public License for more details.

   You should have received a copy of the GNU General Public
   License along with GAS; see the file COPYING.  If not, write
   to the Free Software Foundation, 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

#ifndef TC_XAP2
#define TC_XAP2 1

#ifdef ANSI_PROTOTYPES
struct frag;
#endif

/* This is used to set the default value for `target_big_endian'.  */
/* AM: see also gas/configure.in                                   */
#define TARGET_BYTES_BIG_ENDIAN 1

#define LOCAL_LABELS_FB 1

#define TARGET_ARCH bfd_arch_xap2

#define TARGET_FORMAT "elf32-xap2"

#define DOUBLESLASH_LINE_COMMENTS       /* allow //-style comments */

/* #define XAP2_BIENDIAN */

#define LITERAL_XAP2_PREFIXES   /* allow h', d' and b' numeric literals */

#define WORKING_DOT_WORD

#define LEX_UPA 2        /* can start an identifier -- line number label */
#define LEX_QM 2         /* can start an identifier */
#define LEX_SQT 1        /* can appear in an identifier */

#define md_elf_section_change_hook() xap2_elf_section_change_hook ()
extern void xap2_elf_section_change_hook (void);

/* The generic backend code considers the argument to .align, .p2align to
   be in bytes but we want to specify it in words.  n is the power of two
   to which we have to align, and max is the maximum number of characters
   to skip.  Byte-align in debugging sections. */
#define  md_do_align(n, fill, len, max, just_record_alignment) \
           do {                                                \
             if ((now_seg->flags & SEC_DEBUGGING) == 0)          \
               {                                               \
                 n += 1;                                       \
                 max <<= 1;                                    \
               }                                               \
           } while (0)

#define LISTING_HEADER "XAP2 GAS "
#define LISTING_WORD_SIZE 1
#define LISTING_LHS_WIDTH 4

/* Length of a byte; used for working out addresses.  As XAP2 is 
   word-addressable, make this 16 bits. */
#define OCTETS_PER_BYTE_POWER 1

extern int xap2_pic_code;

/* We require .word, et. al., to be aligned correctly.  */
#define md_cons_align(nbytes) xap2_cons_align (nbytes)
extern void xap2_cons_align (int);

#define HANDLE_ALIGN(fragp) xap2_handle_align (fragp)
extern void xap2_handle_align (struct frag *);

#define MAX_MEM_FOR_RS_ALIGN_CODE  (3 + 4 + 4)

#ifdef OBJ_ELF
/* Don't turn certain relocs into relocations against sections.  This
   is required for the dynamic linker to operate properly.  When
   generating PIC, we need to keep any non PC relative reloc.  The PIC
   part of this test must be parallel to the code in tc_gen_reloc which
   converts relocations to GOT relocations.  */
/* AM: always convert XAP2 16-bit relocations (1st line not in sparc vsn). */
#define tc_fix_adjustable(FIX) xap2_fix_adjustable(FIX)
extern bfd_boolean xap2_fix_adjustable(struct fix *fixP);

/* Values passed to md_apply_fix3 don't include the symbol value.  */
#define MD_APPLY_SYM_VALUE(FIX) 0
#endif

#define MD_PCREL_FROM_WHERE(fixp,sec) \
   (fixP->fx_where + fixP->fx_frag->fr_address)

#define md_operand(x)

extern void xap2_md_end PARAMS ((void));
#define md_end() xap2_md_end ()

/* If we are doing link-time relaxation, convert all fixups in executable
   sections to relocations so the linker can deal with them. */
/* Additionally, relocations in stabs records should be left by the assembler
 * to be processed by the linker */
#define TC_LINKRELAX_FIXUP(sec) \
   ((sec->flags & SEC_ALLOC) || (sec->flags & SEC_DEBUGGING))

#define RELOC_EXPANSION_POSSIBLE
#define MAX_RELOC_EXPANSION 2

#ifdef OBJ_ELF
#define TC_PARSE_CONS_EXPRESSION(EXP, NBYTES) xap2_cons (EXP, NBYTES)
extern void xap2_cons (expressionS *, int);
#endif

#define TC_CONS_FIX_NEW cons_fix_new_xap2
extern void cons_fix_new_xap2 (struct frag *, int, unsigned int,
                               struct expressionS *);

#define TARGET_USE_CFIPOP 1

#define tc_cfi_frame_initial_instructions xap2_cfi_frame_initial_instructions
extern void xap2_cfi_frame_initial_instructions (void);

#define tc_regname_to_dw2regnum xap2_regname_to_dw2regnum
extern int xap2_regname_to_dw2regnum (const char *regname);

#define tc_cfi_emit_pcrel_expr xap2_cfi_emit_pcrel_expr
extern void xap2_cfi_emit_pcrel_expr (expressionS *, unsigned int);

#define DWARF2_LINE_MIN_INSN_LENGTH     1    /* each instruction can increment the PC by 1 */
#define DWARF2_DEFAULT_RETURN_COLUMN    xap2_regname_to_dw2regnum("X")
#define DWARF2_CIE_DATA_ALIGNMENT       -1   /* registers generally saved at negative offsets to the CFA, word-aligned */

extern int xap2_dwarf2_addr_size (void);
/* B-92777: xap2_dwarf2_addr_size() */
#define DWARF2_ADDR_SIZE(bfd)          4 

#endif /* TC_XAP2 */
/* end of tc-xap2.h */
