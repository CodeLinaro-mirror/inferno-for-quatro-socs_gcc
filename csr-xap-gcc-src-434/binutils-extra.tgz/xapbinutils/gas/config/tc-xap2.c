/* tc-xap2.c -- Assembler for the Cambridge Consultants XAP2.
   Modelled-on: gas/config/tc-sparc.c
   [Beware: there is still SPARC-specific code around.]
   
   Copyright 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998,
   1999, 2000, 2001, 2002, 2003, 2004
   Free Software Foundation, Inc.
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com
   
   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public
   License along with GAS; see the file COPYING.  If not, write
   to the Free Software Foundation, 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

#include <stdio.h>

#include "as.h"
#include "safe-ctype.h"
#include "subsegs.h"
#include "../struc-symbol.h"
#include "symbols.h"

#include "opcode/xap2.h"
#include "dw2gencfi.h"

#ifdef OBJ_ELF
#include "elf/xap2.h"
#include "dwarf2dbg.h"
#endif

/* forward references */
static bfd_boolean fixup_insn (unsigned long long *pinsn,
 bfd_reloc_code_real_type r_type, offsetT val, fixS *fixP,
 bfd_boolean ignore_overflows);
static int fits_in_bits (bfd_signed_vma, int, int);
static int in_unsigned_range (bfd_vma, bfd_vma);
static int get_expression (char *str, expressionS *exp, char **err_string);
static void xap2_number_to_chars (char *buf, unsigned long long val, int n);
static void msort (void *base, size_t nmemb, size_t size, 
 int (*compar) (const void *, const void *));

void md_apply_fix (fixS *fixP, valueT *valP, segT segment);

static unsigned current_mach = bfd_mach_xap2_base;

/* Set if the machine variant was specified on the command line, so
   s_variant can warn if it is overridden by a .variant */
static bfd_boolean mach_from_cmd_line = FALSE;

/* Variable recording whether we have assembled any instructions yet.
   Used by s_variant to make sure we don't switch variant part way through
   a program. */
static bfd_boolean assembly_begun = FALSE;

/* Non-zero if we are generating PIC code.  */
/* PIC code is not currently supported, see config/tc-sparc.c as a    */
/* model if you want to re-enable it.                                 */
/* This is only exported for macros in config/tc-xap2.h .             */
int xap2_pic_code = 0;

/* Non-zero if we should give an error when misaligned data is seen.  */
/* On the XAP2 the check is on by default.                             */
static int enforce_aligned_data = 1;

/* large/small mode */
static int target_small_mode = 0;

extern int target_big_endian;

/* Global `target_big_endian' is used for data.
   The following macro is used for instructions.  */
#define INSN_BIG_ENDIAN target_big_endian

/* Handle of the OPCODE hash table.  */
static struct hash_control *op_hash;

/* Routines to handle the various pseudo operations that are XAP2 specific */
static void s_uacons (int);
static void s_elf_rodata (int);
static void s_elf_bss (int);
static void s_stringer (int);
static void s_variant (int);
static void s_markpublic (int);

enum {
    XAP2_LARGE_MODE,
    XAP2_SMALL_MODE
};
static void s_largesmall (int);

const pseudo_typeS md_pseudo_table[] =
  {
    {"align", s_align_bytes, 0},  /* Defaulting is invalid (0) */

    {"rodata", s_elf_rodata, 0},
    {"bss", s_elf_bss, 0},

    /* tc-xap2.h has #defined md_cons_align to be xap2_cons_align, so we can  */
    /* take various actions when .long etc are not aligned.  Normally all data */
    /* must be aligned to a 1-byte boundary; .uabyte/.1byte etc. are aligned to */
    /* a 1-octet boundary, and may only be used in debug sections */

    {"byte", cons, 1},
    {"word", cons, 2},
    {"dword", cons, 4},
  
    /* By default, .space allocates words.  To allocate bytes, use .spaceb  */
    /* (equivalent to DSB on old XAP2 assembler).                           */
    /* .zero and .zerob are synonyms for .space and .spaceb                 */
    {"space", s_space, 2},
    {"spaceb", s_space, 1},
    {"zero", s_space, 2},
    {"zerob", s_space, 1},
  
    {"ascii", s_stringer, 0},
    {"asciz", s_stringer, 1},
    {"string", s_stringer, 1},
  
    {"pascii", stringer, 0},
    {"pasciz", stringer, 1},
    {"pstring", stringer, 1},
  
    {"uabyte", s_uacons, 1},
    {"uaword", s_uacons, 2},
    {"uadword", s_uacons, 4},
  
    {"1byte", s_uacons, 1},
    {"2byte", s_uacons, 2},
    {"4byte", s_uacons, 4},

    {"variant", s_variant, 0},
    
    {"large", s_largesmall, XAP2_LARGE_MODE},
    {"small", s_largesmall, XAP2_SMALL_MODE},
    
    {"public", s_markpublic, 0},

#if 0
    {"assemble",  s_assemble, 0},
    {"compile", s_compile, 0},
#endif

    {NULL, 0, 0},
  };

/* Size of relocation record.  */
const int md_reloc_size = 12;

/* This array holds the chars that always start a comment.  If the
   pre-processor is disabled, these aren't very useful.  */
const char comment_chars[] = ";";

/* This array holds the chars that only start a comment at the beginning of
   a line.  If the line seems to have the form '# 123 filename'
   .line and .file directives will appear in the pre-processed output.  */
/* Note that input_file.c hand checks for '#' at the beginning of the
   first line of the input file.  This is because the compiler outputs
   #NO_APP at the beginning of its output.  */
/* Also note that comments started like this one will always
   work if '/' isn't otherwise defined.  */
const char line_comment_chars[] = "#";   /* was "#" on SPARC */

const char line_separator_chars[] = ""; /* one instruction per line */

/* Chars that can be used to separate mant from exp in floating point
   nums.  */
const char EXP_CHARS[] = "eE";

/* Chars that mean this number is a floating point constant.
   As in 0f12.456
   or    0d1.2345e12  */
const char FLT_CHARS[] = "rRsSfFdDxXpP";

/* Also be aware that MAXIMUM_NUMBER_OF_CHARS_FOR_FLOAT may have to be
   changed in read.c.  Ideally it shouldn't have to know about it at all,
   but nothing is ideal around here.  */

struct xap2_it
{
  char *error;
  unsigned long long opcode;
  expressionS exp;
  unsigned int length;
  bfd_reloc_code_real_type reloc;
};

static bfd_boolean 
xap2_is_pcrel_reloc (const struct xap2_it* insn)
{
  reloc_howto_type *howto = bfd_reloc_type_lookup (stdoutput, insn->reloc);
  return howto->pc_relative;
}

/* FIXME: it would be nice to get this information out of the howto, but
 * the interpretation of howto->size is not very consistent at the moment,
 * see elf32-xap2.c for details. */
static int 
xap2_reloc_size (const struct xap2_it* insn)
{
  switch (insn->reloc)
    {
    case BFD_RELOC_XAP2_16BIT_ZREL_8:
    case BFD_RELOC_XAP2_16BIT_PCREL_8:
    case BFD_RELOC_XAP2_16BIT_ZREL_8_HWRD:
    case BFD_RELOC_XAP2_16BIT_ZREL_8_LWRD:
      return 2;
        
    case BFD_RELOC_XAP2_32BIT_ZREL_16:
    case BFD_RELOC_XAP2_32BIT_ZREL_8:
    case BFD_RELOC_XAP2_32BIT_PCREL_16:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX:
    case BFD_RELOC_XAP2_32BIT_PCREL_16_NORELAX:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD_NORELAX:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD_NORELAX:
      return 4;
        
    case BFD_RELOC_XAP2_48BIT_ZREL_24:
    case BFD_RELOC_XAP2_48BIT_ZREL_16:
    case BFD_RELOC_XAP2_48BIT_PCREL_24:
    case BFD_RELOC_XAP2_48BIT_PCREL_24_NORELAX:
      return 6;
    
    default:
      return -1;
    }
}

/* Returns TRUE if the linker might relax this instruction. */
static bfd_boolean
xap2_is_relaxable (const struct xap2_it* insn)
{
  reloc_howto_type *howto = bfd_reloc_type_lookup (stdoutput, insn->reloc);
  if (howto && howto->dst_mask & 1) /* REL_RELAX */
    return TRUE;
  return FALSE;
}

static struct xap2_it the_insn;

/* Table of arguments to -A and corresponding settings to current_mach. */

struct xap2_mach {
  char *name;
  unsigned mach;
};

static struct xap2_mach  xap2_mach_table[] = {
  { "xap2", bfd_mach_xap2_base },
  { "xap2+",  bfd_mach_xap2_plus  },
  { "xap2_any", bfd_mach_xap2_any },
  { NULL, 0 }
};

static struct xap2_mach *
lookup_mach (char *name)
{
  struct xap2_mach *sa;
  
  for (sa = &xap2_mach_table[0]; sa->name != NULL; sa++)
    if (strcmp (sa->name, name) == 0)
      break;
  if (sa->name == NULL)
    return NULL;
  return sa;
}

/* md_parse_option
 *      Invocation line includes a switch not recognized by the base assembler.
 *      See if it's a processor-specific option.  These are:
 *      -A<string> sets architecture variant <string>
 *      this sets C variable current_mach from the default bfd_mach_xap2_base.
 *      The architecture used only affects the ELF header; the linker
 *      complains for an inappropriate mix (via e_flags).
 */

const char *md_shortopts = "A:K:V";
struct option md_longopts[] = {};

size_t md_longopts_size = sizeof (md_longopts);

int
md_parse_option (int c, char *arg)
{
  switch (c)
    {
    case 'A':
      {
        struct xap2_mach *sa = lookup_mach (arg);
        if (sa == NULL)
          {
            as_bad ("invalid architecture -A%s", arg);
            return 0;
          }
        current_mach = sa->mach;
        mach_from_cmd_line = TRUE;
      }
      break;
      
#ifdef OBJ_ELF
    case 'V':
      print_version_id ();
      break;
      
#ifdef XAP2_PIC_ENABLED
      /* case 'K': (recognise -KPIC and set xap2_pic) removed from here.       */
    case 'K':
      if (strcmp (arg, "PIC") != 0)
        as_warn (_("Unrecognized option following -K"));
      else
        xap2_pic_code = 1;
      break;
#endif
#endif
      
    default:
      return 0;
    }
  
  return 1;
}

void
md_show_usage (FILE *stream)
{
  fprintf (stream, _("XAP2 options:\n"));
  
  {
    const struct xap2_mach *arch;
    for (arch = &xap2_mach_table[0]; arch->name; arch++)
      {
        if (arch != &xap2_mach_table[0])
          fprintf (stream, " | ");
        fprintf (stream, "-A%s", arch->name);
      }
    fprintf (stream, "\n\
                        specify variant of XAP2 architecture\n");
  }
#ifdef OBJ_ELF
#ifdef XAP2_PIC_ENABLED
  fprintf (stream, _("\
-KPIC                   generate PIC\n"));
#endif
  fprintf (stream, _("\
-V                      print assembler version number\n"));
#endif
}

/* Used for sorting the opcode array. msort uses merge sort, which is
 * used because it is stable, and some of the instructions depend on being
 * attempted in the order in the table.
 *
 * msort is a drop-in replacement for qsort. */
static int
opc_cmp(const void * a, const void * b)
{
  return strcmp ( ((const struct xap2_opcode *) a)->name,
                  ((const struct xap2_opcode *) b)->name );
}

void
msort(void *base, size_t nmemb, size_t size,
      int (*compar) (const void *, const void *))
{
  if (nmemb <= 1)
    return;
  
  size_t split = nmemb/2;
  
  void *a = base, *a_end = base+split*size;
  void *b = a_end, *b_end = base+nmemb*size;
  
  msort (a, split, size, compar);
  msort (b, nmemb-split, size, compar);
  
  void *result = alloca(nmemb*size);
  
  if (result == NULL)
    as_fatal(_("couldn't allocate memory when sorting opcodes"));
  
  while (a < a_end && b < b_end)
    {
      if (compar (a, b) <= 0) /* if equal, choose the earlier */
        {
          memcpy (result, a, size);
          result += size;
          a += size;
        }
      else
        {
          memcpy (result, b, size);
          result += size;
          b += size;
        }
    }
  
  if (a < a_end)
    {
      memcpy (result, a, a_end-a);
      result += a_end-a;
    }
  if (b < b_end)
    {
      memcpy (result, b, b_end-b);
      result += b_end-b;
    }
  result -= nmemb*size;
  
  memcpy(base, result, nmemb*size);
}


/* This function is called once, at assembler startup time.  It should
   set up all the tables, etc. that the MD part of the assembler will
   need.  */

void
md_begin ()
{
  register const char *retval = NULL;
  int lose = 0;
  register unsigned int i = 0;
  
  target_big_endian = 1;
  
  msort (xap2_opcodes, xap2_num_opcodes, sizeof(struct xap2_opcode), opc_cmp);
  
  op_hash = hash_new ();
  
  while (i < (unsigned int) xap2_num_opcodes)
    {
      const char *name = xap2_opcodes[i].name;
      retval = hash_insert (op_hash, name, (PTR) &xap2_opcodes[i]);
      if (retval != NULL)
        {
          as_bad (_("Internal error: can't hash `%s': %s\n"),
                  xap2_opcodes[i].name, retval);
          lose = 1;
        }
      
      do
        {
          if (xap2_opcodes[i].match & xap2_opcodes[i].xxlose)
            {
              as_bad (_("Internal error: losing opcode: `%s' \"%s\"\n"),
                      xap2_opcodes[i].name, xap2_opcodes[i].argstring);
              lose = 1;
            }
          ++i;
        } while (i < (unsigned int) xap2_num_opcodes &&
                 !strcmp (xap2_opcodes[i].name, name));
    }
  
  if (lose)
    as_fatal (_("Broken assembler.  No assembly attempted."));
  
  record_alignment (text_section, 0);
  record_alignment (data_section, 0);
  record_alignment (bss_section, 0);
  
#if defined OBJ_COFF || defined OBJ_ELF
  unsigned int flags = 0;
  
  /* Set the flags in the private structure.  */
  
  bfd_set_private_flags (stdoutput, flags);
  
#endif
  
  /* assume linker is always relaxing */
  linkrelax = 1;
  
  /* FIXME: what about .rodata? */
}

/* Called after all assembly has been done.  */

void
xap2_md_end ()
{
  bfd_set_arch_mach (stdoutput, bfd_arch_xap2, current_mach);
  /* elf_elfheader(stdoutput)->e_flags = current_mach; */
}

/* Return non-zero if VAL (an immediate of IMM_SIZE bits) can fit into
   a field BITS bits wide  */

static INLINE int
fits_in_bits (bfd_signed_vma val, int bits, int imm_size)
{
  /* Selects immediate bits*/
  unsigned int imm_mask =  0xffffffff >> (32 - imm_size);
  /* Selects immediate bits except for sign */
  unsigned int sign_mask = 0xffffffff >> (33 - imm_size);
  bfd_signed_vma true_val;
    
  /* For (e.g.) 16-bit immediates, we allow both 0xffff and -0x1 (which are 
     obviously the same.  So here we check that higher order bits are either
     all zero or all sign */
  if ( !( ((val & ~imm_mask) == 0) ||
          ((val & ~sign_mask) == ~sign_mask) ))
    return 0;
  
  /* It is a valid immediate for that imm_size, so if it is not to be truncated
     we can accept it now */
  if (bits == imm_size)
    return 1;
      
  /* The processor sign-extends short immediates up to 16 (or 24) bits.  If
     this does not change the value of the immediate it is valid. */
  
  true_val = SEXT (val, bits);
  
  if ((val & imm_mask) == (true_val & imm_mask)) return 1;
  else return 0;
}

/* Return non-zero if VAL is in the range 0 to MAX.  */

static INLINE int
in_unsigned_range (bfd_vma val, bfd_vma max)
{
  if ((val & (~max)) == (~max)) /* dirty way of allowing ~0x8000 */
                                /* note: this also allows -0x8001 etc,
                                 * which it shouldn't */
    return 1;
  if (val > max)
    return 0;
  return 1;
}

/* For communication between xap2_ip and get_expression.  */
static char *expr_end;

/* [SSC] TODO: very little of this is correct for XAP2! */
static char *get_reg_errcode[] = {
  /* 0  */ ": <assembler confused>",
  /* -1 */ ": register name undefined",
  /* -2 */ ": register number out of range",
  /* -3 */ ": register missing after '%'",
  /* -4 */ ": register expected",
  /* -5 */ ": duplication in register list",
  /* -6 */ ": missing ',' in register list",
  /* -7 */ ": #<n> out-of-range for opcode",
  /* -8 */ ": bad register range specification",
  /* -9 */ ": expected '{'",
  /* -10 */ ": expected '}'",
};

static int get_register(char *s)
{
  int r = -1;
  int l = 0;
  int i;
  expr_end = s;
  
  while (ISALNUM ((unsigned char) s[l]))
    l++;
  
  if (strncasecmp(s, "sp", l) == 0)
    r = 3; /* sp is an alias for the y register */
  
  else
    {
      for (i = 0; i<4; i++)
        if (strncasecmp (s, xap2_genregs[i], l) == 0) /* NB case insensitive */
          r = i;
    }
  
  if (r < 0)
    expr_end = s;
  else
    expr_end = s + l;
  
  return r;
}

/* Subroutine of xap2_ip to parse an expression.  */
/* AM: I really don't know why this wrapper (to expression()) is useful */
/* -- it comes from config/tc-sparc.c and seems harmless.               */
/* SSC: also recognize HWRD and LWRD here. */

static int
get_expression (char *str, expressionS *exp, char **err_string)
{
  char *save_in;
  segT seg;
  
  save_in = input_line_pointer;
  input_line_pointer = str;
  
  if(ISSPACE(*input_line_pointer))
    ++input_line_pointer;
  
  /* We allow HWRD and LWRD provided that they are used in the following way:
     HWRD (expression)
     as a complete expression, i.e. no further operations on the result.
     
     If the HWRD/LWRD is not followed by a left bracket, it is treated as a
     label.  A label will never be followed by a left bracket so this does not
     pollute the namespace. */
  if (((strncasecmp(input_line_pointer, "HWRD", 4) == 0) || 
       (strncasecmp(input_line_pointer, "LWRD", 4) == 0)) &&
      !is_part_of_name(input_line_pointer[4]))
    {
      char variant = *input_line_pointer;  /* ='H' or 'L' */
      char *start_of_exp;
      int paren_count;
      char *save_ilp = input_line_pointer;
      
      input_line_pointer += 4;    /* -> character after *WRD */
      start_of_exp = input_line_pointer;
      
      /* there might be a space before the expression */
      if (ISSPACE (*input_line_pointer))
        ++input_line_pointer;
      
      /* must be a bracket-enclosed expr */
      if (*input_line_pointer == '(')       
        {
          
          /* input_line_pointer -> initial ( */
          /* Check we have a well-formed expression.  The closing ) should be
           * the last non-whitespace character in the expression. */
          paren_count = 1;
          while (paren_count)
            {
              switch (*(++input_line_pointer))
                {
                case '(':  
                  paren_count++; break;
                case ')':
                  paren_count--; break;
                case ',':
                case '\n':
                  *err_string = _("Mismatched parentheses");
                  expr_end = input_line_pointer;
                  input_line_pointer = save_in;
                  return 1;
                default:
                  break;
                }
            }
             
          /* input_line_pointer -> closing ) */
          /* We should be at the end of the expression.  If we have a null, a 
             newline or a comma we are OK */
          ++input_line_pointer;
          if (!(*input_line_pointer == '\0' || 
                *input_line_pointer == '\n' || 
                *input_line_pointer == ','))
            {
              int ok = 0;
              
              /* Otherwise, we might have one whitespace followed by a '\0'
               * or '\n' or ',' */
              if (ISSPACE (*input_line_pointer++))
                {
                  if (*input_line_pointer == '\0' || 
                      *input_line_pointer == '\n' || 
                      *input_line_pointer == ',')
                    ok = 1;
                }
                   
              if (!ok)
                {
                  *err_string = _("Junk following HWRD/LWRD");
                  expr_end = input_line_pointer;
                  input_line_pointer = save_in;
                  return 1;
                }
            }
             
          /* OK, so we have something that looks like HWRD(expression).  Now we
           * need to parse expression. */
          input_line_pointer = start_of_exp;
          seg = expression (exp);
          
          /* Now ensure the expression is something we support.  This can be a 
           * constant (in which case we calculate it now and just pass an
           * O_constant back to xap2_ip) or something we can put into a
           * relocation, i.e. a symbol possibly plus a number.  We don't
           * support a difference of symbols or anything more complicated. */
          if (exp->X_op == O_constant &&
              exp->X_add_symbol == 0 &&
              exp->X_op_symbol == 0)
            {
              if (variant == 'H' || variant == 'h')
                exp->X_add_number = (exp->X_add_number >> 16) & 0xffff;
              else
                exp->X_add_number = exp->X_add_number & 0xffff;
            }
         
          else if (exp->X_op == O_symbol &&
                   exp->X_op_symbol == 0)
            {
              if (variant == 'H' || variant == 'h')
                exp->X_op = O_md1;   /* O_md1 == HWRD */
              else
                exp->X_op = O_md2;   /* O_md2 == LWRD */
            }
         
          else  /* Not a supported type of expression */
            {
              *err_string = _("Invalid expression inside HWRD/LWRD");
              expr_end = input_line_pointer;
              input_line_pointer = save_in;
              return 1;
            }
          
          expr_end = input_line_pointer;
          input_line_pointer = save_in;
          return 0;
        }
      else   /* (*input_line_pointer == '(') */
        /* It's not a valid HWRD or LWRD, so put input_line_pointer back
           where it was and let expression() parse it */
        input_line_pointer = save_ilp;
      
    } /* if(input_line_pointer -> is "HWRD" or "LWRD") */
  
  seg = expression (exp);
  
  expr_end = input_line_pointer;
  input_line_pointer = save_in;
  return 0;
} /* get_expression() */

static bfd_boolean
xap2_check_immediate_range(bfd_boolean isSigned ATTRIBUTE_UNUSED, long val, 
                           enum xap_arg_location location)
{
  switch (location)
    {
    case OpIMM1:
      return fits_in_bits (val, 8, 16);
      
    case OpIMM2_OpIMM1:
      return fits_in_bits (val, 16, 16);
      
    case OpIMM3_OpIMM2_OpIMM1:
      return fits_in_bits (val, 24, 24);
      
    case OpIMMX:
      return (val >= 0 && val <= 0xf);
      
    default:
      as_fatal (_("Internal error: invalid location"));
    }
}

/* Subroutine of md_assemble to do the actual parsing.  */
/* AM: oddly, xap2_ip does not return a value saying whether an opcode   */
/* was found, so an old value of the_insn may be read by caller.        */
/* However since as_bad will have been called in this case, no output   */
/* file will get produced, so no problem.  Hmm.                         */

static void
lcase(char *s)
{
  do { if (*s >= 'A' && *s <= 'Z') *s += ('a' - 'A'); } while(*++s);
}

static void
xap2_ip (char *str)
{
  char *error_message = "";
  char *s;
  const char *args;
  char c;
  const struct xap2_opcode *insn;
  char *argsStart;
  unsigned long long opcode;
  unsigned long long mask = 0;
  int match = 0;
  bfd_boolean negate_arg = FALSE;
  
  /* The next line needs to recognise "A-Za-z0-9._" but scanning all    */
  /* printable chars can only help error messages.                      */
  for (s = str; ISPRINT ((unsigned char) *s) && *s != ' '; ++s)
    ;
  
  switch (*s)
    {
    case '\0':
      break;
      
    case ' ':
      *s++ = '\0';
      break;
      
    default:
      c = *s;
      *s++ = '\0';
      as_bad (_("Unprintable char in opcode: `%s\\x%.2x'"), str, (unsigned char)c);
      return;
    }
  
  /* At this point str contains the instruction mnemonic and s contains the */
  /* operands */
  
  /* XAP2 assembler is case-insensitive */
  lcase (str);
  
  /* XAP2+ instructions enterl and leavel are difficult to represent in the XML
     file because they are exactly the same as enter and leave, except that they
     negate their argument to tell the processor to signal large mode.  So we
     recognize them here. */
  if (strcmp(str, "enterl") == 0)
    {
      str = "enter";
      negate_arg = TRUE;
    }
  else if (strcmp(str, "leavel") == 0)
    {
      str = "leave";
      negate_arg = TRUE;
    }

  insn = (struct xap2_opcode *) hash_find (op_hash, str);
  
  if (insn == NULL)
    {
      as_bad (_("Unknown opcode: `%s'"), str);
      return;
    }

#if 0
  printf("comparing %s to %s\n", s, insn->args);
#endif

  argsStart = s;
  for (;;)
    {
      opcode = insn->match;
      memset (&the_insn, '\0', sizeof (the_insn));
      the_insn.reloc = BFD_RELOC_NONE;
      the_insn.length = 0;
      
      error_message = "(s) for mnemonic";
      
      if (((insn->iflags & XF_XAP2VANILLA) && 
           current_mach != bfd_mach_xap2_base) ||
          ((insn->iflags & XF_XAP2PLUS) && 
           current_mach != bfd_mach_xap2_plus))
        {
          error_message = ": instruction not available on selected machine type";
          goto error;
        }
      
      /*
       * Build the opcode, checking as we go to make
       * sure that the operands match
       */
      for (args = insn->argstring;; ++args)
      {
#if 0
          printf("\n**args  : %s\n**input : %s\n", args, s);
#endif     
          /* args is the argstring for the insn that is currently trying to be
           * matched */
          /* s is the string in the file to assemble */
          /* whitespace is stripped from the source text */
          while (*args == ' ')
            {
              ++args;
            }
          
          if (*args == '\0')
          {
              if (*s == '\0')
              {
                  /* printf("match found - end of args\n"); */
                  match = 1;
                  break;
              }
              /* argstring matched but still trailing text */
              error_message = ": unexpected text at end of line";
              goto error;
          }
          
          /* % followed by 0 to 9 means a parameter is inserted here */
          if (*args != '%' || 
              (*args == '%' && (args[1] < '1' || args[1] > '9')))
            {
              /*most characters in string are literals*/
              if (*s == *args ||
                  ( *s > 'A' && *s < 'Z' && (*s - 'A' + 'a') == *args) ||
                  ( *s > 'a' && *s < 'z' && (*s - 'a' + 'A') == *args))
              {
                  s++; /* Next character */
                  continue;
              }
              /* We allow sp as an alias for y.  Instructions using the
               * y-indexed addressing mode have argstrings of the format
               * #%1, @(%2,y) */
              else if(strcasecmp(args, "y)") == 0 && strcasecmp(s, "sp)") == 0)
                {
                  match = 1;
                  break;
                }
              else
                {
                  /* If correct, except for additional whitespace in the
                   * assembler argument string, then ignore that whitespace */
                  const char* tryArgs = args;
                  while (*tryArgs == ' ')
                    tryArgs++;
                  
                  if (*s == *tryArgs)
                    {
                      /* We start another loop iteration, so reset the
                       * pointers back so they can be incremented again! */
                      s++;
                      tryArgs--;
                      args = tryArgs;
                      continue;
                    }
                  else if (*args == '%' && args[1] >= '1' && args[1] <= '9')
                    {
                      args = tryArgs; /* fall through */
                    }
                  else
                    {
                      break; /* error */
                    }
                }   
            }
          
          /* *args == '%' */
          ++args;

          /* *args == '1' to '9' */
          int arg_num = *args - '0' - 1; /* arg_num from 0 to 8 */
          
          if (arg_num < 0 || arg_num > 8)
            {
              as_fatal (_("Internal Error: Invalid argument number %d."), arg_num);
            }
          
          /* What is this argument? */
          switch (insn->arg_type[arg_num])
            {
            case General_Reg:
              {
                mask = get_register(s);
                if ((int)mask < 0)
                  {   
                    error_message = get_reg_errcode[-mask];
                    goto error;
                  }
                s = expr_end;
                if (FALSE == put_value_in_insn(&opcode, mask, insn->arg_location[arg_num]))
                  {
                    as_fatal("Internal error: invalid register");
                  }
                break;
              }
              
            case Opcode:
              {
                /* We do very little error checking here, since specifying the
                 * opcode yourself is dangerous enough anyway */
                (void) get_expression (s, &the_insn.exp, &the_insn.error);
                s = expr_end;
                if (the_insn.exp.X_op == O_absent)
                  {
                    as_bad (_("Expecting expression"));
                    return;
                  }
                
                /* Check for constants that don't require emitting a reloc.  */
                if (the_insn.exp.X_op == O_constant
                    && the_insn.exp.X_add_symbol == 0
                    && the_insn.exp.X_op_symbol == 0)
                  {
                    opcode |= the_insn.exp.X_add_number;
                  }
                else
                  {
                    as_bad (_("Opcode expression not constant"));
                  }
                break;
              }
              
            case Signed_Immediate_Hex:
            case Signed_Immediate_Offset:
            case Unsigned_Immediate_Hex:
              {
                /* Note that if the get_expression() fails, we will still
                   have created U entries in the symbol table for the
                   'symbols' in the input string.  Try not to create U
                   symbols for registers, etc.  */
                (void) get_expression (s, &the_insn.exp, &the_insn.error);
                s = expr_end;
                if (the_insn.exp.X_op == O_absent)
                  {
                    as_bad (_("Expecting expression"));
                    return;
                  }
                
                /* Check for constants that don't require emitting a reloc.  */
                if (the_insn.exp.X_op == O_constant
                    && the_insn.exp.X_add_symbol == 0
                    && the_insn.exp.X_op_symbol == 0)
                  {
                    bfd_boolean isSigned = 
                      (insn->arg_type[arg_num] != Unsigned_Immediate_Hex) ? TRUE : FALSE;
                    
                    if (negate_arg)
                      the_insn.exp.X_add_number = -the_insn.exp.X_add_number;
                    
                    if (!xap2_check_immediate_range (isSigned, 
                                                     the_insn.exp.X_add_number,
                                                     insn->arg_location[arg_num]))
                      {
                        error_message = ": value too large for field";
                        goto error;
                      }
                    
                    /* Install the constant into the instruction */
                    if (!put_value_in_insn (&opcode, 
                                            the_insn.exp.X_add_number, 
                                            insn->arg_location[arg_num]))
                      {
                        error_message = ": invalid constant specified";
                        goto error;
                      }
            }
                
                /* If we had a HWRD or a LWRD, create the appropriate 
                 * relocation then set the operation field of the expression 
                 * to O_symbol so as not to confuse things later.
                 *
                 * prefix0 instructions need a 16-bit relocation; prefix1
                 * instructions need a 32-bit non-relaxable relocation.
                 * Everything else gets a 32-bit relaxable relocation. */
                
                else if (the_insn.exp.X_op == O_md1)
                  {
                    switch (insn->relocation_type)
                      {
                      case BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX:
                        the_insn.reloc = BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD_NORELAX;
                        break;
                      case BFD_RELOC_XAP2_16BIT_ZREL_8:
                        the_insn.reloc = BFD_RELOC_XAP2_16BIT_ZREL_8_HWRD;
                        break;
                      case 0:
                        the_insn.reloc = BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD;
                        break;
                      default:
                        as_fatal(_("Internal error: bad opcode table"));
                      }
                    
                    the_insn.exp.X_op = O_symbol;
                  }
                
                else if (the_insn.exp.X_op == O_md2)
                  {
                    switch (insn->relocation_type)
                      {
                      case BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX:
                        the_insn.reloc = BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD_NORELAX;
                        break;
                      case BFD_RELOC_XAP2_16BIT_ZREL_8:
                        the_insn.reloc = BFD_RELOC_XAP2_16BIT_ZREL_8_LWRD;
                        break;
                      case 0:
                        the_insn.reloc = BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD;
                        break;
                      default:
                        as_fatal (_("Internal error: bad opcode table"));
                      }
                    
                    the_insn.exp.X_op = O_symbol;
                  }
                
                else
                  /* We have some sort of symbolic expression, emit a reloc. */
                  {
                    /* This condition is to make up for the fact that
                     * immediates are valid in many places that the xml file
                     * specifies as imm -> Signed_Immediate_Hex, when really
                     * they should be immzrel or something. */
                    if (insn->relocation_type == BFD_RELOC_NONE ||
                        insn->relocation_type == 0)
                      the_insn.reloc = BFD_RELOC_XAP2_32BIT_ZREL_16;
                    else
                      the_insn.reloc = insn->relocation_type;
                  }
                break;
              }
              
            case Pcrel_Relocatable_Immediate:
            case Abs_Relocatable_Immediate:
              {
                /* set insn relocation from opcode table */
                the_insn.reloc = insn->relocation_type;
                
                /* Note that if the get_expression() fails, we will still
                   have created U entries in the symbol table for the
                   'symbols' in the input string.  Try not to create U
                   symbols for registers, etc.  */
                (void) get_expression (s, &the_insn.exp, &the_insn.error);
                s = expr_end;
                if (the_insn.exp.X_op == O_absent)
                  {
                    as_bad (_("Expecting expression"));
                    return;
                  }
                
                /* Can't have HWRD or LWRD here */
                if (the_insn.exp.X_op == O_md1 || the_insn.exp.X_op == O_md2)
                  {
                    as_bad (_("HWRD/LWRD not allowed inside address"));
                    return;
                  }
                
                /* Check for constants that don't require emitting a reloc.  */
                if (the_insn.exp.X_op == O_constant
                    && the_insn.exp.X_add_symbol == 0
                    && the_insn.exp.X_op_symbol == 0)
                  {
                    /* Constants that won't fit are checked in md_apply_fix3
                       and bfd_install_relocation.
                       ??? It would be preferable to install the constants
                       into the insn here and save having to create a fixS
                       for each one.  There already exists code to handle
                       all the various cases (e.g. in md_apply_fix3 and
                       bfd_install_relocation) so duplicating all that code
                       here isn't right.  */
                    /* AM: being done!  Note the fixup_insn16 does not
                       need to be considered here as we are still in 32-bit
                       mode only. */
                    if (!fixup_insn (&opcode, the_insn.reloc,
                                     the_insn.exp.X_add_number, 0, FALSE))
                      {
                        error_message = ": value too large for field";
                        goto error;
                      }
                    /* If it is a fixed length instruction, set the_insn.length now
                       so we don't try to relax it below */
                    if (the_insn.reloc == BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX ||
                        the_insn.reloc == BFD_RELOC_XAP2_32BIT_PCREL_16_NORELAX)
                      the_insn.length = 4;
                    if(the_insn.reloc == BFD_RELOC_XAP2_48BIT_PCREL_24_NORELAX)
                      the_insn.length = 6;
                    
                    /* Discard the relocation, it is already fixed up */
                    the_insn.reloc = BFD_RELOC_NONE;
                  }
                break;
              }
              
            default:
              {
                /*invalid argument type*/
                as_fatal (_("Invalid argument type %d."),
                          insn->relocation_type);
              }
            } /* end switch */
          
        } /* end for each character in insn arguments */
      
    error:
      if (match == 0)
        {
          /* Args don't match. */
          if (&insn[1] - xap2_opcodes < xap2_num_opcodes &&
              (insn->name == insn[1].name ||
               !strcmp (insn->name, insn[1].name)))
            {
              ++insn;
              s = argsStart;
              continue;
            }
          else
            {
              as_bad (_("Illegal operand%s"), error_message);
              return;
            }
        }
      break;
    } /* forever looking for a match */
  
  /* work out the current length of the insn */
  
  /* if we have already set length, it is supposed to be a fixed length
     insn (bra2, bra3) so leave it alone */
  if (the_insn.length == 0)
    {
      /* if it has a relocation, use that */
      if (the_insn.reloc != 0 && the_insn.reloc != BFD_RELOC_NONE)
        the_insn.length = xap2_reloc_size (&the_insn);
      
      /* it's already fixed up, so we can try and relax it */
      else
        the_insn.length = xap2_tryrelax (&opcode, 6);
    }
  
  the_insn.opcode = opcode;
}

/* Main entry point to assemble (and output) one instruction.  */

void
md_assemble (char *str)
{
  int orig_size;
  int isize;
  char *toP;

  know (str);
  
  assembly_begun = TRUE;
  
  /* sets the_insn */
  xap2_ip (str);
  
  orig_size = isize = the_insn.length;
  
  /* Allocate space in the instruction stream, starting a new frag if
   * necessary. */
  toP = frag_more (isize);
  xap2_number_to_chars (toP, the_insn.opcode, isize);
  
  /* Put out the symbol-dependent stuff.  */
  if (the_insn.reloc != 0 && the_insn.reloc != BFD_RELOC_NONE)
    {
      fixS *fixP =  fix_new_exp (frag_now,  /* Which frag.  */
                                 (toP - frag_now->fr_literal),  /* where */
                                 isize,                         /* size  */
                                 &the_insn.exp,
                                 xap2_is_pcrel_reloc (&the_insn),
                                 the_insn.reloc);
      /* AM: The next comment and code comes from the config/tc-sparc.c  */
      /* Maybe we could simplify this code for XAP2, but what the heck!  */
      /* Turn off overflow checking in fixup_segment.  We'll do our
         own overflow checking in md_apply_fix3.  This is necessary because
         the insn size is 4 and fixup_segment will signal an overflow for
         large 8 byte quantities.  */
      fixP->fx_no_overflow = 1;
    }

  /* If the linker might relax this instruction, set the frag as
   * rs_machine_dependent so that expr() does not try to optimize expressions
   * that cross it.  This also starts a new frag. */
  if (xap2_is_relaxable (&the_insn))
    frag_variant (rs_machine_dependent, 0, 0, 0, NULL, 0, NULL);
  
#ifdef OBJ_ELF
  /* isize is in bytes, with 0,1 or 2 prefixes. isize == 0 for a parse error, too */
  assert (isize == 0 || isize == 2 || isize == 4 || isize == 6);
  /* this is measuring [in words] from the start of the instruction,
     so needs to know how long it is */
  if(now_seg->flags & SEC_CODE)
      dwarf2_emit_insn (isize / 2);
#endif
}

/* This is identical to the md_atof in m68k.c.  I think this is right,
   but I'm not sure.
   
   Turn a string in input_line_pointer into a floating point constant
   of type TYPE, and store the appropriate bytes in *LITP.  The number
   of LITTLENUMS emitted is stored in *SIZEP.  An error message is
   returned, or NULL on OK.  */

/* Equal to MAX_PRECISION in atof-ieee.c.  */
#define MAX_LITTLENUMS 6

char *
md_atof (int type, char *litP, int *sizeP)
{
  int i, prec;
  LITTLENUM_TYPE words[MAX_LITTLENUMS];
  char *t;
  
  switch (type)
    {
    case 'f':
    case 'F':
    case 's':
    case 'S':
      prec = 2;
      break;

    case 'd':
    case 'D':
    case 'r':
    case 'R':
      prec = 4;
      break;

    case 'x':
    case 'X':
      prec = 6;
      break;

    case 'p':
    case 'P':
      prec = 6;
      break;

    default:
      *sizeP = 0;
      return _("Bad call to MD_ATOF()");
    }

  t = atof_ieee (input_line_pointer, type, words);
  if (t)
    input_line_pointer = t;
  *sizeP = prec * sizeof (LITTLENUM_TYPE);

  if (target_big_endian)
    {
      for (i = 0; i < prec; i++)
        {
          md_number_to_chars (litP, (valueT) words[i],
                              sizeof (LITTLENUM_TYPE));
          litP += sizeof (LITTLENUM_TYPE);
        }
    }
  else
    {
      for (i = prec - 1; i >= 0; i--)
        {
          md_number_to_chars (litP, (valueT) words[i],
                              sizeof (LITTLENUM_TYPE));
          litP += sizeof (LITTLENUM_TYPE);
        }
    }

  return 0;
}

/* Write a value out to the object file, using the appropriate
   endianness.  */
/* Turns out that valueT is too narrow to store a 48-bit opcode, so here is
   a helper function */
static void
xap2_number_to_chars (char *buf, unsigned long long val, int n)
{
  switch (n)
    {
    case 6:
      *buf++ = (val >> 40) & 0xff;
      *buf++ = (val >> 32) & 0xff;
    case 4:
      *buf++ = (val >> 24) & 0xff;
      *buf++ = (val >> 16) & 0xff;
    case 2:
      *buf++ = (val >> 8) & 0xff;
    /* allow .byte to output a single byte and trust it to realign things 
     *afterwards! */
    case 1:
      *buf++ = val & 0xff;
    case 0:
      break;
    default:
      as_fatal (_("Internal error: invalid number of bytes in md_number_to_chars"));
    }
}

void
md_number_to_chars (char *buf, valueT val, int n)
{
        if (n > 4)
          as_fatal (_("Internal error: too many bytes for valueT in md_number_to_chars"));
        xap2_number_to_chars (buf, (unsigned long long) val, n);
}

/* These functions are called on rs_machine_dependent frags.  XAP2 only uses
 * rs_machine_dependent frags to signal a linker-relaxable instruction
 * (we don't do any relaxation in the assembler) so no special processing is
 * needed */
int
md_estimate_size_before_relax (fragS *fragp ATTRIBUTE_UNUSED, 
                               asection *seg ATTRIBUTE_UNUSED)
{
  return 0;
}

void
md_convert_frag (bfd *abfd ATTRIBUTE_UNUSED, asection *sec ATTRIBUTE_UNUSED,
                 fragS *fragP ATTRIBUTE_UNUSED)
{
  return;
}

/* helper function for md_apply_fix() */
static bfd_boolean
fixup_insn (unsigned long long *pinsn, bfd_reloc_code_real_type r_type,
            offsetT val, fixS *fixP, bfd_boolean ignore_overflows)
{
  bfd_boolean ret = TRUE;
  unsigned long long insn = *pinsn;
  switch (r_type)
    {
    case BFD_RELOC_XAP2_16BIT_ZREL_8:
    case BFD_RELOC_XAP2_32BIT_ZREL_8:
    case BFD_RELOC_XAP2_16BIT_PCREL_8:
      if (!fits_in_bits (val, 8, 16))
        goto ovfl;
      ret = put_value_in_insn (&insn, val, OpIMM1);
      break;
      
    case BFD_RELOC_XAP2_32BIT_ZREL_16:
    case BFD_RELOC_XAP2_48BIT_ZREL_16:
    case BFD_RELOC_XAP2_32BIT_PCREL_16:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX:
    case BFD_RELOC_XAP2_32BIT_PCREL_16_NORELAX:
      if (!fits_in_bits (val, 16, 16))
        goto ovfl;
      ret = put_value_in_insn (&insn, val, OpIMM2_OpIMM1);
      break;
      
    case BFD_RELOC_XAP2_48BIT_ZREL_24:
    case BFD_RELOC_XAP2_48BIT_PCREL_24:
    case BFD_RELOC_XAP2_48BIT_PCREL_24_NORELAX:
      if (!fits_in_bits (val, 24, 24))
        goto ovfl;
      ret = put_value_in_insn (&insn, val, OpIMM3_OpIMM2_OpIMM1);
      break;
      
    case BFD_RELOC_NONE:
    default:
      if (fixP == 0)
        {
          as_fatal (_("assembler confused(fixup_insn)"));
          return FALSE;
        }
      as_bad_where (fixP->fx_file, fixP->fx_line,
                    "bad or unhandled relocation type: 0x%02x",
                    r_type);
      break;
      
    ovfl:
      if (fixP == 0) return FALSE;
      if (ignore_overflows) return FALSE;
      as_bad_where (fixP->fx_file, fixP->fx_line, "relocation overflow: 0x%x into relocation type 0x%02x", (unsigned int) val, r_type);
      break;
    }
  
  *pinsn = insn;
  return ret;
}

/* Apply a fixS to the frags, now that we know the value it ought to
   hold.  */
void
md_apply_fix (fixS *fixP, valueT *valP, segT segment ATTRIBUTE_UNUSED)
{
  offsetT val = * (offsetT *) valP;
  
  assert (fixP->fx_r_type < BFD_RELOC_UNUSED);
  
  fixP->fx_addnumber = val;     /* Remember value for emit_reloc.  */
  
  /* anything that gets here ought is emitted as a relocation for the linker 
     to deal with */
  return;
}

/* "You may define this macro to indicate whether a fixup against a locally
 * defined symbol should be adjusted to be against the section symbol. It
 * should return a non-zero value if the adjustment is acceptable."
 *
 * If it's in a debugging section, leave it alone.
 */
bfd_boolean xap2_fix_adjustable(fixS *fixp)
{
  if(fixp->fx_subsy != NULL &&
     (fixp->fx_r_type == BFD_RELOC_XAP2_UA32 ||
      fixp->fx_r_type == BFD_RELOC_XAP2_UA16 ||
      fixp->fx_r_type == BFD_RELOC_XAP2_UA8))
    return 0;
  
  return 1;
}

/* Translate internal representation of relocation info to BFD target
   format.  */
/* [SSC]: RELOC_EXPANSION_POSSIBLE is defined in tc-xap2.h, so this function
 * returns a pointer to a null-terminated list of arelent*s.  This allows us 
 * to express fixups which require multiple relocations, using 
 * pseudo-relocations.  The only one which is currently supported is
 * R_XAP2_MINUS, which allows things like syma - symb where both syma and
 * symb are relocatable symbols.  To express this, we emit (for example):
 *
 *          R_XAP2_MINUS         symb
 *          R_XAP2_32BIT_ZREL_16  syma
 *         
 * The relocations must be at the same address, consecutive, and in the right
 * order.  It makes no sense to have anything but an ABS location since the
 * result of the operation is an (absolute) constant.  The MINUS relocation
 * has no intrinsic size as it does not actually modify any code; the size of
 * the whole operation is set by the following real relocation.  It can also
 * be used on HWRD/LWRD relocations, though that seems unlikely to be useful!
 */

arelent **
tc_gen_reloc (asection *section ATTRIBUTE_UNUSED, fixS *fixp)
{
  static arelent *retval[3];  /* return array */
  
  arelent *reloc, *pseudoreloc = NULL;
  bfd_reloc_code_real_type code;
  
  reloc = (arelent *) xmalloc (sizeof (arelent));
  
  reloc->sym_ptr_ptr = (asymbol **) xmalloc (sizeof (asymbol *));
  *reloc->sym_ptr_ptr = symbol_get_bfdsym (fixp->fx_addsy);
  reloc->address = (fixp->fx_frag->fr_address + fixp->fx_where);
  
  /* Relocation address is in octets for unaligned-data relocs, bytes for
     everything else */
  if (! (fixp->fx_r_type == BFD_RELOC_XAP2_UA8 ||
         fixp->fx_r_type == BFD_RELOC_XAP2_UA16 ||
         fixp->fx_r_type == BFD_RELOC_XAP2_UA32))
    reloc->address /= bfd_octets_per_byte (stdoutput);

#ifdef DEBUG5  
  fprintf (stderr, "\n\ntc_gen_reloc:\n");
  print_fixup (fixp);
#endif

  /* Difference of symbols - we need to emit 2 relocs */
  if (fixp->fx_subsy != NULL)
    {
      if (S_GET_SEGMENT (fixp->fx_subsy) == absolute_section)
        {
          /* TODO should this be a warning or an error */
          fixp->fx_offset -= S_GET_VALUE (fixp->fx_subsy);
          as_warn_where (fixp->fx_file, fixp->fx_line,
                         _("subtracting an absolute value prior to forming relocation (any labels may have been resolved too early)"));
          fixp->fx_subsy = NULL;
        }
#if 0      
         This would be ideal, but breaks STABS records
         else if (fixp->fx_subsy->sy_value.X_op == O_constant)
         {
         /* TODO should this be a warning or an error */
         fixp->fx_offset -= S_GET_VALUE (fixp->fx_subsy);
         as_warn_where (fixp->fx_file, fixp->fx_line,
         _("subtracting a constant value prior to forming relocation (any labels may have been resolved too early)"));
         fixp->fx_subsy = NULL;
         }
#endif
      else
        {
          pseudoreloc = (arelent *) xmalloc (sizeof (arelent));
          
          pseudoreloc->howto = bfd_reloc_type_lookup (stdoutput,
                                                      BFD_RELOC_XAP2_MINUS);
          pseudoreloc->sym_ptr_ptr = (asymbol **) xmalloc(sizeof(asymbol*));
          *pseudoreloc->sym_ptr_ptr = symbol_get_bfdsym(fixp->fx_subsy);
          pseudoreloc->address = reloc->address;
          pseudoreloc->addend = 0;
        }
    }
  
  switch (fixp->fx_r_type)
    {
      /* XAP2 ELF-supported relocations: */
      
    case BFD_RELOC_16:
    case BFD_RELOC_32:
    case BFD_RELOC_XAP2_UA8:
    case BFD_RELOC_XAP2_UA16:
    case BFD_RELOC_XAP2_UA32:
    case BFD_RELOC_XAP2_16BIT_ZREL_8:
    case BFD_RELOC_XAP2_32BIT_ZREL_16:
    case BFD_RELOC_XAP2_48BIT_ZREL_24:
    case BFD_RELOC_XAP2_32BIT_ZREL_8:
    case BFD_RELOC_XAP2_48BIT_ZREL_16:
    case BFD_RELOC_XAP2_16BIT_PCREL_8:
    case BFD_RELOC_XAP2_32BIT_PCREL_16:
    case BFD_RELOC_XAP2_48BIT_PCREL_24:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_NORELAX:
    case BFD_RELOC_XAP2_32BIT_PCREL_16_NORELAX:
    case BFD_RELOC_XAP2_48BIT_PCREL_24_NORELAX:
    case BFD_RELOC_16_HWRD:
    case BFD_RELOC_16_LWRD:
    case BFD_RELOC_XAP2_16BIT_ZREL_8_HWRD:
    case BFD_RELOC_XAP2_16BIT_ZREL_8_LWRD:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_HWRD_NORELAX:
    case BFD_RELOC_XAP2_32BIT_ZREL_16_LWRD_NORELAX:
    
      code = fixp->fx_r_type;
      break;
      /* Internal assembler-only relocations (should never get here) */
    default:
      as_bad_where (fixp->fx_file, fixp->fx_line,
                    _("Cannot represent %s relocation at %.4lx in XAP2 ELF"),
                    bfd_get_reloc_code_name(fixp->fx_r_type), reloc->address);
      return NULL;
    }
  
  reloc->howto = bfd_reloc_type_lookup (stdoutput, code);
  if (reloc->howto == 0)
    {
      as_bad_where (fixp->fx_file, fixp->fx_line,
                    _("internal error: can't export reloc type %d (`%s')"),
                    fixp->fx_r_type, bfd_get_reloc_code_name (code));
      xfree (reloc);
      return NULL;
    }

   /* @@ Why fx_addnumber sometimes and fx_offset other times?  */
   /* [SSC] It seems that fx_addnumber and fx_offset are often the same.
      More specifically, fx_addnumber is the value that md_apply_fix3 is
      called with, and fx_offset is the similar.  See fixup_insn in write.c
      for the gory details.  It seems that there are two cases where 
      fx_addnumber != fx_offset - in one fx_addnumber is incremented by
      MD_PCREL_FROM_WHERE and fx_offset by something which looks suspiciously
      like it but might not be; in the other they differ by MD_PCREL_FROM_WHERE.
      
      So, fx_offset is the absolute address whereas fx_addnumber, if set, is the
      pc-relative address.  We always want to pass the absolute address on to the
      linker, and indeed the code that was here seems to be doing just that - passing
      fx_addnumber for non-pcrel relocations, fx_addnumber+MD_PCREL_FROM_WHERE+section->vma
      if fx_addsy is a section symbol (?) and fx_offset for other pcrel relocations.
      
      It is now much simpler, though I still need to investigate why section symbols
      for PC relative relocs need to have section->vma added on.  section->vma always
      ought to be 0, after all.
    */
#ifdef OBJ_ELF

  /* This mess is to support arithmetic with absolute symbols.  Such an expression
     gets simplified further upstream in such a way that the bfd_symbol in the fixup
     has a value of 0 but the sy_value field specifies a constant with the result of
     the expression.  Hence logic below.  A better solution would be to dig around in
     write.c and/or expr.c to find out where this happens and make it update the value
     of the bfd symbol as well. */
  if((fixp->fx_addsy->bsym != NULL &&
      (fixp->fx_addsy->bsym->value == 0)) &&
     ((fixp->fx_addsy->sy_value).X_add_number != 0))
    reloc->addend = (fixp->fx_addsy->sy_value).X_add_number;
  else
    reloc->addend = fixp->fx_offset;
  
  if((code == BFD_RELOC_XAP2_16BIT_PCREL_8 ||
      code == BFD_RELOC_XAP2_32BIT_PCREL_16 ||
      code == BFD_RELOC_XAP2_48BIT_PCREL_24 ||
      code == BFD_RELOC_XAP2_32BIT_PCREL_16_NORELAX ||
      code == BFD_RELOC_XAP2_48BIT_PCREL_24_NORELAX) && symbol_section_p(fixp->fx_addsy))
    reloc->addend += section->vma;
  
#endif

  if (pseudoreloc != NULL)
    {
      retval[0] = pseudoreloc;
      retval[1] = reloc;
      retval[2] = NULL;
    }
  else
    {
      retval[0] = reloc;
      retval[1] = NULL;
    }
  
  return retval;
}

/* We have no need to default values of symbols.  */
symbolS *
md_undefined_symbol (char *name ATTRIBUTE_UNUSED)
{
  return 0;
}

/* Round up a section size to the appropriate boundary.  */
valueT
md_section_align (segT segment ATTRIBUTE_UNUSED, valueT size)
{
  return size;
}

/* Exactly what point is a PC-relative offset relative TO?
   On the sparc, they're relative to the address of the offset, plus
   its size.  This gets us to the following instruction.
   RJEQ: Changing to spec v2.11, where it is relative to the start.
   (??? Is this right?  FIXME-SOON).  (XAP2: FIXME-SOON too).  */
long
md_pcrel_from (fixS *fixP)
{
  return MD_PCREL_FROM_WHERE(fixP, NULL);
}

/* Return log2 (VALUE), or -1 if VALUE is not an exact positive power
   of two.  */
static int
ilog2 (int value)
{
  int shift;

  if (value <= 0)
    return -1;

  for (shift = 0; (value & 1) == 0; value >>= 1)
    ++shift;

  return (value == 1) ? shift : -1;
}

/* This static variable is set by s_uacons to tell xap2_cons_align
   that the expression does not need to be aligned.  */
static int xap2_no_align_cons = 0;

/* This static variable is set by xap2_cons to emit requested types
   of relocations in cons_fix_new_xap2.  */
static const char *xap2_cons_special_reloc;

/* This handles the unaligned space allocation pseudo-ops, such as
   .uaword.  .uaword is just like .word, but the value does not need
   to be aligned.  */

static void
s_uacons (int bytes)
{
  /* Tell xap2_cons_align not to align this value.  */
  xap2_no_align_cons = 1;
  cons (bytes);
  xap2_no_align_cons = 0;
  
  if ((now_seg->flags & SEC_DEBUGGING) == 0)
    as_bad ("Octet-aligned data not allowed in non-debug section");
}

/* This gets called when we see a .section in the assembler file.
   
   Make sure SEC_DEBUGGING is set on debug sections.  This is important
   because these sections are octet-addressed rather than byte-addressed.
   ELF has no flag for debug sections, so we recognize them based on name.
   The slightly over-optimised _bfd_elf_make_section_from_shdr in elf.c
   checks for section names starting with .debug, .gnu.linkonce.wi., line
   and .stab.  Here, we only check for .stab and  .debug (DWARF2 information) */
void
xap2_elf_section_change_hook ()
{
  if (strncmp (".debug", now_seg->name, 6) == 0 ||
      strncmp (".stab", now_seg->name, 5) == 0)
    now_seg->flags |= SEC_DEBUGGING;
}

/* We require everything to be aligned to a word boundary (2^0 words),
   unless it was generated by .byte or an .uaxxxx pseudo-op */
void
xap2_cons_align (int nbytes)
{
  int nalign;
  char *p;
  
  /* Don't align if this is an unaligned pseudo-op, or if we are in a .stab or
     .debug section. */
  if (xap2_no_align_cons || (now_seg->flags & SEC_DEBUGGING))
    return;

  if ((nbytes % 2) != 0)
      as_bad("can't align to %d bytes!", nbytes);

  nalign = ilog2 (nbytes);

#if 0
  if (nbytes != 2)
  printf("xap2_cons_align: nbytes = %d, nalign = %d\n", nbytes, nalign);
#endif 

  if (nbytes == 1)
    return;

  /* Only do this if we are enforcing aligned data.  */
  if (!enforce_aligned_data && now_seg != text_section)
    return;

  /* Don't align if this is an unaligned pseudo-op.  */
  if (xap2_no_align_cons)
    return;

  if ((nbytes % 2) != 0)
      as_bad("can't align to %d bytes!", nbytes);

  nalign = ilog2 (nbytes / 2);

#if 0
  if (nbytes != 2)
  printf("xap2_cons_align: nbytes = %d, nalign = %d\n", nbytes, nalign);
#endif

  if (nbytes == 1)
    return;

  if (nalign == 0)
    return;

  assert (nalign > 0);

  if (now_seg == absolute_section)
    {
      if ((abs_section_offset & ((1 << nalign) - 1)) != 0)
        as_bad (_("misaligned data"));
      return;
    }

  p = frag_var (rs_align_test, 1, 1, (relax_substateT) 0,
                (symbolS *) NULL, (offsetT) nalign, (char *) NULL);

  record_alignment (now_seg, nalign);
}

/* This is called from HANDLE_ALIGN in tc-xap2.h.  */

void
xap2_handle_align (fragS *fragp)
{
  int count, fix;
  char *p;

  count = fragp->fr_next->fr_address - fragp->fr_address - fragp->fr_fix;

  switch (fragp->fr_type)
    {
    case rs_align_test:
      if (count != 0)
        as_bad_where (fragp->fr_file, fragp->fr_line, _("misaligned data"));
      break;

    case rs_align_code:
      p = fragp->fr_literal + fragp->fr_fix;
      fix = 0;

      if (count & 3)
        {
          fix = count & 3;
          memset (p, 0, fix);
          p += fix;
          count -= fix;
        }

      if (INSN_BIG_ENDIAN)
        number_to_chars_bigendian (p, 0x23456789, 4);        /* SPARC NOP? */
      else
        number_to_chars_littleendian (p, 0x23456789, 4);     /* SPARC NOP? */

      fragp->fr_fix += fix;
      fragp->fr_var = 4;
      break;

    default:
      break;
    }
}

#ifdef OBJ_ELF
void
xap2_cons (expressionS *exp, int size)
{
  char *save;
  char *err_string;
  
  /* [SSC]: I don't know what this lot is supposed to be doing but it seems
            harmless! */
            
  SKIP_WHITESPACE ();
  xap2_cons_special_reloc = NULL;
  save = input_line_pointer;
  if (input_line_pointer[0] == '%'
      && input_line_pointer[1] == 'r'
      && input_line_pointer[2] == '_')
    {
      if (strncmp (input_line_pointer + 3, "disp", 4) == 0)
        {
          input_line_pointer += 7;
          xap2_cons_special_reloc = "disp";
        }
      else if (strncmp (input_line_pointer + 3, "plt", 3) == 0)
        {
          if (size != 4 && size != 8)
            as_bad (_("Illegal operands: %%r_plt in %d-byte data field"), size);
          else
            {
              input_line_pointer += 6;
              xap2_cons_special_reloc = "plt";
            }
        }
      else if (strncmp (input_line_pointer + 3, "tls_dtpoff", 10) == 0)
        {
          if (size != 4 && size != 8)
            as_bad (_("Illegal operands: %%r_tls_dtpoff in %d-byte data field"), size);
          else
            {
              input_line_pointer += 13;
              xap2_cons_special_reloc = "tls_dtpoff";
            }
        }
      if (xap2_cons_special_reloc)
        {
          int bad = 0;
          
          switch (size)
            {
            case 1:
              if (*input_line_pointer != '8')
                bad = 1;
              input_line_pointer--;
              break;
            case 2:
              if (input_line_pointer[0] != '1' || input_line_pointer[1] != '6')
                bad = 1;
              break;
            case 4:
              if (input_line_pointer[0] != '3' || input_line_pointer[1] != '2')
                bad = 1;
              break;
            case 8:
              if (input_line_pointer[0] != '6' || input_line_pointer[1] != '4')
                bad = 1;
              break;
            default:
              bad = 1;
              break;
            }
          
          if (bad)
            {
              as_bad (_("Illegal operands: Only %%r_%s%d allowed in %d-byte data fields"),
                      xap2_cons_special_reloc, size * 8, size);
            }
          else
            {
              input_line_pointer += 2;
              if (*input_line_pointer != '(')
                {
                  as_bad (_("Illegal operands: %%r_%s%d requires arguments in ()"),
                          xap2_cons_special_reloc, size * 8);
                  bad = 1;
                }
            }
          
          if (bad)
            {
              input_line_pointer = save;
              xap2_cons_special_reloc = NULL;
            }
          else
            {
              int c;
              char *end = ++input_line_pointer;
              int npar = 0;
              
              while (! is_end_of_line[(c = *end)])
                {
                  if (c == '(')
                    npar++;
                  else if (c == ')')
                    {
                      if (!npar)
                        break;
                      npar--;
                    }
                  end++;
                }
              
              if (c != ')')
                as_bad (_("Illegal operands: %%r_%s%d requires arguments in ()"),
                        xap2_cons_special_reloc, size * 8);
              else
                {
                  *end = '\0';
                  expression (exp);
                  *end = c;
                  if (input_line_pointer != end)
                    {
                      as_bad (_("Illegal operands: %%r_%s%d requires arguments in ()"),
                              xap2_cons_special_reloc, size * 8);
                    }
                  else
                    {
                      input_line_pointer++;
                      SKIP_WHITESPACE ();
                      c = *input_line_pointer;
                      if (! is_end_of_line[c] && c != ',')
                        as_bad (_("Illegal operands: garbage after %%r_%s%d()"),
                                xap2_cons_special_reloc, size * 8);
                    }
                }
            }
        }
    }
  if (xap2_cons_special_reloc == NULL)
    {
      if(get_expression (input_line_pointer, exp, &err_string) != 0)
        as_bad(_("Bad expression: %s"), err_string);
      
      input_line_pointer = expr_end;
    }
}

#endif

/* This is called by emit_expr via TC_CONS_FIX_NEW when creating a
   reloc for a cons.  We could use the definition there, except that
   we want to handle little endian relocs specially.  */
void
cons_fix_new_xap2 (fragS *frag, int where, unsigned int nbytes,
                   expressionS *exp)
{
  bfd_reloc_code_real_type r;
  
  if (!(xap2_no_align_cons || (now_seg->flags & SEC_DEBUGGING)))
    {
      if (exp->X_op == O_md1)
        {
          r = BFD_RELOC_16_HWRD;
          exp->X_op = O_symbol;
        }
      
      else if (exp->X_op == O_md2)
        {
          r = BFD_RELOC_16_LWRD;
          exp->X_op = O_symbol;
        }
      else switch (nbytes)
        {
        case 1: r = BFD_RELOC_8; break;
        case 2: r = BFD_RELOC_16; break;
        case 4: r = BFD_RELOC_32; break;
        case 8: r = BFD_RELOC_64; break;
        default: abort ();
        }
    }
  else
    {
      switch (nbytes)
        {
        case 1: r = BFD_RELOC_XAP2_UA8; break;
        case 2: r = BFD_RELOC_XAP2_UA16; break;
        case 4: r = BFD_RELOC_XAP2_UA32; break;
        default: abort ();
        }
    }

  fix_new_exp (frag, where, (int) nbytes, exp, 0, r);
}

void
xap2_cfi_frame_initial_instructions ()
{
    static int regno = -1;

    if (regno < 0)
    {
        xap2_regname_to_dw2regnum("Y");
    }
    assert (regno >= 0);

    /* On entry to a function, the CFA is at SP + 0 */
    cfi_add_CFA_def_cfa(regno, 0);
}

/* The register numbering scheme is the same as that used by CSR GCC 4.3.4 */
/* Returns -1 on no match */
int 
xap2_regname_to_dw2regnum (const char *regname)
{
    /* NB this only handles registers up to 7, and not the 4 virtual registers or the 2 stack registers */
    static const char* reg_names[] = {"AH", "AL", "XH", "X", 0, "Y", 0};
    int reg = -1;
    unsigned int i;
    for (i = 0; i < ARRAY_SIZE(reg_names); i++)
    {
        const char* test_name = reg_names[i];
        if (test_name && strcmp(regname, test_name) == 0)
        {
            reg = (int) i;
            break;
        }
    }
    return reg;
}

void
xap2_cfi_emit_pcrel_expr (expressionS *exp, unsigned int nbytes)
{
    /* TODO this needs work! */
    xap2_cons_special_reloc = "disp";
    xap2_no_align_cons = 1;
    emit_expr (exp, nbytes);
    xap2_no_align_cons = 0;
    xap2_cons_special_reloc = NULL;
}

/* Pseudo op handlers: */

/* Pseudo op to change to the .rodata section.  */
static void
s_elf_rodata (int xxx)
{
  char *save_line = input_line_pointer;
  static char section[] = ".rodata\n";

  /* Just pretend this is .section .rodata */
  input_line_pointer = section;
  obj_elf_section (xxx);

  input_line_pointer = save_line;
}

static void
s_elf_bss (int xxx)
{
  char *save_line = input_line_pointer;
  static char section[] = ".bss\n";

  /* Just pretend this is .section .bss */
  input_line_pointer = section;
  obj_elf_section (xxx);

  input_line_pointer = save_line;
}

/* Copied from stringer() in read.c, but modified to output unpacked strings
   (i.e. one word per character) */
/* We read 0 or more ',' separated, double-quoted strings.
   Caller should have checked need_pass_2 is FALSE because we don't
   check it.  */
static void
s_stringer (/* Worker to do .ascii etc statements.  */
          /* Checks end-of-line.  */
          register int append_zero      /* 0: don't append '\0', else 1.  */)
{
  register unsigned int c;
  char *start;

  /* If we are in a DWARF section, all strings are packed */
  if (now_seg->flags & SEC_DEBUGGING)
    {
      xap2_no_align_cons = 1;
      stringer (append_zero);
      xap2_no_align_cons = 0;
      return;
    }
  
#ifdef md_flush_pending_output
  md_flush_pending_output ();
#endif
  
  /* The following awkward logic is to parse ZERO or more strings,
     comma separated. Recall a string expression includes spaces
     before the opening '\"' and spaces after the closing '\"'.
     We fake a leading ',' if there is (supposed to be)
     a 1st, expression. We keep demanding expressions for each ','.  */
  if (is_it_end_of_statement ())
    {
      c = 0;                    /* Skip loop.  */
      ++input_line_pointer;     /* Compensate for end of loop.  */
    }
  else
    {
      c = ',';                  /* Do loop.  */
    }
  /* If we have been switched into the abs_section then we
     will not have an obstack onto which we can hang strings.  */
  if (now_seg == absolute_section)
    {
      as_bad (_("strings must be placed into a section"));
      c = 0;
      ignore_rest_of_line ();
    }

  while (c == ',' || c == '<' || c == '"')
    {
      SKIP_WHITESPACE ();
      switch (*input_line_pointer)
        {
        case '\"':
          ++input_line_pointer; /*->1st char of string.  */
          start = input_line_pointer;
          while (is_a_char (c = next_char_of_string ()))
            {
              FRAG_APPEND_1_CHAR (0);
              FRAG_APPEND_1_CHAR (c);
            }
          if (append_zero)
            {
              FRAG_APPEND_1_CHAR (0);
              FRAG_APPEND_1_CHAR (0);
            }
          know (input_line_pointer[-1] == '\"');

          break;
        case '<':
          input_line_pointer++;
          c = get_single_number ();
          FRAG_APPEND_1_CHAR (0);
          FRAG_APPEND_1_CHAR (c);
          if (*input_line_pointer != '>')
            {
              as_bad (_("expected <nn>"));
            }
          input_line_pointer++;
          break;
        case ',':
          input_line_pointer++;
          break;
        }
      SKIP_WHITESPACE ();
      c = *input_line_pointer;
    }

  demand_empty_rest_of_line ();
  
  /* [SSC] UGLYHACK: Don't remove this unless you can figure out why it
     works!  The problem is that if you have lots of .asciis in .rodata
     sometimes the labels pointing to them will end up pointing one word
     too early, causing predictably bizarre runtime errors.  The following 
     ought to be a no-op but fixes it.  Maybe the problem is that the frag 
     is getting too big?  But I haven't been able to track it down. */
  frag_align(0,0,0); 
}                               /* stringer() */

static void
s_variant (int i ATTRIBUTE_UNUSED)
{
  unsigned new_mach;
  char *s;
  char c;
  
  s = input_line_pointer;  /* -> first character of argument */
  
  while(ISGRAPH(*input_line_pointer))
    input_line_pointer++;
  
  c = *input_line_pointer;
  *input_line_pointer = 0;
  
  if(strcasecmp(s, "xap2") == 0)
    new_mach = bfd_mach_xap2_base;
  else if(strcasecmp(s, "xap2+")  == 0)
    new_mach = bfd_mach_xap2_plus;
  else if(strcasecmp(s, "xap2_any") == 0)
    new_mach = bfd_mach_xap2_any;
  else
    {
      as_bad(_("Unrecognized machine variant %s"), s);
      ignore_rest_of_line();
      return;
    }
  
  *input_line_pointer = c;
  
  demand_empty_rest_of_line();
  
  if(assembly_begun)
    {
      if(new_mach != current_mach)
        {
          as_bad(_("Tried to switch machine variant part way through program!"));
          return;
        }
      else
        {
          as_warn(_(".variant part way through program"));
        }
    }
  
#define VARIANT_NAME(v) ( (v == bfd_mach_xap2_base) ? "xap2" : \
                          (v == bfd_mach_xap2_plus) ? "xap2+" : \
                          (v == bfd_mach_xap2_any) ? "xap2_any" : \
                          "unknown")
  
  if(mach_from_cmd_line && current_mach != new_mach)
    {
      as_warn(_("Setting machine variant to '%s' overriding '%s' specified on command line"),
              VARIANT_NAME(new_mach), VARIANT_NAME(current_mach));
    }          
  
  current_mach = new_mach;
}

void
s_markpublic (int ignore ATTRIBUTE_UNUSED)
{
    char *name;
    int c;
    symbolS *sym;
    asymbol *bfdsym;
    elf_symbol_type *elfsym;

    name = input_line_pointer;
    c = get_symbol_end ();
    sym = symbol_find_or_make(name);
    bfdsym = symbol_get_bfdsym(sym);
    elfsym = elf_symbol_from(bfd_asymbol_bfd(bfdsym), bfdsym);
    elfsym->internal_elf_sym.st_other |= STO_XAP2_PUBLIC;
    *input_line_pointer = c;

    demand_empty_rest_of_line ();
}

static void
s_largesmall (int mode)
{
    switch (mode) {
        case XAP2_LARGE_MODE:
            target_small_mode = 0;
            break;
        case XAP2_SMALL_MODE:
            target_small_mode = 1;
            break;
    }
}

int
xap2_dwarf2_addr_size (void)
{
    return target_small_mode ? 2 : 4;
}
