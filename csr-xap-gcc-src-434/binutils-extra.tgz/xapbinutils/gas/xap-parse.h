/* xap-parse.h - Assembly parsing code for the Cambridge Consultants
                 XAP processors.

   Copyright (C) 2008 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public
   License along with GAS; see the file COPYING.  If not, write
   to the Free Software Foundation, 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

struct fixed_len_insn
{
    char* name;
    bfd_reloc_code_real_type reloc;
};

struct xap_it
{
    char *error;
    opcode_t opcode;
    expressionS exp;
    int i_subtype;         /* for relaxable opcodes: FR_SUBTYPE_xxx above */
    bfd_boolean mayrelax;  /* are we allowed to relax this opcode? */
    bfd_reloc_code_real_type reloc;
};

extern void xap_parse_ip (char *str, struct hash_control * op_hash, struct xap_it* the_insn, struct fixed_len_insn* fixed_len_insns, int num_brk_regs, unsigned invalid_iflags);
