/* xap-parse.c - Assembly parsing code for the Cambridge Consultants
                 XAP processors.

   Copyright (C) 2008 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

   This file is part of GAS, the GNU Assembler.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public
   License along with GAS; see the file COPYING.  If not, write
   to the Free Software Foundation, 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdarg.h>

#include "as.h"
#include "safe-ctype.h"
#include "subsegs.h"
#include "../struc-symbol.h"
#include "symbols.h"
#define XAP_PARSER
#include "targ-cpu.h"

/* FIXME: this file depends heavily on declarations in tc-xap{4|5|6}.h, but
   is always included in the build.
 */
#if defined(TC_XAP4) || defined(TC_XAP5) || defined(TC_XAP6)

#include "xap-parse.h"

/* Sign-extend V from bit B */
#undef SEXT
#define SEXT(V,B)  ((((V) & ((1LL << ((B)+1)) - 1)) ^ (1LL << (B))) - (1LL << (B)))

/* Conditional sign-extend V from bit B, only if all higher bits are clear */
#undef CSEXT
#define CSEXT(V,B) (((V) & ~((1LL << ((B)+ 1)) - 1)) ? (V) : SEXT(V,B))

/* Foward references */
static void get_expression PARAMS ((char **, struct xap_it *));

static char *get_reg_errcode[] = {
  /* 0  */ "<assembler confused>",
  /* -1 */ "register name undefined",
  /* -2 */ "register number out of range",
  /* -3 */ "register missing after '%'",
  /* -4 */ "register expected",
  /* -5 */ "duplication in register list",
  /* -6 */ "missing ',' in register list",
  /* -7 */ "#<n> out-of-range for opcode",
  /* -8 */ "bad register range specification",
  /* -9 */ "expected '{'",
  /* -10 */ "expected '}'",
  /* -11 */ "registers appear in incorrect order",
};

static int lookup_reg(const char *s, int slen, const char *rtab[16])
{
    int i;
    if (rtab != 0)
    {
        for (i = 0; i<8; i++)
        {
            if (strncmp(s, rtab[i], slen) == 0)
            {
                return i;
            }
        }
    }
    return -1;
}

static int get_register(char **input, char flavour, int mask)
{
    int r = -1;
    int c;
    char *s = *input;
    if (*s != '%')
        return -4; /* "register expected" */

    const char **tab = get_register_tab(flavour);

    s++;
    if (tab)
    {
	char *ss = s;
	while (ISALNUM((unsigned char)(c = *s)) || c == '_')
	    s++;

	r = lookup_reg(ss, s-ss, tab);
    }
    else
    {
	if (*s++ != flavour || ! ISDIGIT ((unsigned char) (c = *s++)))
	    return -3; /* "register missing after '%'" */

	if (ISDIGIT ((unsigned char) *s))
	    return -2; /* "register not 0..7" */

	c -= '0';
	if (!(mask & (1 << c)))
	    return -2; /* "register not 0..7" */

	r = c;
    }

    *input = s;
    return r & 15;
}

static int get_reglist(char **input, bfd_boolean increasing)
{
    int r1, r2, mask = 0;
    int last_seen = (increasing ? -1 : 1000);
    char *s = *input;
    for (;;)
    {
        while (*s == ' ') s++;

        if (*s == '}')
	    break;

        if (mask != 0)
        {
            if (*s != ',')
		return -6; /* "missing ',' in register list" */
	    s++;
	    while (*s == ' ') s++;
        }

        r1 = r2 = get_register(&s, 'r', 0xff);
        if (r1 < 0)
	    return r1;

	if (increasing ? (last_seen >= r1) : (last_seen <= r1))
            return -11; /* "registers appear in incorrect order" */

        if (*s == '-')
        {
	    s++;
            r2 = get_register(&s, 'r', 0xff);
            if (r2 < 0)
		return r2;

	    if (increasing ? (r1 >= r2) : (r1 <= r2))
		return -11; /* "registers appear in incorrect order" */
        }

	/* make sure rh >= rl, regardless of the setting of increasing */
	int rh = (r2 > r1) ? r2 : r1;
	int rl = (r2 < r1) ? r2 : r1;

        mask |= (1 << (rh+1)) - (1 << rl);

        last_seen = r2;
    }

    *input = s;
    return mask;
}

static int get_reglist_braces(char **input, bfd_boolean increasing)
{
    if (**input != '{')
        return -9; //Expected {

    (*input)++;

    int ret;
    ret = get_reglist(input, increasing);

    if (ret < 0)
	return ret;
    if (**input != '}')
	return -10; //Expected }

    (*input)++;
    return ret;
}

static struct {
  char *name;
  int position;
} flags_bits[] = {
  {"z", 0},
  {"n", 1},
  {"c", 2},
  {"v", 3},
  {"m0", 4},
  {"m1", 5},
  {"i", 6},
  {"s0", 7},
  {"s1", 8},
  {"s2", 9},
  {"s3", 10},
  {"s4", 11},
  {"p0", 12}, {"b", 12},
  {"p1", 13}, {"t", 13},
  {"p2", 14},
  {"p3", 15},
};
#define NUM_FLAGS (sizeof(flags_bits)/sizeof(flags_bits[0]))

static int get_flags_bit(char **input)
{
    unsigned int i; 
    for (i=0; i<NUM_FLAGS; i++)
    {
      int len = strlen(flags_bits[i].name);
      if (strncmp(*input, flags_bits[i].name, len) == 0)
      {
	(*input) += len;
	return flags_bits[i].position;
      }
    }

    return -1;
}

static int get_bitspec(char **input)
{
    char *s = *input;
    while (*s == ' ') s++;

    if (0 <= *s && *s <= '7')
    {
        *input = s + 1;
        return *s - '0';
    }

    return -1;
}

/* Subroutine of xapN_ip to parse an expression.  */

static void
get_expression (char **input, struct xap_it *insn_data)
{
  char *save_in;

  save_in = input_line_pointer;
  input_line_pointer = *input;

  (void) expression (&insn_data->exp);

  *input = input_line_pointer;
  input_line_pointer = save_in;
}


/* Parser parameters */

#define MATCH_OPEN  "([{"
#define MATCH_CLOSE ")]}"
#define MATCH_CHARS 3

#define MAX_LINE_LEN 1024

#define MAX_FORMS 32 /* maximum entries in opcodes with same mnemonic */

/* This code splits a string on commas, paying attention to parens etc.
 *
 * It assumes that ret has been declared at least as char [5][1024];
 *
 * It returns FALSE on error. */

static bfd_boolean
split_parameter_list (char *s, char ret[][MAX_LINE_LEN], int *retlen)
{
  int match_stack[MAX_LINE_LEN];
  int match_depth = 0;

  char *source = s;
  char *target = ret[0];
  *retlen = 1;

  while (*source == ' ')
    source++;

  if (*source == '\0')
  {
    *retlen = 0;
    return TRUE;
  }

  while (*source != '\0')
  {
    int i;
    for (i=0; i<MATCH_CHARS; i++)
    {
      if (*source == MATCH_OPEN[i])
	match_stack[match_depth++] = i;

      if (*source == MATCH_CLOSE[i])
      {
	match_depth--;
	if (match_stack[match_depth] != i)
	{
	  as_bad(_("Parse error: failed to match '%c' (got '%c')"),
	      MATCH_OPEN[match_stack[match_depth]], *source);
	  return FALSE;
	}
      }
    }

    if (match_depth == 0 && *source == ',')
    {
      /* Start a new parameter */
      *target = '\0';
      if (*retlen == 5)
      {
	as_bad(_("Parse error: too many parameters"));
	return FALSE;
      }
      target = ret[*retlen];
      (*retlen)++;

      /* pass comma and skip space */
      source++;
      while (*source == ' ')
	source++;
    }
    else
    {
      /* add and move on */
      *target = *source;
      target++;
      source++;
    }
  }

  /* finish off last parameter */
  *target = '\0';

  if (match_depth != 0)
  {
    as_bad(_("Parse error: unmatched '%c' at end of line"),
	MATCH_OPEN[match_stack[match_depth-1]]);
    return FALSE;
  }

  *target = '\0';

  return TRUE;
}

/* The return value of this function is a 'distance' from a successful parse.
 * If the parse is successful, it should return 0. Otherwise, it should return
 * smaller numbers for more likely mistakes for people to make, and larger
 * numbers if it seems likely that simply the incorrect format is being tried.
 *
 * TODO: make the subfunctions (get reglist et al.) distance aware. */

static int
parse_parameter(char *input, char *fmt, const xap_opcode_t *insn,
	        opcode_t *opcode, struct xap_it *insn_data, struct fixed_len_insn* fixed_len_insns,
		char **errormsg)
{
  int mask;

start_of_parse_loop:
  while (*fmt != '\0')
  {
    /* be nice about accepting literal constants (allow hex etc) */
    /* todo check if (*fmt == ' ') should be included here too */
    if ('0' <= *fmt && *fmt <= '9')
    {
      int required = -1, given = -1;
      char *new;

      required = (int) strtol(fmt, &new, 0);
      if (new == fmt) /* strtol failed */
	as_fatal(_("Failed to parse format"));
      if (*new != '\0')
	as_fatal(_("Extraneous data in format: `%s'"), new);

      given = (int) strtol(input, &new, 0);
      if (new == input) /* strtol failed */
      {
	if (asprintf(errormsg, "Expected %d, got `%s'", required, input) == -1)
	  as_fatal ("%s", xstrerror (errno));
	return 2;
      }
      if (*new != '\0')
      {
	if (asprintf(errormsg, "Unexpected data after integer literal: `%s'", new) == -1)
	  as_fatal ("%s", xstrerror (errno));
	return 1;
      }

      if (required != given)
      {
	if (asprintf(errormsg, "Got incorrect integer literal: "
			       "expected %d, got %d", required, given) == -1)
	  as_fatal ("%s", xstrerror (errno));
	return 1;
      }

      return 0;
    }

    /* % followed by 0 to 9 means a parameter is inserted here */
    if (! (fmt[0] == '%' && '1' <= fmt[1] && fmt[1] <= '9'))
    {
      /* compare literal characters*/

      /* if correct except for additional whitespace in the assembler
       * format string, then ignore that space */
      if (*fmt != *input && *fmt == ' ')
      {
	fmt++;
	goto start_of_parse_loop;
      }

      /* handle errors due to literal differences */
      if (*fmt != *input)
      {
	if (*fmt == '%') /* eg. %pc */
	  *errormsg = strdup("Expected %<register>");
	else if ((*fmt == '(' && *input == '@') ||
		 (*fmt == '@' && *input == '('))
	  *errormsg = strdup("Incorrect address formation type");
	else if (*fmt == '@' || *fmt == '(')
	  *errormsg = strdup("Expected address formation");
	else if (*input == '@' || *input == '(')
	  *errormsg = strdup("Unexpected address formation");
	else
	{
	  if (asprintf(errormsg, "Expected '%c', got '%c'", *fmt, *input) == -1)
	    as_fatal ("%s", xstrerror (errno));
	}
	return 2;
      }

      /* literal characters have matched */

      if (fmt[0] == '@' && fmt[1] == '(' && input[1] != '(')
      {
	*errormsg = strdup("@ must precede an address formation");
	return 3;
      }

      if ((fmt[0] == '@' && fmt[1] == '(') || fmt[0] == '(')
      {
	/* we are parsing an address formation. we parse the second part
	 * first, because it is likely to yield a more fundamental error. */

	/* move into the start of the address formation */
	if (*fmt == '@')
	{
	  fmt += 2;
	  input += 2;
	}
	else if (*fmt == '(')
	{
	  fmt++;
	  input++;
	}

	/* since we write to the strings, we duplicate them first */
	char *fmt2 = strdup(fmt);
	char *input2 = strdup(input);

	char *fmt2_end = fmt2 + strlen(fmt2) - 1;
	char *input2_end = input2 + strlen(input2) - 1;

	char *fmt2_comma = fmt2_end;
	char *input2_comma = input2_end;

	know(*fmt2_end == ')');

	if (*input2_end != ')')
	{
	  if (asprintf(errormsg, "Expected ')' at end of address formation, "
			        "got '%c'", *input2_end) == -1)
	    as_fatal ("%s", xstrerror (errno));
	  free(fmt2);
	  free(input2);
	  return 2;
	}

	/* scan back to find the commas */
	while (*fmt2_comma != ',')
	  fmt2_comma--;
	while (*input2_comma != ',' && input2_comma > input2)
	  input2_comma--;
	if (input2_comma == input2)
	{
	  *errormsg = strdup("Couldn't find comma in address formation");
	  free(fmt2);
	  free(input2);
	  return 3;
	}

	/* null out the closing brackets */
	*fmt2_end = '\0';
	*input2_end = '\0';

	/* try and parse the second part */
	if (0 != parse_parameter(input2_comma+1, fmt2_comma+1, insn,
			      opcode, insn_data, fixed_len_insns, errormsg))
	{
	  /* restore the string */
	  *fmt2_end = *input2_end = ')';
	  free(fmt2);
	  free(input2);
	  return 2;
	}

	/* null out the commas */
	*fmt2_comma = *input2_comma = '\0';

	/* try and parse the first part */
	if (0 != parse_parameter(input2, fmt2, insn,
			      opcode, insn_data, fixed_len_insns, errormsg))
	{
	  /* restore the string */
	  *fmt2_end = *input2_end = ')';
	  *fmt2_comma = *input2_comma = ',';
	  free(fmt2);
	  free(input2);
	  return 1;
	}

	free(fmt2);
	free(input2);

	/* we have parsed an address formation successfully! */
	return 0;
      }

      if (*fmt == '%')
      {
	/* compare the entire register name */
	char *fmt_end = fmt + 1;
	char *input_end = input+ 1;

	while (ISALNUM(*fmt_end))
	  fmt_end++;
	while (ISALNUM(*input_end))
	  input_end++;

	if ((fmt_end-fmt) != (input_end-input) ||
	    strncmp(fmt, input, fmt_end-fmt) != 0)
	{
	  if (asprintf(errormsg, "Expected `%.*s', got `%.*s'",
		   (int)(fmt_end-fmt), fmt,
		   (int)(input_end-input), input) == -1)
	    as_fatal ("%s", xstrerror (errno));
	  return 2;
	}

	fmt = fmt_end;
	input = input_end;
	goto start_of_parse_loop;
      }

      /* nothing fancy here - just check that they're closed nicely */
      if (*fmt == '{')
      {
	know (fmt[strlen(fmt) - 1] == '}');
	if (input[strlen(input) - 1] != '}')
	{
	  if (asprintf(errormsg, "Expected closing '}', got '%c'",
			     input[strlen(input) - 1]) == -1)
	    as_fatal ("%s", xstrerror (errno));
	  return 2;
	}
      }
      if (*fmt == '[')
      {
	know (fmt[strlen(fmt) - 1] == ']');
	if (input[strlen(input) - 1] != ']')
	{
	  if (asprintf(errormsg, "Expected closing ']', got '%c'",
			     input[strlen(input) - 1]) == -1)
	    as_fatal ("%s", xstrerror (errno));
	  return 2;
	}
      }

      /* we have tried all special handling of literal characters,
       * so just move on. */
      fmt++;
      input++;
      goto start_of_parse_loop;
    }

    /* *fmt == '%' */
    fmt++;

    /* *fmt == '1' to '9' */
    int arg_num = *fmt - '0' - 1; /* arg_num from 0 to 8 */

    fmt++;

    if (arg_num < 0 || arg_num > 8)
    {
      as_fatal(_("Internal Error: Invalid argument number %d."), arg_num);
    }

    //printf("\n**Argument number %d\n", arg_num);

    /* What is this argument? */
    switch (insn->arg_type[arg_num])
    {
      case General_Reg:
      case Address_Reg:
      case Special_Reg:
      case Break_Reg:
	{
	  enum xap_arg_type t = insn->arg_type[arg_num];
	  char code = (t == General_Reg) ? 'r' :
	    (t == Address_Reg) ? 'a' :
	    (t == Special_Reg) ? 's' :
	    (t == Break_Reg) ? 'b' :
	    '?';

	  mask = get_register(&input, code, 0xff);
	  if (mask < 0)
	  {
	    *errormsg = strdup(get_reg_errcode[-mask]);
	    return 2;
	  }

	  if (! XAP_PUT_VALUE_IN_INSN(opcode, mask, insn->arg_location[arg_num]))
	  {
	    if (! XAP_CHECK_IMMEDIATE_RANGE(FALSE, mask, insn->arg_location[arg_num], insn->arg_range[arg_num]))
	    {
	      *errormsg = strdup("Invalid constant specified");
	      return 1;
	    }
	  }
	  break;
	}

      case Flags_Bit:
	mask = get_flags_bit(&input);
	if (mask < 0)
	{
	  *errormsg = strdup("%flags[bit] : unknown bit");
	  return 1;
	}

	if (! XAP_PUT_VALUE_IN_INSN(opcode, mask, insn->arg_location[arg_num]))
	{
	  if (! XAP_CHECK_IMMEDIATE_RANGE(FALSE, mask, insn->arg_location[arg_num], insn->arg_range[arg_num]))
	  {
	    *errormsg = strdup("Invalid constant specified");
	    return 1;
	  }
	}
	break;

      case Pop_Reglist:
      case Push_Reglist:
	mask = get_reglist_braces(&input,
				  insn->arg_type[arg_num] == Pop_Reglist);

	if (mask < 0)
	{
	  *errormsg = strdup(get_reg_errcode[-mask]);
	  return 2;
	}
	if (! XAP_PUT_VALUE_IN_INSN(opcode, mask, insn->arg_location[arg_num]))
	{
	  if (! XAP_CHECK_IMMEDIATE_RANGE(FALSE, mask, insn->arg_location[arg_num], insn->arg_range[arg_num]))
	  {
	    *errormsg = strdup("Invalid constant specified");
	    return 1;
	  }
	}
	break;

      case Bit_Number:
	/* Instructions are only allowed one relocation so we must
	 * make sure this one does not clobber the address part
	 * of the addr[bit] form instructions
	 */
	mask = get_bitspec(&input);
	if (mask < 0)
	{
	  *errormsg = strdup("Expected bit specifier (0-7)");
	  return 1;
	}
	if (! XAP_PUT_VALUE_IN_INSN(opcode, mask, insn->arg_location[arg_num]))
	{
	  if (! XAP_CHECK_IMMEDIATE_RANGE(FALSE, mask, insn->arg_location[arg_num], insn->arg_range[arg_num]))
	  {
	    *errormsg = strdup("Invalid constant specified");
	    return 1;
	  }
	}
	break;

      case Signed_Immediate_Hex:
      case Signed_Immediate_Offset:
      case Unsigned_Immediate_Hex:
      case Unsigned_Immediate_Dec:
	{
	  const char *expr_start = input;
	  /* Note that if the get_expression() fails, we will still
	     have created U entries in the symbol table for the
	     'symbols' in the input string.  Try not to create U
	     symbols for registers, etc.  */
	  get_expression (&input, insn_data);

	  if (insn_data->exp.X_op == O_absent ||
	      insn_data->exp.X_op == O_illegal)
	  {
	    if (asprintf(errormsg, "Expected expression, got `%.*s'",
		(int)(input-expr_start), expr_start) == -1)
	      as_fatal ("%s", xstrerror (errno));
	    return 2;
	  }

	  /* Check for constants that don't require emitting a reloc.  */
	  if (insn_data->exp.X_op == O_constant
	      && insn_data->exp.X_add_symbol == 0
	      && insn_data->exp.X_op_symbol == 0)
	  {
	    bfd_boolean isSigned =
		insn->arg_type[arg_num] == Signed_Immediate_Hex ||
		insn->arg_type[arg_num] == Signed_Immediate_Offset;
	    if (!XAP_CHECK_IMMEDIATE_RANGE(isSigned, insn_data->exp.X_add_number, insn->arg_location[arg_num], insn->arg_range[arg_num]))
	    {
	      *errormsg = strdup("value outside field range");
	      return 1;
	    }

	    //Install the constant into the instruction
	    XAP_PUT_VALUE_IN_INSN(opcode, insn_data->exp.X_add_number, insn->arg_location[arg_num]);
	  }
	  else
	  {
	    //printf("** %d %d %d %d\n", the_insn.exp.X_op, O_constant, the_insn.exp.X_add_symbol, the_insn.exp.X_op_symbol);
	    if (asprintf(errormsg, "Expected constant, got `%.*s'",
		(int)(input-expr_start), expr_start) == -1)
	      as_fatal ("%s", xstrerror (errno));
	    return 2;
	  }
	  break;
	}

      case Signed_Pcrel_Relocatable_Immediate:
      case Signed_Abs_Relocatable_Immediate:
      case Signed_Gprel_Relocatable_Immediate:
      case Unsigned_Pcrel_Relocatable_Immediate:
      case Unsigned_Abs_Relocatable_Immediate:
	{
	  const char *expr_start = input;
	  /* Relocation type from xapn-opcodes table */
	  insn_data->reloc = insn->relocation_type;
	  /* If it is a fixed length insn, use a non-relaxable relocation.  I
	   * suppose this ought to go in the XML file too...  Also unset
	   * mayrelax in case the argument is an immediate and the relocation
	   * gets removed. */
	  if (fixed_len_insns)
	  {
    	  struct fixed_len_insn* fixed_len_insn = fixed_len_insns;
    	  while (fixed_len_insn->name)
    	  {
        	  if(strcmp(insn->name, fixed_len_insn->name) == 0)
        	  {
        	    insn_data->reloc = fixed_len_insn->reloc;
        	    insn_data->mayrelax = FALSE;
        	  }
        	  fixed_len_insn++;
    	  }
	  }

	  /* Note that if the get_expression() fails, we will still
	     have created U entries in the symbol table for the
	     'symbols' in the input string.  Try not to create U
	     symbols for registers, etc.  */
	  get_expression (&input, insn_data);

	  if (insn_data->exp.X_op == O_absent ||
	      insn_data->exp.X_op == O_illegal)
	  {
	    if (asprintf(errormsg, "Expected expression, got `%.*s'",
		(int)(input-expr_start), expr_start) == -1)
	      as_fatal ("%s", xstrerror (errno));
	    return 2;
	  }

	  /* Check for constants that don't require emitting a reloc.  */
	  if (insn_data->exp.X_op == O_constant
	      && insn_data->exp.X_add_symbol == 0
	      && insn_data->exp.X_op_symbol == 0)
	  {
	    /* If the number entered by the user is unsigned and positive, sign extend to
	       32 bits, using the length of the field in the instruction that the immediate will go into
	       CSEXT will only sign-extend if the bits being sign-extended into are clear
	       --Only sign extend if the immediate is signed
	       */
	    unsigned int number = insn_data->exp.X_add_number;
	    if (insn->reloc_num_bits > 0 &&
		(insn->arg_type[arg_num] == Signed_Pcrel_Relocatable_Immediate ||
		 insn->arg_type[arg_num] == Signed_Abs_Relocatable_Immediate))
	    {
	      number = CSEXT(number, insn->reloc_num_bits - 1);
	    }

	    /* fixup_insn assumes that values are sign-extended correctly */
	    if (!fixup_insn(opcode, insn_data->reloc, number, 0, FALSE))
	    {
	      *errormsg = strdup("value outside field range");
	      return 1;
	    }

	    /* Remove the relocation, because it is now fixed up.  We used to retain
	       PC-relative relocations here, only to remove them anyway in md_assemble!
	       This way avoids much convoluted logic and seems to accomplish the same
	       thing. */
	    insn_data->reloc = BFD_RELOC_NONE;
	  }
	  break;
	}

      default:
	{
	  /*invalid argument type*/
	  as_fatal(_("Invalid argument type %d."), insn->relocation_type);
	}
    } /* end switch */
  }

  if (*input != '\0')
  {
    if (asprintf(errormsg, "Extraneous data at end of input: `%s'", input) == -1)
      as_fatal ("%s", xstrerror (errno));
    return 1;
  }

  return 0;
}

/* FIXME: potential buffer overflow for extremely long formats. these should
 * never exist, though. */

static char pretty_format[512];

static char *
pretty_print_format (const char *fmt, const xap_opcode_t *insn, int num_brk_regs)
{
  char *p = pretty_format;

  while (*fmt != '\0')
  {
    if (! (fmt[0] == '%' && '1' <= fmt[1] && fmt[1] <= '9'))
    {
      /* literal character */
      *p++ = *fmt++;
      continue;
    }

    int arg_num = fmt[1] - '1';

    fmt += 2;

    switch (insn->arg_type[arg_num])
    {
    case General_Reg:
      p += sprintf(p, "%%r[0-7]");
      break;
    case Special_Reg:
      p += sprintf(p, "<special register>");
      break;
    case Address_Reg:
      p += sprintf(p, "<address register>");
      break;
    case Break_Reg:
      p += sprintf(p, "%%brk[0-%d]", num_brk_regs-1);
      break;
    case Flags_Bit:
      p += sprintf(p, "bit");
      break;
    case Pop_Reglist:
      p += sprintf(p, "{increasing reglist}");
      break;
    case Push_Reglist:
      p += sprintf(p, "{decreasing reglist}");
      break;
    case Bit_Number:
      p += sprintf(p, "0-7");
      break;
    case Signed_Immediate_Hex:
    case Signed_Immediate_Offset:
    case Unsigned_Immediate_Hex:
    case Unsigned_Immediate_Dec:
      p += sprintf(p, "<constant>");
      break;
    case Signed_Abs_Relocatable_Immediate:
    case Unsigned_Abs_Relocatable_Immediate:
    case Signed_Gprel_Relocatable_Immediate:
    case Signed_Pcrel_Relocatable_Immediate:
    case Unsigned_Pcrel_Relocatable_Immediate:
      p += sprintf(p, "<label>");
      break;
    default:
      as_fatal(_("Unknown argument type"));
    }
  }

  *p = '\0';

  return pretty_format;
}

/* Subroutine of md_assemble to do the actual parsing.  */
/* AM: oddly, xapN_ip does not return a value saying whether an opcode   */
/* was found, so an old value of the_insn may be read by caller.        */
/* However since as_bad will have been called in this case, no output   */
/* file will get produced, so no problem.  Hmm.                         */

void
xap_parse_ip (char *str, struct hash_control * op_hash, struct xap_it* the_insn, struct fixed_len_insn* fixed_len_insns, int num_brk_regs, unsigned invalid_iflags)
{
  char *s;
  int c, i, par;

  char parameters[5][1024];
  int nparameters;

  xap_opcode_t *insns;
  int ninsns;

  /* results of parsing */
  bfd_boolean valid[MAX_FORMS];
  int distance[MAX_FORMS][5];
  char *(errormsg[MAX_FORMS][5]);

  /* instructions created by each parse */
  opcode_t opcode[MAX_FORMS];
  struct xap_it insn_data[MAX_FORMS];

  if (strlen(str) + 1 >= MAX_LINE_LEN)
  {
    as_bad(_("Parse error: line is too long"));
    return;
  }

  /* The next line needs to recognise "A-Za-z0-9._" but scanning all    */
  /* printable chars can only help error messages.                      */
  for (s = str; ISPRINT ((unsigned char) *s) && *s != ' '; ++s)
    ;

  switch (*s)
    {
    case '\0':
      break;

    case ' ':
      *s++ = '\0';
      break;

    default:
      c = *s;
      *s++ = '\0';
      as_bad (_("Unprintable char in opcode: `%s\\x%.2x'"), str, (unsigned char)c);
      return;
    }
  insns = (xap_opcode_t *) hash_find (op_hash, str);
  if (insns == NULL)
    {
      as_bad (_("Unknown opcode: `%s'"), str);
      return;
    }

  ninsns = 1;
  while (ninsns + (insns - XAP_OPCODES) < XAP_NUM_OPCODES
	&& strcmp(insns[0].name, insns[ninsns].name) == 0)
    ninsns++;

  if (ninsns > MAX_FORMS)
    as_fatal(_("Internal error: too many encodings for `%s'"), insns[0].name);

  if (!split_parameter_list(s, parameters, &nparameters))
    return;

  for (i=0; i<ninsns; i++)
  {
    valid[i] = TRUE;
    if (nparameters != insns[i].nparameters)
      valid[i] = FALSE;
    if (insns[i].iflags & invalid_iflags)
      valid[i] = FALSE;

    opcode[i] = insns[i].match;
    memset (&insn_data[i], 0, sizeof (insn_data[i]));
    insn_data[i].i_subtype = 0;
    insn_data[i].reloc = BFD_RELOC_NONE;
    insn_data[i].mayrelax = TRUE;

    for (par=0; par<insns[i].nparameters; par++)
    {
      distance[i][par] = 0;
      errormsg[i][par] = NULL;
    }
  }

  {
    bfd_boolean all_invalid = TRUE;
    for (i=0; i<ninsns; i++)
      if (valid[i])
	all_invalid = FALSE;
    if (all_invalid)
    {
      as_bad(_("No forms of `%s' have %d parameter%s"),
	     insns[0].name, nparameters, nparameters == 1 ? "" : "s");
      return;
    }
  }

  for (par=0; par<nparameters; par++)
  {
    for (i=0; i<ninsns; i++)
    {
      if (!valid[i])
	continue;

      distance[i][par] = parse_parameter(parameters[par],
				       insns[i].parameters[par], &insns[i],
				       &opcode[i], &insn_data[i], fixed_len_insns,
				       &errormsg[i][par]);
    }
  }

  int best_insn = -1;
  int best_distance = 1000;
  bfd_boolean ambiguous = FALSE;

  for (i=0; i<ninsns; i++)
  {
    int total_distance = 0;

    if (!valid[i]) /* ignore encodings with different number of args */
      continue;

    for (par=0; par<nparameters; par++)
      total_distance += distance[i][par];

    if (total_distance == best_distance)
      ambiguous = TRUE;
    else if (total_distance < best_distance)
    {
      best_distance = total_distance;
      best_insn = i;
      ambiguous = FALSE;
    }
  }

  if (best_distance > 0)
  {
    for (par=0; par<nparameters; par++)
    {
      if (0 == distance[best_insn][par])
	continue;

      as_bad(_("Error parsing `%s':"), parameters[par]);
      if (errormsg[best_insn][par] == NULL)
	as_bad(_(" Closest format: `%s'"),
	       pretty_print_format(insns[best_insn].parameters[par],
			           &insns[best_insn], num_brk_regs));
      else
	as_bad(_(" Closest format: `%s': %s"),
	       pretty_print_format(insns[best_insn].parameters[par],
				   &insns[best_insn], num_brk_regs),
	       errormsg[best_insn][par]);
    }
  }
  else
  {
    if (ambiguous)
    {
      as_bad(_("Ambiguous parse!"));
      as_bad(_(" This is extremely bad! Please report this bug!"));
      as_bad(_(" Mnemonic: %s"), insns[0].name);
      as_bad(_(" Valid parses:"));
      for (par=0; par<nparameters; par++)
      {
	as_bad(_(" Parameter %d: '%s'"), par, parameters[par]);
	for (i=0; i<ninsns; i++)
	{
	  as_bad(_("  Form %d: '%s': %s"), i,
	      pretty_print_format(insns[i].parameters[par], &insns[i], num_brk_regs),
	      distance[i][par] == 0 ? "success" : "FAIL");
	}
      }
    }
    else
    {
      if (the_insn)
      {
          *the_insn = insn_data[best_insn];
          the_insn->opcode = opcode[best_insn];
      }
    }
  }

  for (i=0; i<ninsns; i++)
    for (par=0; par<nparameters; par++)
      if (errormsg[i][par] != NULL)
	free(errormsg[i][par]);
}

#endif /* defined TC_XAP4 | TC_XAP5 | TC_XAP6 */
