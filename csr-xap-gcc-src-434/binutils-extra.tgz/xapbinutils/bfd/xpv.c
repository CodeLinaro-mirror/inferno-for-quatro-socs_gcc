/* BFD back-end for XPV/XDV/XUV files.
   Copyright 1995, 1996, 1998, 1999, 2000, 2001, 2002, 2003
   Free Software Foundation, Inc.
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com
   
   Written by Peter Lloyd, modified from Intel Hex back-end
   Intel Hex back-end written by Ian Lance Taylor of Cygnus Support <ian@cygnus.com>.
   

   This file is part of BFD, the Binary File Descriptor library.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/***********************************************************
 * STATUS : XPV/XDV file generation tested.
            XPV/XDV file reading UNTESTED (and known to have issues eg comments not understood)
 */

#include "bfd.h"
#include "sysdep.h"
#include "libbfd.h"
#include "libiberty.h"
#include "safe-ctype.h"

static void xpv_init
  PARAMS ((void));
static bfd_boolean xpv_mkobject
  PARAMS ((bfd *));
static INLINE int xpv_get_byte
  PARAMS ((bfd *, bfd_boolean *));
static void xpv_bad_byte
  PARAMS ((bfd *, unsigned int, int, bfd_boolean));
static bfd_boolean xpv_scan
  PARAMS ((bfd *));
static const bfd_target *xpv_object_p
  PARAMS ((bfd *));
static bfd_boolean xpv_read_section
  PARAMS ((bfd *, asection *, bfd_byte *));
static bfd_boolean xpv_get_section_contents
  PARAMS ((bfd *, asection *, PTR, file_ptr, bfd_size_type));
static bfd_boolean xpv_set_section_contents
  PARAMS ((bfd *, asection *, const PTR, file_ptr, bfd_size_type));
static bfd_boolean xdv_set_section_contents
  PARAMS ((bfd *, asection *, const PTR, file_ptr, bfd_size_type));
static bfd_boolean xuv_set_section_contents
  PARAMS ((bfd *, asection *, const PTR, file_ptr, bfd_size_type));
static bfd_boolean xpv_set_section_contents_common
  PARAMS ((bfd *, asection *, const PTR, file_ptr, bfd_size_type));
static bfd_boolean xpv_write_record
  PARAMS ((bfd *, unsigned int, bfd_byte *, bfd_boolean, bfd_boolean));
static bfd_boolean xpv_xdv_write_object_contents
  PARAMS ((bfd *));
static bfd_boolean xuv_write_object_contents
  PARAMS ((bfd *));
static bfd_boolean xpv_set_arch_mach
  PARAMS ((bfd *, enum bfd_architecture, unsigned long));
static bfd_boolean xdv_set_arch_mach
  PARAMS ((bfd *, enum bfd_architecture, unsigned long));
static bfd_boolean xuv_set_arch_mach
  PARAMS ((bfd *, enum bfd_architecture, unsigned long));
static int xpv_sizeof_headers
  PARAMS ((bfd *, bfd_boolean));

/* Number of bytes of address and data */
  
#define ADDRESS_BYTES 6
#define DATA_BYTES 4
  
/* Macros for converting between hex and binary.  */

#define NIBBLE(x)    (hex_value (x))
#define HEX2(buffer) ((NIBBLE ((buffer)[0]) << 4) + NIBBLE ((buffer)[1]))
#define HEX4(buffer) ((HEX2 (buffer) << 8) + HEX2 ((buffer) + 2))
#define HEX6(buffer) ((HEX2 (buffer) << 16) + (HEX2 ((buffer) + 2) << 8) + HEX2 ((buffer) + 4))
#define ISHEX(x)     (hex_p (x))

/* When we write out an xpv file, the values can not be output as
   they are seen.  Instead, we hold them in memory in this structure.  */

struct xpv_data_list
{
  struct xpv_data_list *next;
  bfd_byte *data;
  bfd_vma where;
  bfd_size_type size;
};

/* The xpv tdata information.  */

struct xpv_data_struct
{
  struct xpv_data_list *head;
  struct xpv_data_list *tail;
};

/* Range element for xuv file sanity checking. Used to test for
 * address overlap when generating an XUV file.
 */
struct xuv_addr_range
{
  unsigned int start;
  unsigned int end;
};

/* The number of bytes per line of XPV file. */
unsigned int xpv_bytes_per_line = 2;
/* Initialize by filling in the hex conversion array.  */

static void
xpv_init ()
{
  static bfd_boolean inited;

  if (! inited)
    {
      inited = TRUE;
      hex_init ();
    }
}

/* Create an xpv object.  */

static bfd_boolean
xpv_mkobject (abfd)
     bfd *abfd;
{
  struct xpv_data_struct *tdata;
  bfd_size_type amt = sizeof (struct xpv_data_struct);

  tdata = (struct xpv_data_struct *) bfd_alloc (abfd, amt);
  if (tdata == NULL)
    return FALSE;

  abfd->tdata.xpv_data = tdata;
  tdata->head = NULL;
  tdata->tail = NULL;
  return TRUE;
}

/* Read a byte from a BFD.  Set *ERRORPTR if an error occurred.
   Return EOF on error or end of file.  */

static INLINE int
xpv_get_byte (abfd, errorptr)
     bfd *abfd;
     bfd_boolean *errorptr;
{
  bfd_byte c;

  if (bfd_bread (&c, (bfd_size_type) 1, abfd) != 1)
    {
      if (bfd_get_error () != bfd_error_file_truncated)
	*errorptr = TRUE;
      return EOF;
    }

  return (int) (c & 0xff);
}

/* Report a problem in an XPV file.  */

static void
xpv_bad_byte (abfd, lineno, c, error)
     bfd *abfd;
     unsigned int lineno;
     int c;
     bfd_boolean error;
{
  if (c == EOF)
    {
      if (! error)
	bfd_set_error (bfd_error_file_truncated);
    }
  else
    {
      char buf[10];

      if (! ISPRINT (c))
	sprintf (buf, "\\%03o", (unsigned int) c);
      else
	{
	  buf[0] = c;
	  buf[1] = '\0';
	}
      (*_bfd_error_handler)
	(_("%B:%d: unexpected character `%s' in XPV file\n"),
	 abfd, lineno, buf);
      bfd_set_error (bfd_error_bad_value);
    }
}

/* Read a XPV file and turn it into sections.  We create a new
   section for each contiguous set of bytes.  */

static bfd_boolean
xpv_scan (abfd)
     bfd *abfd;
{
  asection *sec;
  unsigned int lineno;
  bfd_boolean error;
  int c;
  
  bfd_vma last_addr = 0;

  if (bfd_seek (abfd, (file_ptr) 0, SEEK_SET) != 0)
    goto error_return;

  abfd->start_address = 0;

  sec = NULL;
  lineno = 1;
  error = FALSE;

  while ((c = xpv_get_byte (abfd, &error)) != EOF)
  {
    if (c == '\r')
	  continue;
    else if (c == '\n')
	{
	  ++lineno;
	  continue;
	}
    else if (c != '@')
	{
	  xpv_bad_byte (abfd, lineno, c, error);
	  goto error_return;
	}
      else
    {
	  file_ptr pos;
	  char adr[ADDRESS_BYTES];
	  char dat[DATA_BYTES];
	  unsigned int i;
	  bfd_vma addr;

	  /* This is a data record.  */
	  pos = bfd_tell (abfd) - 1;

	  /* Read the address bytes.  */
	  if (bfd_bread (adr, (bfd_size_type) ADDRESS_BYTES, abfd) != ADDRESS_BYTES)
	    goto error_return;

	  for (i = 0; i < ADDRESS_BYTES; i++)
	  {
	      if (! ISHEX (adr[i]))
	      {
		     xpv_bad_byte (abfd, lineno, adr[i], error);
		     goto error_return;
		  }
	  }

	  addr = HEX6 (adr);
	  
      /* Chomp all whitespace */
	  c = xpv_get_byte (abfd, &error);
	  if (c == EOF)
	     goto error_return;
	  if (c != ' ')
	  {
	      xpv_bad_byte (abfd, lineno, c, error);
	      goto error_return;
	  }
	  
	  do
	  {
          c = xpv_get_byte (abfd, &error);
          if (c == EOF)
             goto error_return;
      }
      while (c == ' ');
      
      //At this stage, c contains the first non-whitespace byte
      dat[0] = c;
      
	  /* Read the data bytes. (Starting at dat[1] and reading one less than we should) */
	  if (bfd_bread (dat + 1, (bfd_size_type) DATA_BYTES - 1, abfd) != (DATA_BYTES - 1))
	    goto error_return;

	  for (i = 0; i < DATA_BYTES; i++)
	  {
	      if (! ISHEX (dat[i]))
		  {
		  xpv_bad_byte (abfd, lineno, dat[i], error);
		  goto error_return;
		  }
	  } 
	  
	  if (sec != NULL && (last_addr = 0 || last_addr == addr + 1))
	  {
		  /* This data goes at the end of the section we are
             currently building.  */
		  sec->rawsize += 2;
	  }
	  else
	  {
		  //Make a new section
    	  char secbuf[20];
		  char *secname;
		  bfd_size_type amt;
		  
		  bfd_vma section_start_addr = addr;

		  sprintf (secbuf, ".sec%d", bfd_count_sections (abfd) + 1);
		  amt = strlen (secbuf) + 1;
		  secname = (char *) bfd_alloc (abfd, amt);
		  if (secname == NULL)
		    goto error_return;
		  strcpy (secname, secbuf);
		  sec = bfd_make_section (abfd, secname);
		  if (sec == NULL)
		    goto error_return;
		  sec->flags = SEC_HAS_CONTENTS | SEC_LOAD | SEC_ALLOC;
		  sec->vma = section_start_addr;
		  sec->lma = section_start_addr;
		  sec->rawsize = 2;
		  sec->filepos = pos;
	  }
      last_addr = addr;
     //abfd->start_address = addr; ????
	      
    }
  } //End while()

  if (error)
    goto error_return;

  return TRUE;

 error_return:
  return FALSE;
}

/* Try to recognize an XPV file.  */

static const bfd_target *
xpv_object_p (abfd)
     bfd *abfd;
{
  PTR tdata_save;
  bfd_byte b[9];
  unsigned int i;

  xpv_init ();

  if (bfd_seek (abfd, (file_ptr) 0, SEEK_SET) != 0)
    return NULL;
  if (bfd_bread (b, (bfd_size_type) 8, abfd) != 8)
    {
      if (bfd_get_error () == bfd_error_file_truncated)
	bfd_set_error (bfd_error_wrong_format);
      return NULL;
    }

  if (b[0] != '@')
    {
      bfd_set_error (bfd_error_wrong_format);
      return NULL;
    }

  for (i = 1; i < 7; i++)
    {
      if (! ISHEX (b[i]))
	{
	  bfd_set_error (bfd_error_wrong_format);
	  return NULL;
	}
    }
    
  if (b[7] != ' ')
    {
      bfd_set_error (bfd_error_wrong_format);
      return NULL;
    }

  /* OK, it looks like it really is an XPV file.  */
  tdata_save = abfd->tdata.any;
  if (! xpv_mkobject (abfd) || ! xpv_scan (abfd))
    {
      if (abfd->tdata.any != tdata_save && abfd->tdata.any != NULL)
	bfd_release (abfd, abfd->tdata.any);
      abfd->tdata.any = tdata_save;
      return NULL;
    }

  return abfd->xvec;
}

/* Read the contents of a section in an XPV file.  */

static bfd_boolean
xpv_read_section (abfd, section, contents)
     bfd *abfd;
     asection *section;
     bfd_byte *contents;  //Contents is alloc'ed to be rawsize bytes long
{
  int c;
  bfd_byte *p;
  bfd_boolean error;

  if (bfd_seek (abfd, section->filepos, SEEK_SET) != 0)
    goto error_return;

  p = contents;
  error = FALSE;
  while ((c = xpv_get_byte (abfd, &error)) != EOF)
    {
      char adr[ADDRESS_BYTES];
      char dat[DATA_BYTES];
      bfd_vma addr;

      if (c == '\r' || c == '\n')
          continue;

      /* This is called after xpv_scan has succeeded, so we ought to
         know the exact format.  */
      BFD_ASSERT (c == '@');

      if (bfd_bread (adr, (bfd_size_type) ADDRESS_BYTES, abfd) != ADDRESS_BYTES)
          goto error_return;

      addr = HEX6 (adr);
      
      /* Chomp all whitespace */
	  do
	  {
          c = xpv_get_byte (abfd, &error);
          if (c == EOF)
             goto error_return;
      }
      while (c == ' ');

      //At this stage, c contains the first non-whitespace byte
      dat[0] = c;
      
      /* Read the data bytes. (Starting at dat[1] and reading one less than we should) */
	  if (bfd_bread (dat + 1, (bfd_size_type) DATA_BYTES - 1, abfd) != (DATA_BYTES - 1))
	    goto error_return;

      *p++ = HEX2 (dat);
      *p++ = HEX2 (dat + 2); //TODO check endianness
      
      if ((bfd_size_type) (p - contents) >= section->rawsize)
	  {
    	  /* We've read everything in the section.  */
    	  return TRUE;
	  }
  }

  if ((bfd_size_type) (p - contents) < section->rawsize)
    {
      (*_bfd_error_handler)
	(_("%B: bad section length in xpv_read_section"), abfd);
      bfd_set_error (bfd_error_bad_value);
      goto error_return;
    }

  return TRUE;

 error_return:
  return FALSE;
}

/* Get the contents of a section in an XPV file.  */

static bfd_boolean
xpv_get_section_contents (abfd, section, location, offset, count)
     bfd *abfd;
     asection *section;
     PTR location;
     file_ptr offset;
     bfd_size_type count;
{
  if (section->used_by_bfd == NULL)
    {
      section->used_by_bfd = bfd_alloc (abfd, section->rawsize);
      if (section->used_by_bfd == NULL)
	return FALSE;
      if (! xpv_read_section (abfd, section, section->used_by_bfd))
	return FALSE;
    }

  memcpy (location, (bfd_byte *) section->used_by_bfd + offset,
	  (size_t) count);

  return TRUE;
}

/* Set the contents of a section in an XPV file.  */

static bfd_boolean
xpv_set_section_contents (abfd, section, location, offset, count)
     bfd *abfd;
     asection *section;
     const PTR location;
     file_ptr offset;
     bfd_size_type count;
{
    if (count == 0
      || (section->flags & SEC_CODE) == 0) //Code segments only
    return TRUE;
    
    return xpv_set_section_contents_common(abfd, section, location, offset, count);
}

static bfd_boolean
xdv_set_section_contents (abfd, section, location, offset, count)
     bfd *abfd;
     asection *section;
     const PTR location;
     file_ptr offset;
     bfd_size_type count;
{
    if (count == 0 || (section->flags & SEC_CODE) != 0) //Data segments only
    return TRUE;
    
    /*printf("Processing section %s, location %x offset %x count %x\n", section->name, location, offset, count);*/

    return xpv_set_section_contents_common(abfd, section, location, offset, count);
}

static bfd_boolean
xuv_set_section_contents (abfd, section, location, offset, count)
     bfd *abfd;
     asection *section;
     const PTR location;
     file_ptr offset;
     bfd_size_type count;
{
    if (count == 0) return TRUE; 
    return xpv_set_section_contents_common(abfd, section, location, offset, count);
}

static bfd_boolean
xpv_set_section_contents_common (abfd, section, location, offset, count)
     bfd *abfd;
     asection *section;
     const PTR location;
     file_ptr offset;
     bfd_size_type count;
{
  struct xpv_data_list *n;
  bfd_byte *data;
  struct xpv_data_struct *tdata;
  bfd_size_type amt;
  const bfd_vma code_bit_mask = ~(0x80000000);

  if (count == 0
      || (section->flags & SEC_ALLOC) == 0
      || (section->flags & SEC_LOAD) == 0)
    return TRUE;

  amt = sizeof (struct xpv_data_list);
  n = (struct xpv_data_list *) bfd_alloc (abfd, amt);
  if (n == NULL)
    return FALSE;

  data = (bfd_byte *) bfd_alloc (abfd, count);
  if (data == NULL)
    return FALSE;
  memcpy (data, location, (size_t) count);

  n->data = data;
  /*printf("VMA %x, LMA %x, Addr %x, Offset %x\n", section->vma, section->lma, offset);*/
  n->where = section->lma + offset;
  n->size = count;

  /* Sort the records by address.  Optimize for the common case of
     adding a record to the end of the list. For sorting purposes,
     ignore the top bit of the address (code addresses will tend to
     have the top bit set, which won't be true in the final run-time
     address. */
  tdata = abfd->tdata.xpv_data;
  if (tdata->tail != NULL
      && (n->where & code_bit_mask) >= (tdata->tail->where & code_bit_mask))
    {
      tdata->tail->next = n;
      n->next = NULL;
      tdata->tail = n;
    }
  else
    {
      register struct xpv_data_list **pp;

      for (pp = &tdata->head;
	   *pp != NULL && ((*pp)->where & code_bit_mask) < (n->where & code_bit_mask);
	   pp = &(*pp)->next)
	;
      n->next = *pp;
      *pp = n;
      if (n->next == NULL)
	tdata->tail = n;
    }

  return TRUE;
}

/* Write a record out to an XPV, XDV or XUV file.  */

static bfd_boolean
xpv_write_record (bfd* abfd, unsigned int addr, bfd_byte* data, bfd_boolean isCode, bfd_boolean checkAddrRange)
{
    /* @aaaaaaaa dd...\r\n */
    static const char digs[] = "0123456789ABCDEF";
    char buf[20];
    char* pBuf = buf;
    int byte_num;
    /* this should call bfd_arch_bits_per_address(abfd) */
    int address_bits = (isCode ? 24 : 16);
  
    if (checkAddrRange && (addr >> address_bits) != 0)
    {
        char err_buf[20];
        
        sprintf_vma (err_buf, (unsigned long)addr);
        (*_bfd_error_handler)
        (_("%s: address 0x%s out of range for %s file"),
        bfd_get_filename (abfd), err_buf, (isCode ? "XPV" : "XDV"));
        bfd_set_error (bfd_error_bad_value);
        return FALSE;
    }

    *pBuf++ = '@';

    /* Address */
    for (byte_num = address_bits - 4; byte_num >= 0 ; byte_num -= 4)
    {
        *pBuf++ = digs[(addr >> byte_num) & 0xf];
    }

    /* Three spaces */
    strcpy(pBuf, "   ");
    pBuf += 3;

    for (byte_num = 0; byte_num < (int) xpv_bytes_per_line; byte_num++)
    {
        /* big endian */
        bfd_byte data_byte = data[byte_num];
        *pBuf++ = digs[(data_byte >> 4) & 0xf];
        *pBuf++ = digs[(data_byte     ) & 0xf];
    }

    /* Newline */
    strcpy(pBuf, "\r\n");
    pBuf += 2;

    *pBuf = '\0';

    {
        size_t total = pBuf - buf;
        if (bfd_bwrite (buf, (bfd_size_type) total, abfd) != total)
            return FALSE;
    }

    return TRUE;
}

/* Write out an XPV or XDV file.  */

static bfd_boolean
xpv_xdv_write_object_contents (abfd)
     bfd *abfd;
{
    struct xpv_data_list *l;

    for (l = abfd->tdata.xpv_data->head; l != NULL; l = l->next)
    {
        bfd_vma address;
        bfd_byte *p;
        bfd_size_type count;
        bfd_boolean isCode;

        address = l->where;
        p = l->data;
        count = l->size;

        isCode = ((address & 0x80000000) != 0);
        if (isCode)
        {
            //Code addresses have top bit set
            address &= 0x7fffffff;
        }

        if (count % 2 != 0)
        {
            (*_bfd_error_handler)
              (_("%s: odd number of bytes found in source data"),
               bfd_get_filename (abfd));
               bfd_set_error (bfd_error_bad_value);
            return FALSE;
        }

        while (count > 0)
        {
            //TODO CHECK IF NEED TO ADD abfd->start_address to address
            if (! xpv_write_record (abfd, (unsigned int)(address), p, isCode, TRUE /* distinguish between code and data */))
                return FALSE;
            
            address++;
            p += 2;
            count -= 2;
        }
    }
    
    return TRUE;
}

/* Write out an XUV file.  */

static bfd_boolean
xuv_write_object_contents (abfd)
     bfd *abfd;
{
    struct xpv_data_list *l;
    struct xuv_addr_range *addr_ranges;
    int max_ranges = 0;
    int active_ranges = 0;

    /* Create one address range element per section */ 
    for (l = abfd->tdata.xpv_data->head; l != NULL; l = l->next)
    {
         max_ranges++;
    }
    addr_ranges = (struct xuv_addr_range *)bfd_malloc(max_ranges * sizeof(struct xuv_addr_range)); 
    if (addr_ranges == NULL)
    {
        (*_bfd_error_handler)
          (_("%s: allocation failure"),
          bfd_get_filename (abfd));
        bfd_set_error (bfd_error_no_memory);
        return FALSE;
    }

    for (l = abfd->tdata.xpv_data->head; l != NULL; l = l->next)
    {
        bfd_vma address;
        bfd_byte *p;
        bfd_size_type count;
        bfd_boolean isCode;
        int i;
        unsigned int new_range_start, new_range_end;

        address = l->where;
        p = l->data;
        count = l->size;

        isCode = ((address & 0x80000000) != 0);
        if (isCode)
        {
            //Code addresses have top bit set
            address &= 0x7fffffff;
        }

        if (count % 2 != 0)
        {
            (*_bfd_error_handler)
              (_("%s: odd number of bytes found in source data"),
               bfd_get_filename (abfd));
               bfd_set_error (bfd_error_bad_value);
            return FALSE;
        }

        /* Check this address range doesn't overlap with any we've
         * previously seen. If not, or we haven't seen any ranges at
         * all yet, then insert the range into the address range array.
         */
        new_range_start = address;
        new_range_end   = address + (count / 2) - 1;
        if (active_ranges == 0)
        {
            addr_ranges[active_ranges].start = new_range_start;
            addr_ranges[active_ranges].end   = new_range_end;
            active_ranges++;
        }
        else
        {
            for (i = 0; i < active_ranges; i++)
            {
                unsigned int existing_range_start = addr_ranges[i].start;
                unsigned int existing_range_end   = addr_ranges[i].end;
                if (   (new_range_start <= existing_range_start && new_range_end >= existing_range_start)
                    || (new_range_start >= existing_range_start && new_range_start <= existing_range_end))
                {
                    (*_bfd_error_handler)
                      (_("%s: address overlap detected. Check code and data section addresses."),
                      bfd_get_filename (abfd));
                    bfd_set_error (bfd_error_bad_value);
                    return FALSE;
                }
            }
            addr_ranges[active_ranges].start = new_range_start;
            addr_ranges[active_ranges].end   = new_range_end;
            active_ranges++;
        }

        while (count > 0)
        {
            //TODO CHECK IF NEED TO ADD abfd->start_address to address
            if (! xpv_write_record (abfd, (unsigned int)(address), p, 
                                    TRUE  /* treat everything as code (i.e. 6 bytes for addresses) */, 
                                    FALSE /* and don't care about address range checking */))
                return FALSE;

            address++;
            p += 2;
            count -= 2;
        }
    }

    free(addr_ranges);

    return TRUE;
}

/* Set the architecture for the output file.  The architecture is
   irrelevant, so we ignore errors about unknown architectures.  */

static bfd_boolean
xpv_set_arch_mach (abfd, arch, mach)
     bfd *abfd;
     enum bfd_architecture arch;
     unsigned long mach;
{
  if (! bfd_default_set_arch_mach (abfd, arch, mach))
    {
      if (arch != bfd_arch_unknown)
	return FALSE;
    }
  return TRUE;
}

static bfd_boolean
xdv_set_arch_mach (abfd, arch, mach)
     bfd *abfd;
     enum bfd_architecture arch;
     unsigned long mach;
{
  return xpv_set_arch_mach (abfd, arch, mach);
}

static bfd_boolean
xuv_set_arch_mach (abfd, arch, mach)
     bfd *abfd;
     enum bfd_architecture arch;
     unsigned long mach;
{
    return xpv_set_arch_mach (abfd, arch, mach);
}

/* Get the size of the headers, for the linker.  */

static int
xpv_sizeof_headers (abfd, exec)
     bfd *abfd ATTRIBUTE_UNUSED;
     bfd_boolean exec ATTRIBUTE_UNUSED;
{
  return 0;
}

/* Some random definitions for the target vector.  */

#define	xpv_close_and_cleanup _bfd_generic_close_and_cleanup
#define xpv_bfd_free_cached_info _bfd_generic_bfd_free_cached_info
#define xpv_new_section_hook _bfd_generic_new_section_hook
#define xpv_get_section_contents_in_window \
  _bfd_generic_get_section_contents_in_window

#define xpv_get_symtab_upper_bound bfd_0l
#define xpv_canonicalize_symtab \
  ((long (*) PARAMS ((bfd *, asymbol **))) bfd_0l)
#define xpv_make_empty_symbol _bfd_generic_make_empty_symbol
#define xpv_print_symbol _bfd_nosymbols_print_symbol
#define xpv_get_symbol_info _bfd_nosymbols_get_symbol_info
#define xpv_bfd_is_local_label_name _bfd_nosymbols_bfd_is_local_label_name
#define xpv_bfd_is_target_special_symbol _bfd_nosymbols_bfd_is_target_special_symbol
#define xpv_get_lineno _bfd_nosymbols_get_lineno
#define xpv_find_nearest_line _bfd_nosymbols_find_nearest_line
#define xpv_find_inliner_info _bfd_nosymbols_find_inliner_info
#define xpv_bfd_make_debug_symbol _bfd_nosymbols_bfd_make_debug_symbol
#define xpv_read_minisymbols _bfd_nosymbols_read_minisymbols
#define xpv_minisymbol_to_symbol _bfd_nosymbols_minisymbol_to_symbol

#define xpv_get_reloc_upper_bound \
  ((long (*) PARAMS ((bfd *, asection *))) bfd_0l)
#define xpv_canonicalize_reloc \
  ((long (*) PARAMS ((bfd *, asection *, arelent **, asymbol **))) bfd_0l)
#define xpv_bfd_reloc_type_lookup _bfd_norelocs_bfd_reloc_type_lookup

#define xpv_bfd_get_relocated_section_contents \
  bfd_generic_get_relocated_section_contents
#define xpv_bfd_relax_section bfd_generic_relax_section
#define xpv_bfd_gc_sections bfd_generic_gc_sections
#define xpv_bfd_merge_sections bfd_generic_merge_sections
#define xpv_bfd_is_group_section bfd_generic_is_group_section
#define xpv_bfd_discard_group bfd_generic_discard_group
#define xpv_section_already_linked _bfd_generic_section_already_linked
#define xpv_bfd_link_hash_table_create _bfd_generic_link_hash_table_create
#define xpv_bfd_link_hash_table_free _bfd_generic_link_hash_table_free
#define xpv_bfd_link_add_symbols _bfd_generic_link_add_symbols
#define xpv_bfd_link_just_syms _bfd_generic_link_just_syms
#define xpv_bfd_final_link _bfd_generic_final_link
#define xpv_bfd_link_split_section _bfd_generic_link_split_section

/* The XPV target vector.  */

const bfd_target xpv_vec =
{
  "xpv",			/* name */
  bfd_target_xpv_flavour,
  BFD_ENDIAN_UNKNOWN,		/* target byte order */
  BFD_ENDIAN_UNKNOWN,		/* target headers byte order */
  EXEC_P,			/* object_flags */
  (SEC_ALLOC | SEC_LOAD | SEC_READONLY | SEC_CODE
   | SEC_ROM | SEC_HAS_CONTENTS), /* section_flags */
  0,				/* leading underscore */
  ' ',				/* ar_pad_char */
  16,				/* ar_max_namelen */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,	/* data */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,	/* hdrs */

  {
    _bfd_dummy_target,
    xpv_object_p,		/* bfd_check_format */
    _bfd_dummy_target,
    _bfd_dummy_target,
  },
  {
    bfd_false,
    xpv_mkobject,
    _bfd_generic_mkarchive,
    bfd_false,
  },
  {				/* bfd_write_contents */
    bfd_false,
    xpv_xdv_write_object_contents,
    _bfd_write_archive_contents,
    bfd_false,
  },

  BFD_JUMP_TABLE_GENERIC (xpv),
  BFD_JUMP_TABLE_COPY (_bfd_generic),
  BFD_JUMP_TABLE_CORE (_bfd_nocore),
  BFD_JUMP_TABLE_ARCHIVE (_bfd_noarchive),
  BFD_JUMP_TABLE_SYMBOLS (xpv),
  BFD_JUMP_TABLE_RELOCS (xpv),
  BFD_JUMP_TABLE_WRITE (xpv),
  BFD_JUMP_TABLE_LINK (xpv),
  BFD_JUMP_TABLE_DYNAMIC (_bfd_nodynamic),

  NULL,

  (PTR) 0
};

/* The XDV target vector.  Same as above but uses a different segment selection function */

const bfd_target xdv_vec =
{
  "xdv",			/* name */
  bfd_target_xpv_flavour,
  BFD_ENDIAN_UNKNOWN,		/* target byte order */
  BFD_ENDIAN_UNKNOWN,		/* target headers byte order */
  EXEC_P,			/* object_flags */
  (SEC_ALLOC | SEC_LOAD | SEC_READONLY | SEC_DATA
   | SEC_ROM | SEC_HAS_CONTENTS), /* section_flags */
  0,				/* leading underscore */
  ' ',				/* ar_pad_char */
  16,				/* ar_max_namelen */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,	/* data */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,	/* hdrs */

  {
    _bfd_dummy_target,
    xpv_object_p,		/* bfd_check_format */
    _bfd_dummy_target,
    _bfd_dummy_target,
  },
  {
    bfd_false,
    xpv_mkobject,
    _bfd_generic_mkarchive,
    bfd_false,
  },
  {				/* bfd_write_contents */
    bfd_false,
    xpv_xdv_write_object_contents,
    _bfd_write_archive_contents,
    bfd_false,
  },

  BFD_JUMP_TABLE_GENERIC (xpv),
  BFD_JUMP_TABLE_COPY (_bfd_generic),
  BFD_JUMP_TABLE_CORE (_bfd_nocore),
  BFD_JUMP_TABLE_ARCHIVE (_bfd_noarchive),
  BFD_JUMP_TABLE_SYMBOLS (xpv),
  BFD_JUMP_TABLE_RELOCS (xpv),
  BFD_JUMP_TABLE_WRITE (xdv), //Different segment selection
  BFD_JUMP_TABLE_LINK (xpv),
  BFD_JUMP_TABLE_DYNAMIC (_bfd_nodynamic),

  NULL,

  (PTR) 0
};

/* The XUV target vector.  Same as above but outputs both code and data segments, and
 * registers a tweaked function to write out the file (that turns off address range
 * checking).
 */

const bfd_target xuv_vec =
{
  "xuv",                        /* name */
  bfd_target_xpv_flavour,
  BFD_ENDIAN_UNKNOWN,           /* target byte order */
  BFD_ENDIAN_UNKNOWN,           /* target headers byte order */
  EXEC_P,                       /* object_flags */
  (SEC_ALLOC | SEC_LOAD | SEC_READONLY | SEC_CODE | SEC_DATA
   | SEC_ROM | SEC_HAS_CONTENTS), /* section_flags */
  0,                            /* leading underscore */
  ' ',                          /* ar_pad_char */
  16,                           /* ar_max_namelen */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,   /* data */
  bfd_getb64, bfd_getb_signed_64, bfd_putb64,
  bfd_getb32, bfd_getb_signed_32, bfd_putb32,
  bfd_getb16, bfd_getb_signed_16, bfd_putb16,   /* hdrs */

  {
    _bfd_dummy_target,
    xpv_object_p,               /* bfd_check_format */
    _bfd_dummy_target,
    _bfd_dummy_target,
  },
  {
    bfd_false,
    xpv_mkobject,
    _bfd_generic_mkarchive,
    bfd_false,
  },
  {                             /* bfd_write_contents */
    bfd_false,
    xuv_write_object_contents,
    _bfd_write_archive_contents,
    bfd_false,
  },

  BFD_JUMP_TABLE_GENERIC (xpv),
  BFD_JUMP_TABLE_COPY (_bfd_generic),
  BFD_JUMP_TABLE_CORE (_bfd_nocore),
  BFD_JUMP_TABLE_ARCHIVE (_bfd_noarchive),
  BFD_JUMP_TABLE_SYMBOLS (xpv),
  BFD_JUMP_TABLE_RELOCS (xpv),
  BFD_JUMP_TABLE_WRITE (xuv), // Different segment selection
  BFD_JUMP_TABLE_LINK (xpv),
  BFD_JUMP_TABLE_DYNAMIC (_bfd_nodynamic),

  NULL,

  (PTR) 0
};

;
