/* BFD library support routines for Cambridge Consultants XAP2 architecture.
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#include "bfd.h"
#include "sysdep.h"
#include "libbfd.h"

#define N(machine, print, default, next)        (bfd_arch_info_type)    \
{                                                 \
  16,             /* 16 bits in a word.  */       \
  24,             /* Bits in an address.  */      \
  16,             /* 16 bits in a byte (= smallest addressable unit)  */  \
  bfd_arch_xap2,                                  \
  machine,        /* Machine number.  */          \
  "xap2",         /* Architecture name.   */      \
  print,          /* Printable name.  */          \
  0,              /* Section align power.  */     \
  default,        /* The default machine?  */     \
  compatible,     /* Compatibility function */    \
  bfd_default_scan,                               \
  next                                            \
}

/* Different XAP2 variants are never compatible */
static const bfd_arch_info_type *
compatible (const bfd_arch_info_type *a, const bfd_arch_info_type *b)
{
  if (a->arch != b->arch)
    return NULL;
   
  if (a->mach == b->mach)
    return a;
       
  /* Anything can be linked with xap2_any */
  if (a->mach == bfd_mach_xap2_any)
    return b;

  /* No specific machine variants are compatible with each other */
  return NULL;
}

static const bfd_arch_info_type arch_info_struct[] =
  { N (bfd_mach_xap2_base, "xap2", TRUE, &arch_info_struct[1]),
    N (bfd_mach_xap2_plus, "xap2+", FALSE, NULL) };

bfd_arch_info_type bfd_xap2_arch = 
    N(bfd_mach_xap2_any, "xap2_any", FALSE, &arch_info_struct[0]);
