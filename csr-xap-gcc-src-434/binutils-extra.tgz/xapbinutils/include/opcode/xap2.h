/* Definitions for opcode table for the Cambridge Consultants XAP2.
   Modelled-on: include/opcode/sparc.h
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com


This file is part of GAS, the GNU Assembler, GDB, the GNU debugger, and
the GNU Binutils.

GAS/GDB is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GAS/GDB is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GAS or GDB; see the file COPYING.	If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <ansidecl.h>
#include "bfd.h" //For bfd_boolean

/* The following should really go elsewhere for access from the         */
/* other XAP2 tools...                                                  */
#define addrmode_start    (0)
#define reg_start         (2)
#define regx_start        (12)
#define opcode_start      (4)
#define opimm1_start      (8)
#define opimm2_start      (24)
#define opimm3_start      (40)
#define opimmx_start      (8)

/* XAP2 instruction fields: (extraction) */
#define XAP2_ADDRMODE(o) (((o) >> addrmode_start) & 0x3)
#define XAP2_REG(o)      (((o) >> reg_start) & 0x3)
#define XAP2_REGX(o)     (((o) >> regx_start) & 0x3)
#define XAP2_OPCODE(o)   (((o) >> opcode_start) & 0xf)
#define XAP2_OPIMM1(o)   (((o) >> opimm1_start) & 0xff)
#define XAP2_OPIMM2(o)   (((o) >> opimm2_start) & 0xff)
#define XAP2_OPIMM3(o)   (((o) >> opimm3_start) & 0xff)
#define XAP2_OPIMMX(o)   (((o) >> opimmx_start) & 0xf)

/* XAP2 instruction fields: (insertion) */
#define XAP2_MKADDRMODE(o) (((o) & 0x3) << addrmode_start)
#define XAP2_MKREG(o)      (((o) & 0x3) << reg_start)
#define XAP2_MKREGX(o)     (((o) & 0x3) << regx_start)
#define XAP2_MKOPCODE(o)   (((o) & 0xf) << opcode_start)
#define XAP2_MKOPIMM1(o)   (((o) & 0xff) << opimm1_start)
#define XAP2_MKOPIMM2(o)   (((o) & 0xff) << opimm2_start)
#define XAP2_MKOPIMM3(o)   (((o) & 0xff) << opimm3_start)
#define XAP2_MKOPIMMX(o)   (((o) & 0xf) << opimmx_start)

/* Sign-extend a value of a given length (in bits) */
#define SEXT(value, size) ((((value) & (0xffffffffffffffffLL >> (64 - (size)))) ^ (1 << ((size)-1))) - (1 << ((size)-1)))

/* The XAP2 opcode table (and other related data) is defined in
   the opcodes library in xap2-opc.c.  If you change anything here, make
   sure you fix up that file, and vice versa.  */

enum xap_arg_type {
    Type_Invalid,
	General_Reg,
	Signed_Immediate_Hex,
	Unsigned_Immediate_Hex,
	Abs_Relocatable_Immediate,
	Pcrel_Relocatable_Immediate,
	Signed_Immediate_Offset,
        Opcode,
};

enum xap_arg_location {
    Location_Invalid,    //0
        OpINSTR_OpREG_OpADDRMODE,
	OpREG,
	OpREGX,
	OpIMM1,
	OpIMM2_OpIMM1,
	OpIMM3_OpIMM2_OpIMM1,	
	OpIMMX,
};

enum xap_arg_range {
    No_Explicit_Range
};

/* Structure of an opcode table entry.  */

struct xap2_opcode {
  const char *name;
  unsigned long long match;	/* Bits that must be set. */
  unsigned long long xxlose;	/* Bits that must not be set. */
  unsigned iflags;      /* XF_xxx below. */
  const char *argstring;
  char *parameters[5];
  int nparameters;
  enum xap_arg_type arg_type[5];
  enum xap_arg_location arg_location[5];
  enum xap_arg_range arg_range[5];
  bfd_reloc_code_real_type relocation_type; /* was enum xap_relocation_type */
  int reloc_num_bits;
};

/*
** The match component is a mask saying which bits must match a particular
** opcode in order for an instruction to be an instance of that opcode.
** The xxlose component says which bits forbid the particular instruction being
** an instance of the opcode.
** 
** The args component is a string containing one character for each operand of
** the instruction.  See  opcodes/xap2-opc.c  for examples and code to
** interpret them in  gas/config/tc-xap2.c  and  opcodes/xap2-dis.c.
** 
** Flags are as below -- some are pretty vesigial (from the SPARC basis).
*/

#define XF_SYNONYM  128 /* disassembler to ignore                       */
#define XF_XAP2VANILLA 1024 /* instruction only available on vanilla XAP2 */
#define XF_XAP2PLUS    2048 /* instruction only available on XAP2+        */
                            
extern struct xap2_opcode xap2_opcodes[];
extern const int xap2_num_opcodes;

/* Register name tables. */
extern const char *xap2_genregs[4];

/* [SSC] This lot is probably unnecessary for XAP2 as the 16 <-> 32 <-> 48 */
/* conversions are so simple                                               */

/* Extracts a value from an instruction at the indicated location */
extern unsigned long long get_value_from_insn(unsigned long long opcode, enum xap_arg_location location);

/* Inserts a value into an instruction in the indicated location */
/* Returns false if the location code is not understood */
extern bfd_boolean put_value_in_insn(unsigned long long *pinsn, unsigned long long mask, enum xap_arg_location location);

/* Try to relax an instruction and return the adjusted size */
extern unsigned int xap2_tryrelax(unsigned long long *pinsn, unsigned int orig_size);

/* Length in bits of the immediate */
/* verify0 and verify1 may be null. If not, then they are set to represent any restrictions
   on the immediate value (eg verify0 = 3 means bits 0 and 1 must be 1.)*/
extern int xap2_get_immediate_length(enum xap_arg_location location, int* verify0, int* verify1);

/* end of xap2.h */
