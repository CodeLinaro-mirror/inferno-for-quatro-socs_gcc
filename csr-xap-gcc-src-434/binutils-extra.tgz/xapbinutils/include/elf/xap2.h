/* Cambridge Consultants XAP2 ELF support for BFD.
   
   Copyright (C) 2005-2007 Cambridge Consultants Limited.
   Contributed by Cambridge Consultants Limited.
   Send enquiries to: xap@cambridgeconsultants.com


This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#ifndef _ELF_XAP2_H
#define _ELF_XAP2_H

/* Processor specific flags for the ELF header e_flags field.  */


/* At the moment, there is only one XAP2 variant, 'bfd_mach_xap2_base'. */
/* If we decide to have more than one, the definitions of the values    */
/* used in the e_flags field can be given here.                         */


/* Relocation types for XAP2 ELF.  */
/* (there are others used by the assembler (see BFD_RELOC_XAP2_xxx)     */
/*  but only the following ones appear in ELF files.                    */
enum elf32_xap2_reloc_type {
    R_XAP2_NONE = 0,
    R_XAP2_16,
    R_XAP2_32,
    R_XAP2_16BIT_ZREL_8,
    R_XAP2_32BIT_ZREL_16,
    R_XAP2_48BIT_ZREL_24,
    R_XAP2_32BIT_ZREL_8,
    R_XAP2_48BIT_ZREL_16,
    R_XAP2_16BIT_PCREL_8,
    R_XAP2_32BIT_PCREL_16,
    R_XAP2_48BIT_PCREL_24,
    R_XAP2_32BIT_ZREL_16_NORELAX,
    R_XAP2_32BIT_PCREL_16_NORELAX,
    R_XAP2_48BIT_PCREL_24_NORELAX,
    R_XAP2_16_HWRD,
    R_XAP2_16_LWRD,
    R_XAP2_16BIT_ZREL_8_HWRD,
    R_XAP2_16BIT_ZREL_8_LWRD,
    R_XAP2_32BIT_ZREL_16_HWRD,
    R_XAP2_32BIT_ZREL_16_LWRD,
    R_XAP2_32BIT_ZREL_16_HWRD_NORELAX,
    R_XAP2_32BIT_ZREL_16_LWRD_NORELAX,
    R_XAP2_MINUS,
    R_XAP2_UA8,
    R_XAP2_UA16,
    R_XAP2_UA32,
    R_XAP2_max
};


/* Flag for the symbol st_other field used to indicate symbols that
 * make up part of a library interface (and hence should not be scrambled in
 * "private" libraries).
 *
 * st_other is an 8 bit field, and the bottom 2 bits are use for "Visibility",
 * see STV_* in elf/common.h.
 */
#define STO_XAP2_PUBLIC 0x80

#endif /* _ELF_XAP2_H */
