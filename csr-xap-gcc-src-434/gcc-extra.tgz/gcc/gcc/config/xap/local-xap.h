/*
   xap.h
  
   Header describing the xap port.
   Contributed by CSR plc.
   
   Copyright (c) ????-2010, The Linux Foundation.
   Portions Copyright (C) 2010 Cambridge Consultants Ltd

This file is part of GCC.

GCC is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 3, or (at your option) any later
version.

GCC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with GCC; see the file COPYING3.  If not see
<http://www.gnu.org/licenses/>
 */

#ifndef XAP_H
#define XAP_H

extern int target_flags;

#define TARGET_VERSION fprintf(stderr,"(xap2+)");

/**** 14.2 Controlling the Compilation Driver, gcc ****/

#define TARGET_OPTION_TRANSLATE_TABLE \
    { "-help", "-v" }, \
    { "-mno-args-span-regs-and-mem", "-mno-split-args" }, \
    { "-mno-inline-block-copy-mode", "-mno-block-copy" }, \
    { "-mpu", "-mno-block-copy -mfunction-ptr-pi"      }

#define LIBGCC_SPEC ""

/**** 14.3 Run-time Target Specification ****/

/* Defines macros __XAP, __XAP__ and possibly XAP */
#define TARGET_CPU_CPP_BUILTINS() \
    builtin_define_std("XAP")

#define OVERRIDE_OPTIONS \
    xap_override_options();

/**** 14.5 Storage Layout ****/

#define BITS_BIG_ENDIAN         0
#define BYTES_BIG_ENDIAN        1
#define WORDS_BIG_ENDIAN        1
#define BITS_PER_UNIT           16
#define UNITS_PER_WORD          1

#define POINTER_SIZE            16   
#define FUNCTION_POINTER_SIZE   (TARGET_SMALL_MODE ? 16 : 32)

/* If GCC has to implicitly cast 
 * function pointers to anything, let
 * it be to unsigned longs, as casting it to
 * unsigned of 24-bits generates errors in the optimisers
 * which have a hard time coping with unknown types.
 * B-77688
 */
#define FUNCTION_POINTER_CAST_TYPE (TARGET_SMALL_MODE ? sizetype : long_unsigned_type_node)

#define PARM_BOUNDARY           16
#define STACK_BOUNDARY          16
#define FUNCTION_BOUNDARY       16
#define BIGGEST_ALIGNMENT       16

/* "Biggest alignment supported by the object file format of this machine. Use
 * this macro to limit the alignment which can be specified using the
 * __attribute__ ((aligned (n))) construct."
 *
 * Set to 64k * 8 bits when targetting AS, 16 bits otherwise.
 */
#define MAX_OFILE_ALIGNMENT     (TARGET_AS_MODE ? ((1 << 16) * 8) : 16)
#define EMPTY_FIELD_BOUNDARY    16

/* XXX Not sure what this should be set to.
 *
 * STRICT_ALIGNMENT
 * Define this macro to be the value 1 if instructions will fail to work if
 * given data not on the nominal alignment. If instructions will merely go
 * slower in that case, define this macro as 0.
 */
#define STRICT_ALIGNMENT        1

#define BITFIELD_NBYTES_LIMITED 1
#define MAX_FIXED_MODE_SIZE     64
#define TARGET_FLOAT_FORMAT     IEEE_FLOAT_FORMAT

/**** 14.6 Layout of Source Language Data Types ****/

#define INT_TYPE_SIZE           16
#define SHORT_TYPE_SIZE         16
#define LONG_TYPE_SIZE          32
#define LONG_LONG_TYPE_SIZE     64
#define CHAR_TYPE_SIZE          16

#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

#define DEFAULT_SIGNED_CHAR     0
#define SIZE_TYPE               "unsigned int"
#define PTRDIFF_TYPE            "int"
#define WCHAR_TYPE              "int"
#define WCHAR_TYPE_SIZE         16

/**** 14.7.1 Register Usage ****/

/* Numbering of registers:
 *
 * AH AL XH XL AP SP FP
 *  0  1  2  3  4  5  6
 * 
 * Fake regs: 7,8,9,10
 * Frame regs: 11,12
 *
 * XXX Do we have enough fake/frame registers?
 */

/**** 14.7.1 Basic Characteristics of Registers ****/

#define FIRST_PSEUDO_REGISTER   13
#define FIXED_REGISTERS \
{ \
    0, 0, 1, 0, 1, 1, 1, \
    0, 0, 0, 0, \
    0, 0 \
}
    
#define CALL_USED_REGISTERS \
{ \
    1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, \
    1, 1 \
}

/**** 14.7.2 Order of Allocation of Registers ****/

#define REG_ALLOC_ORDER \
{ RAL, RAH, RXL, RFFF8, RFFF9, RFFFA, RFFFB, RY1, RY2 }

/**** 14.7.3 How Values Fit in Registers ****/

#define HARD_REGNO_NREGS(regno,mode) \
    ((GET_MODE_SIZE (mode) + UNITS_PER_WORD - 1) / UNITS_PER_WORD)

/* XXX It may be that we want to ban gcc from ever putting 64bit things in
 * registers. That would probably require changing this to reject anything that
 * big. */
#define HARD_REGNO_MODE_OK(regno,mode)  1

/* A C expression that is nonzero if a value of mode mode1 is 
 * accessible in mode mode2 without copying.
 *
 * If HARD_REGNO_MODE_OK (r, mode1) and HARD_REGNO_MODE_OK (r, mode2) 
 * are always the same for any r, then MODES_TIEABLE_P (mode1, mode2) 
 * should be nonzero. If they differ for any r, you should define this 
 * macro to return zero unless some other mechanism ensures the
 * accessibility of the value in a narrower mode.
 *
 * You should define this macro to return nonzero in as many cases as
 * possible since doing so will allow GCC to perform better register 
 * allocation. 
 */
#define MODES_TIEABLE_P(mode1,mode2) xap_modes_tieable(mode1, mode2)

/**** 14.8 Register Classes ****/

#define XAP_REGISTER_CLASSES(x) \
    x(NO_REGS),    x(ADDR_REGS), x(DATA_REGS), \
    x(STACK_REGS), x(CHIP_REGS), x(FAKE_REGS), \
    x(MEM_REGS),   x(ALL_REGS)

#define reg_class_X(x) x
enum reg_class { XAP_REGISTER_CLASSES(reg_class_X), LIM_REG_CLASSES };

#define REG_CLASS_NAMES_X(x) #x
#define REG_CLASS_NAMES { XAP_REGISTER_CLASSES(REG_CLASS_NAMES_X) }

#define N_REG_CLASSES ((int) LIM_REG_CLASSES)

#define GENERAL_REGS NO_REGS

#define XAPMASK(r) (1<<(r))
#define REG_CLASS_CONTENTS \
{\
    /* NO_REGS    */ { 0 }, \
\
    /* ADDR_REGS  */ { XAPMASK( RXL   ) }, \
\
    /* DATA_REGS  */ { XAPMASK( RAH   )|XAPMASK( RAL   ) }, \
\
    /* STACK_REGS */ { XAPMASK( RY1   )|XAPMASK( RY2   ) }, \
\
    /* CHIP_REGS  */ { XAPMASK( RAH   )|XAPMASK( RAL   )    \
                      |XAPMASK( RXL   )|XAPMASK( RFP   )    \
                      |XAPMASK( RSP   )                  }, \
\
    /* FAKE_REGS  */ { XAPMASK( RFFF8 )|XAPMASK( RFFF9 )    \
                      |XAPMASK( RFFFA )|XAPMASK( RFFFB ) }, \
\
    /* MEM_REGS   */ { XAPMASK( RFFF8 )|XAPMASK( RFFF9 )    \
                      |XAPMASK( RFFFA )|XAPMASK( RFFFB )    \
                      |XAPMASK( RY1   )|XAPMASK( RY2   ) }, \
\
    /* ALL_REGS   */ { XAPMASK( RAH   )|XAPMASK( RAL   )    \
                      |XAPMASK( RXL   )|XAPMASK( RFP   )    \
                      |XAPMASK( RSP   )                     \
                      |XAPMASK( RY1   )|XAPMASK( RY2   )    \
                      |XAPMASK( RFFF8 )|XAPMASK( RFFF9 )    \
                      |XAPMASK( RFFFA )|XAPMASK( RFFFB ) }  \
}

#ifndef IN_LIBGCC2
extern int xap_regno_reg_class[FIRST_PSEUDO_REGISTER];
#endif
#define REGNO_REG_CLASS(regno) \
    ((regno < FIRST_PSEUDO_REGISTER) ? xap_regno_reg_class[regno] : NO_REGS)

#define BASE_REG_CLASS ADDR_REGS
#define INDEX_REG_CLASS NO_REGS

#define HARD_REGNO_OK_FOR_BASE_P(regno) \
    ( (regno)==RXL || (regno)==RAP || (regno)==RSP || (regno)==RFP )

#define REGNO_OK_FOR_BASE_P(regno) \
    (   HARD_REGNO_OK_FOR_BASE_P(regno) \
     || HARD_REGNO_OK_FOR_BASE_P(reg_renumber[regno]) )

#define REGNO_OK_FOR_INDEX_P(regno) 0

#define PREFERRED_RELOAD_CLASS(x,c) c

/* XXX Perhaps we should define this. An option to turn it on would be useful */
#define SMALL_REGISTER_CLASSES 0

/* XXX Should we really define this, or would the default be better? Perhaps we
 * need an option for it so we can try out different combinations.
 * 
 * A C expression whose value is nonzero if pseudos that have been assigned to
 * registers of class class would likely be spilled because registers of class
 * are needed for spill registers.
 *
 * The default value of this macro returns 1 if class has exactly one register
 * and zero otherwise. On most machines, this default should be used. Only
 * define this macro to some other expression if pseudos allocated by
 * local-alloc.c end up in memory because their hard registers were needed for
 * spill registers. If this macro returns nonzero for those classes, those
 * pseudos will only be allocated by global.c, which knows how to reallocate the
 * pseudo to another register. If there would not be another register available
 * for reallocation, you should not change the definition of this macro since
 * the only effect of such a definition would be to slow down register
 * allocation.
 */
#define CLASS_LIKELY_SPILLED_P(regclass) \
    ( (regclass) == ADDR_REGS || (regclass) == DATA_REGS )

#define CLASS_MAX_NREGS(regclass,mode) \
    ((GET_MODE_SIZE (mode) + UNITS_PER_WORD - 1) / UNITS_PER_WORD)

/* XXX Check me! */
#define CANNOT_CHANGE_MODE_CLASS(from_mode,to_mode,regclass) 0

/**** 14.9 Stack Layout and Calling Conventions ****/

/**** 14.9.1 Basic Stack Layout ****/

/* Frame layout looks like this:
 *
 *          | incoming arg |
 *          | ...          |
 * old Y -> | incoming arg |  ^
 *          | XH           |  |
 *          | X            |  | increasing
 *          | local        |  | address
 *          | ...          |  |
 *          | local        |
 *          | outgoing arg |
 *          | ...          |
 *     Y -> | outgoing arg |
 *
 */


#define STACK_GROWS_DOWNWARD
#define STARTING_FRAME_OFFSET       current_function_outgoing_args_size
#define FIRST_PARM_OFFSET(fundecl)  0

#define RETURN_ADDR_RTX(count,frameaddr) xap_return_addr_rtx(count,frameaddr)

/**** 14.9.3 Specifying How Stack Checking is Done ****/

/* Checking gets done in function prologues */
#define STACK_CHECK_BUILTIN 1

/**** 14.9.4 Registers That Address the Stack Frame ****/

#define STACK_POINTER_REGNUM    RSP
#define FRAME_POINTER_REGNUM    RFP
#define ARG_POINTER_REGNUM      RAP
#define STATIC_CHAIN_REGNUM     RFFF9

/**** 14.9.5 Eliminating Frame Pointer and Arg Pointer ****/

#define FRAME_POINTER_REQUIRED  1

/* RSP,RAP can be eliminated in terms of RFP */
#define ELIMINABLE_REGS \
{\
    { RAP, RSP } , \
    { RAP, RFP } , \
    { RFP, RSP } , \
}

#define CAN_ELIMINATE(fromreg,toreg) 1

#define INITIAL_ELIMINATION_OFFSET(fromreg,toreg,offset) \
    ( (offset) = xap_initial_elimination_offset(fromreg,toreg) )

/**** 14.9.6 Passing Function Arguments on the Stack ****/

#define PUSH_ARGS                                    0
#define ACCUMULATE_OUTGOING_ARGS                     1
#define RETURN_POPS_ARGS(fundecl,funtype,stack_size) 0
#define CALL_POPS_ARGS(cum)                          0

/**** 14.9.7 Passing Arguments in Registers ****/

#define CUMULATIVE_ARGS int

#define FUNCTION_ARG(cum,mode,type,named) xap_function_arg(cum,mode,type,named)
#define INIT_CUMULATIVE_ARGS(cum,fntype,libname,fndecl,n_named_args) ((cum)=0)

#define FUNCTION_ARG_ADVANCE(cum,mode,type,named) ((cum) += xap_arg_size(mode,type))
#define FUNCTION_ARG_REGNO_P(regno) ( (regno)==RAH || (regno)==RAL )

/**** 14.9.8 How Scalar Function Values Are Returned ****/

#define LIBCALL_VALUE(mode) xap_libcall_value(mode)

/* "A register whose use for returning values is limited to serving as the
 * second of a pair (for a value of type double, say) need not be recognized by
 * this macro." */
#define FUNCTION_VALUE_REGNO_P(regno) \
    (   (regno)==RAH \
     || (!TARGET_ALT_CALLING_CONVENTION && (regno)==RAL) )

/**** 14.9.9 How Large Values Are Returned ****/

#define DEFAULT_PCC_STRUCT_RETURN 0

/**** 14.9.11 Function Entry and Exit ****/

#define EXIT_IGNORE_STACK 1

/**** 14.9.12 Generating Code for Profiling ****/

#define FUNCTION_PROFILER(file,labelno) abort()

/**** 14.11 Trampolines for Nested Functions ****/

/* XXX can we support this? */
#define TRAMPOLINE_TEMPLATE(FILE) abort()
#define TRAMPOLINE_SIZE 0
#define INITIALIZE_TRAMPOLINE(tramp,fnaddr,cxt) abort()

/**** 14.13 Addressing Modes ****/

#define CONSTANT_ADDRESS_P(x) CONSTANT_P(x)
#define MAX_REGS_PER_ADDRESS 1

#define REG_OK_FOR_BASE_P_STRICT(x) \
    ( REGNO(x)==RXL || REGNO(x)==RAP || REGNO(x)==RSP || REGNO(x) == RFP )

#define REG_OK_FOR_BASE_P_LAX(x) \
    ( REG_OK_FOR_BASE_P_STRICT(x) || REGNO(x) >= FIRST_PSEUDO_REGISTER )

enum xap_reg_ok { XAP_REG_OK_STRICT, XAP_REG_OK_LAX };

#ifdef REG_OK_STRICT

#   define GO_IF_LEGITIMATE_ADDRESS(mode,x,label) \
        if(xap_legitimate_address(mode,x,XAP_REG_OK_STRICT)) goto label
#   define REG_OK_FOR_BASE_P(x) REG_OK_FOR_BASE_P_STRICT(x)

#else

#   define GO_IF_LEGITIMATE_ADDRESS(mode,x,label) \
        if(xap_legitimate_address(mode,x,XAP_REG_OK_LAX)) goto label
#   define REG_OK_FOR_BASE_P(x) REG_OK_FOR_BASE_P_LAX(x)

#endif

#define REG_OK_FOR_INDEX_P(x) REG_OK_FOR_BASE_P(x)

#define GO_IF_MODE_DEPENDENT_ADDRESS(addr,label)

#define LEGITIMATE_CONSTANT_P(x) \
            (GET_CODE(x) != CONST_DOUBLE)

/**** 14.14 Condition Code Status ****/

#define NOTICE_UPDATE_CC(exp,insn) xap_notice_update_cc(exp,insn)

/**** 14.15 Describing Relative Costs of Operations ****/

#define XAP_MEM_REG_CLASS(regclass) \
    (   (regclass) == FAKE_REGS \
     || (regclass) == STACK_REGS \
     || (regclass) == MEM_REGS )

#define REGISTER_MOVE_COST(mode,from,to) xap_register_move_cost(mode, from, to)

#define MEMORY_MOVE_COST(mode,class,in) xap_memory_move_cost(mode, class, in)

#define BRANCH_COST xap_branch_cost()

#define SLOW_BYTE_ACCESS 1

/* XXX correct? I've worked this out by adding up the (code space) cost of doing
 * a block copy with a fudge factor to account for clobbering extra registers.
 * XXX It's possible we should be changing this based on optimisation options,
 * ie, did the user say -Os/-O/-O2/-O3 ? */
#define MOVE_RATIO 2
#define CLEAR_RATIO 7

#define STORE_BY_PIECES_P(size,alignment) \
    ( (size) < CLEAR_RATIO )

#define NO_FUNCTION_CSE 1

/**** 14.17 Dividing the Output into Sections (Texts, Data, ...) ****/

#define TEXT_SECTION_ASM_OP             xap_text_section_asm_op()
#define DATA_SECTION_ASM_OP             xap_data_section_asm_op()
#define READONLY_DATA_SECTION_ASM_OP    xap_readonly_data_section_asm_op()

/* BSS_SECTION_ASM_OP is unused, but a definition is required for varasm to use
 * a bss section at all. bss_section is re-defined in
 * xap_asm_init_sections. */
#define BSS_SECTION_ASM_OP              ""

#define JUMP_TABLES_IN_TEXT_SECTION (!TARGET_CONST_JUMP_TABLES)

/**** 14.19.1 The Overall Framework of an Assembler File ****/

#define ASM_COMMENT_START   ";#"
#define ASM_APP_ON          ";# asm start\n"
#define ASM_APP_OFF         ";# asm end\n"

/* The following are used by xIDE to identify the register numbering scheme in use.
   xap_override_options() forces flag_no_ident to be set when not using TARGET_AS_MODE */
#define ASM_OUTPUT_IDENT(FILE, NAME) \
    do{ gcc_assert(TARGET_AS_MODE); \
        fprintf (FILE, "%s\"%s\"\n", IDENT_ASM_OP, NAME); \
    } while (0)
#define IDENT_ASM_OP "\t.ident\t"

/**** 14.19.2 Output of Data14.19.2 Output of Data ****/

#define ASM_OUTPUT_ASCII(file,ptr,len) xap_asm_output_ascii(file,ptr,len)

/**** 14.19.3 Output of Uninitialized Variables ****/

#define ASM_OUTPUT_ALIGNED_DECL_COMMON(stream,decl,name,size,alignment) \
        xap_asm_output_aligned_decl_common(stream,decl,name,size,alignment)

#define ASM_OUTPUT_ALIGNED_DECL_LOCAL(stream,decl,name,size,alignment) \
        ASM_OUTPUT_ALIGNED_DECL_COMMON(stream,decl,name,size,alignment) 

#define ASM_OUTPUT_BSS(stream, decl, name, size, rounded) \
    asm_output_bss(stream,decl,name,size,rounded)

/**** 14.19.4 Output and Generation of Labels ****/

/* #define ASM_OUTPUT_LABEL(stream,name) xap_asm_output_label(stream,name)*/

#define ASM_OUTPUT_SIZE_DIRECTIVE(stream,name,size) \
    xap_asm_output_size_directive(stream,name,size)

/* Eek! I don't think we can do this. */
/* #define ASM_OUTPUT_MEASURED_SIZE(stream,name) abort()*/

#define ASM_DECLARE_OBJECT_NAME(stream,name,decl) \
    xap_asm_declare_object_name(stream,name,decl)

/* ASM_DECLARE_FUNCTION_SIZE 
 *
 * A C statement (sans semicolon) to output to the stdio stream stream any 
 * text necessary for declaring the size of a function which is being defined. 
 * The argument name is the name of the function. The argument decl is the 
 * FUNCTION_DECL tree node representing the function. 
 */
#define ASM_DECLARE_FUNCTION_SIZE(stream,name,decl) \
    xap_asm_declare_function_size(stream,name,decl)

/* XXX "This should add _ to the front of the name, if that is customary on your
 * operating system" */
#define ASM_OUTPUT_LABELREF(stream,name) \
    xap_asm_output_labelref(stream,name)

#define ASM_GENERATE_INTERNAL_LABEL(string, prefix, num) \
    xap_asm_generate_internal_label(string, prefix, num)

/* JRRK - not all source files include xap-protos.h because they don't think they need it
 * this leads to disaster on 64-bit systems which raturn a char * inside an int, losing
 * the top 32-bits. This wouldn't matter except this string is generated using alloca ie
 * on the stack which is at top of memory and way beyond the 4 gig watershed. Solution is
 * to declare the prototype inside the macro. Is that disgusting or what ? */
#define ASM_FORMAT_PRIVATE_NAME(output, name, labelno) \
    do { char *xap_asm_format_private_name(char *, const char *, unsigned int); \
    (output) = xap_asm_format_private_name((char*)alloca(strlen(name)+12), name, labelno); \
    } while(0)

#define ASM_OUTPUT_DEF(stream,name,value) \
    xap_asm_output_def(stream,name,value)

#define TYPE_ASM_OP	"\t.type\t"
#define SIZE_ASM_OP	"\t.size\t"

#define ASM_OUTPUT_TYPE_DIRECTIVE(STREAM, NAME, TYPE)	\
        xap_asm_output_type_directive(STREAM, NAME, TYPE)

/* The definition of this for TARGET_AS_MODE and !TARGET_AS_MODE is safe,
   because ASM_OUTPUT_TYPE_DIRECTIVE is a no-op in !TARGET_AS_MODE */
#define ASM_DECLARE_FUNCTION_NAME(FILE, NAME, DECL)		\
    xap_asm_declare_function_name(FILE, NAME, DECL)

/* Output the size directive for a decl in rest_of_decl_compilation
in the case where we did not do so before the initializer.
Once we find the error_mark_node, we know that the value of
size_directive_output was set
by ASM_DECLARE_OBJECT_NAME when it was run for the same decl.  */
#define ASM_FINISH_DECLARE_OBJECT(FILE, DECL, TOP_LEVEL, AT_END) \
      xap_asm_finish_declare_object(FILE, DECL, TOP_LEVEL, AT_END)

/**** 14.19.6 Macros Controlling Initialization Routines ****/

#define HAS_INIT_SECTION

/**** 14.19.7 Output of Assembler Instructions ****/

#define REGISTER_NAMES \
{\
    "AH", "AL", "XH", "X", "AP", "Y", "Y", \
    "@H'fff8", "@H'fff9", "@H'fffa", "@H'fffb", \
    "@(-1,Y)", "@(-2,Y)" \
}

#define PRINT_OPERAND(stream,x,code) \
    xap_print_operand(stream,x,code)

#define PRINT_OPERAND_ADDRESS(stream,x) \
    xap_print_operand_address(stream,x)

/* XXX apparently used when profiling, probably should do somethign sensible */
/*#define ASM_OUTPUT_REG_PUSH abort()
#define ASM_OUTPUT_REG_POP abort()*/

/**** 14.19.8 Output of Dispatch Tables ****/

#define ASM_OUTPUT_ADDR_DIFF_ELT(stream, body, value, rel) \
    xap_asm_output_addr_diff_elt(stream,body,value,rel)

#define ASM_OUTPUT_CASE_LABEL(stream, prefix, num, table) \
    xap_asm_output_case_label(stream, prefix, num, table)

#define ASM_OUTPUT_CASE_END(stream, num, table) \
    xap_asm_output_case_end(stream, num, table)

/**** 14.19.10 Assembler Commands for Alignment ****/

#define ASM_OUTPUT_SKIP(stream,nbytes) xap_asm_output_skip(stream,nbytes)

#define ASM_OUTPUT_ALIGN(stream,pow) xap_asm_output_align(stream,pow)

/**** 14.20.2 Specific Options for DBX Output ****/

#define DBX_DEBUGGING_INFO

#define ASM_STABS_OP (TARGET_AS_MODE ? "\t.stabs\t" : ";.stabs\t")
#define ASM_STABD_OP (TARGET_AS_MODE ? "\t.stabd\t" : ";;;.stabd\t")
#define ASM_STABN_OP (TARGET_AS_MODE ? "\t.stabn\t" : ";;;.stabn\t")
#define DBX_NO_XREFS

#define DBX_FUNCTION_FIRST

/* In ELF files, its OK to generate very long STABS records */
#define DBX_CONTIN_LENGTH (TARGET_AS_MODE ? 0 : 80)

/* Generate a blank trailing N_SO to mark the end of the .o file, since
   we can't depend upon the linker to mark .o file boundaries with
   embedded stabs.  */
#define DBX_OUTPUT_NULL_N_SO_AT_MAIN_SOURCE_FILE_END

#ifndef IN_LIBGCC2
#include "debug.h"
extern struct gcc_debug_hooks xap_debug_hooks;
#define OTHER_DEBUG_HOOKS \
     xap_debug_hooks    
#endif

/**** 14.20.5 Specific Options for DWARF Output ****/
#define DWARF2_DEBUGGING_INFO   1

/* This should be DWARF2_DEBUG once binutils becomes standard.
 * for now its DBX_DEBUG
 */
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG

#define DWARF_FRAME_RETURN_COLUMN    DWARF_FRAME_REGNUM(RXL)
#define INCOMING_RETURN_ADDR_RTX     gen_rtx_REG (Pmode, RXL)
#define INCOMING_FRAME_SP_OFFSET     0

/* This is defined to preserve binary compatability */
#define DWARF_FRAME_REGISTERS       13
/* Generate frame information, but don't support exceptions */
#define DWARF2_UNWIND_INFO          0
/* Produce more compact debug information - gas supports this */
#define DWARF2_ASM_LINE_DEBUG_INFO  1
/* Ensures all addresses are big enough for relaxation to occur
   NB, these sizes are specified in octets */

/* B-92777: (TARGET_SMALL_MODE ? 2 : 4) */
#define DWARF2_ADDR_SIZE            4

/**** 14.27 Miscellaneous Parameters ****/

#define HAS_LONG_COND_BRANCH    1
#define HAS_LONG_UNCOND_BRANCH  1

#define CASE_VECTOR_MODE        QImode
#define CASE_VECTOR_PC_RELATIVE 1

/* XXX Tune me! */
#define CASE_VALUES_THRESHOLD   5
#define CASE_USE_BIT_TESTS      1

/* XXX does this ever happen? */
#define LOAD_EXTEND_OP(mode) UNKNOWN

/* XXX would 0 be sensible here? It is supposed to be the number of bytes we can
 * move from memory to memory in one (reasonably fast) instruction, which is
 * none at all. */
#define MOVE_MAX 1

#define TRULY_NOOP_TRUNCATION(outprec,inprec) 1

/* XXX function pointer DOOM */
#ifdef XAP_PMODE_DEBUG
# define Pmode xap_pmode(__FILE__,__LINE__)
#else
# define Pmode QImode
#endif

#define FUNCTION_Pmode (TARGET_SMALL_MODE ? QImode : HImode)

#define FUNCTION_MODE QImode

/* XXX Tune me! Should depend on optimize_size? */
#define POWI_MAX_MULTS 6

/* 15.21.4 Output and Generation of Labels */

/* A C expression which evaluates to true if the target supports weak symbols.
 *
 * If you don't define this macro, defaults.h provides a default definition. 
 * If either ASM_WEAKEN_LABEL or ASM_WEAKEN_DECL is defined, the default 
 * definition is `1'; otherwise, it is `0'. Define this macro if you want to 
 * control weak symbol support with a compiler flag such as -melf. 
 *
 * We can only support weak symbols in AS_MODE
 */
#define SUPPORTS_WEAK TARGET_AS_MODE 

/* Macro: FINAL_PRESCAN_INSN (insn, opvec, noperands) 
 * 
 * If defined, a C statement to be executed just prior to the output of 
 * assembler code for insn, to modify the extracted operands so they will 
 * be output differently.
 * 
 * Here the argument opvec is the vector containing the operands extracted 
 * from insn, and noperands is the number of elements of the vector which 
 * contain meaningful data for this insn. The contents of this vector are what 
 * will be used to convert the insn template into assembler code, so you 
 * can change the assembler output by changing the contents of the vector. 
 *
 * This macro is useful when various assembler syntaxes share a single file 
 * of instruction patterns; by defining this macro differently, you can 
 * cause a large class of instructions to be output differently (such as 
 * with rearranged operands). Naturally, variations in assembler syntax 
 * affecting individual insn patterns ought to be handled by writing 
 * conditional output routines in those patterns. 
 *
 * If this macro is not defined, it is equivalent to a null statement.  */
#define FINAL_PRESCAN_INSN(insn, operand, nop) final_prescan_insn (insn, operand,nop)

/* Macro: CANONICALIZE_COMPARISON (code, op0, op1)
 *
 * On some machines not all possible comparisons are defined, but you
 * can convert an invalid comparison into a valid one. For example, the
 * Alpha does not have a GT comparison, but you can use an LT comparison
 * instead and swap the order of the operands.
 *
 * On such machines, define this macro to be a C statement to do any required
 * conversions. code is the initial comparison code and op0 and op1 are the
 * left and right operands of the comparison, respectively. You should modify 
 * code, op0, and op1 as required.
 *
 * GCC will not assume that the comparison resulting from this macro is
 * valid but will see if the resulting insn matches a pattern in the md file.
 *
 * You need not define this macro if it would never change the comparison code or operands. */
#define CANONICALIZE_COMPARISON(code, op0, op1) \
    code = xap_canonicalize_comparison(code, &op0, &op1)

/* Define the information needed to generate branch insns.  This is
 * stored from the compare operation.  Note that we can't use "rtx" here
 * since it hasn't been defined!  */
struct xap_compare
{
    struct rtx_def *op0, *op1;
    int cmp;
};

extern struct xap_compare xap_compare;

#endif /* ifndef XAP_H */
