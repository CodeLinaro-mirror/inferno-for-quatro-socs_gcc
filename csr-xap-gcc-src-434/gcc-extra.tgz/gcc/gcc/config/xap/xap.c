/*
   xap.c
  
   Functions to support the xap2+ port.
   Contributed by CSR plc.
   
   Copyright (c) ????-2010, The Linux Foundation.
   Portions Copyright (C) 2010 Cambridge Consultants Ltd

This file is part of GCC.

GCC is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 3, or (at your option) any later
version.

GCC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with GCC; see the file COPYING3.  If not see
<http://www.gnu.org/licenses/>
 */

/* Urk. These includes are horribly sensitive to order. My approach is to copy
 * the order from arm.c */
#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "rtl.h"
#include "tree.h"
#include "tree-pass.h" /* Access to current_pass structure for debug info */
#include "tree-iterator.h"
#include "tree-flow.h"
#include "regs.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "function.h"
#include "expr.h"
#include "toplev.h"
#include "basic-block.h"
#include "target.h"
#include "target-def.h"
#include "insn-codes.h"
#include "debug.h"
#include "filenames.h"
#include "langhooks.h"
#include "c-common.h"
#include "df.h"
#include "integrate.h"
#include "xap-protos.h"

#include <stdio.h>
#include <string.h>
#ifdef WIN32
void *alloca(size_t size);
#else
#include <alloca.h>
#endif
#include <ctype.h>


#define WRITEME \
    fprintf(stderr,"GCC called an unimplemented function!\n"); \
    abort();

/* Initialise the GCC target hooks */

enum reg_class xap_secondary_reload (bool in_p,
                                            rtx x,
                                            enum reg_class reload_class,
                                            enum machine_mode reload_mode,
                                            secondary_reload_info *sri);
#undef TARGET_SECONDARY_RELOAD 
#define TARGET_SECONDARY_RELOAD xap_secondary_reload

static int xap_arg_partial_bytes(CUMULATIVE_ARGS *cum,
                                         enum machine_mode mode,
                                         tree type,
                                         bool named);
#undef TARGET_ARG_PARTIAL_BYTES
#define TARGET_ARG_PARTIAL_BYTES xap_arg_partial_bytes

static bool xap_pass_by_reference(CUMULATIVE_ARGS *cum,
                                         enum machine_mode mode,
                                         const_tree type,
                                         bool named);
#undef TARGET_PASS_BY_REFERENCE
#define TARGET_PASS_BY_REFERENCE xap_pass_by_reference

static bool xap_callee_copies(CUMULATIVE_ARGS *cum,
                                     enum machine_mode mode,
                                     const_tree type,
                                     bool named);
#undef TARGET_CALLEE_COPIES 
#define TARGET_CALLEE_COPIES xap_callee_copies

static rtx xap_function_value(const_tree ret_type,
                                     const_tree fn_decl_or_type,
                                     bool outgoing);
#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE xap_function_value

static bool xap_return_in_memory(const_tree type, const_tree fntype);
#undef TARGET_RETURN_IN_MEMORY
#define TARGET_RETURN_IN_MEMORY xap_return_in_memory 

static rtx xap_struct_value_rtx(tree fndecl, int incoming);
#undef TARGET_STRUCT_VALUE_RTX
#define TARGET_STRUCT_VALUE_RTX xap_struct_value_rtx 

static bool xap_function_ok_for_sibcall (tree decl, tree exp);
#undef TARGET_FUNCTION_OK_FOR_SIBCALL 
#define TARGET_FUNCTION_OK_FOR_SIBCALL xap_function_ok_for_sibcall

static bool xap_rtx_costs(rtx x, int code, int outer_code, int *total);
#undef TARGET_RTX_COSTS
#define TARGET_RTX_COSTS xap_rtx_costs

static int xap_address_cost(rtx address);
#undef TARGET_ADDRESS_COST
#define TARGET_ADDRESS_COST xap_address_cost

static void xap_asm_init_sections(void);
#undef TARGET_ASM_INIT_SECTIONS
#define TARGET_ASM_INIT_SECTIONS xap_asm_init_sections

section * xap_asm_select_section (tree exp,
                                         int reloc,
                                         unsigned HOST_WIDE_INT align);
#undef TARGET_ASM_SELECT_SECTION 
#define TARGET_ASM_SELECT_SECTION xap_asm_select_section

static void xap_encode_section_info(tree decl, rtx rtl, int new_decl_p);
#undef TARGET_ENCODE_SECTION_INFO
#define TARGET_ENCODE_SECTION_INFO xap_encode_section_info

static void xap_asm_file_start(void);
#undef TARGET_ASM_FILE_START
#define TARGET_ASM_FILE_START xap_asm_file_start

static void xap_asm_file_end(void);
#undef TARGET_ASM_FILE_END 
#define TARGET_ASM_FILE_END xap_asm_file_end 

static void xap_asm_named_section(const char *name, unsigned int flags, tree decl);
#undef TARGET_ASM_NAMED_SECTION
#define TARGET_ASM_NAMED_SECTION xap_asm_named_section 

static bool xap_commutative_p(rtx x, int outer_code);
#undef TARGET_COMMUTATIVE_P
#define TARGET_COMMUTATIVE_P xap_commutative_p

#undef TARGET_HAVE_NAMED_SECTIONS
#define TARGET_HAVE_NAMED_SECTIONS true

#undef TARGET_ASM_BYTE_OP
#define TARGET_ASM_BYTE_OP NULL /* filled in in xap_override_options */

static bool xap_asm_integer(rtx x, unsigned int size, int aligned_p);
#undef TARGET_ASM_INTEGER 
#define TARGET_ASM_INTEGER xap_asm_integer 

void xap_asm_globalize_label(FILE *stream, const char *name);
#undef TARGET_ASM_GLOBALIZE_LABEL
#define TARGET_ASM_GLOBALIZE_LABEL xap_asm_globalize_label

const struct attribute_spec xap_attribute_table[];
#undef TARGET_ATTRIBUTE_TABLE
#define TARGET_ATTRIBUTE_TABLE xap_attribute_table

void xap_asm_external_libcall(rtx symref);
#undef TARGET_ASM_EXTERNAL_LIBCALL
#define TARGET_ASM_EXTERNAL_LIBCALL xap_asm_external_libcall

static void xap_init_builtins(void);
#undef TARGET_INIT_BUILTINS
#define TARGET_INIT_BUILTINS xap_init_builtins

static tree xap_fold_builtin(tree fndecl, 
                             tree arglist, 
                             bool ignore);
#undef TARGET_FOLD_BUILTIN
#define TARGET_FOLD_BUILTIN xap_fold_builtin

#define XAP_LABEL_PREFIX (TARGET_AS_MODE?".":"?")

struct gcc_target targetm = TARGET_INITIALIZER;

/* Save information from a "cmpxx" or "tstxx" operation until the branch
 * is emitted */
struct xap_compare xap_compare;

/* Minimal register class for all of our registers */
int xap_regno_reg_class[FIRST_PSEUDO_REGISTER] =
{
    /* RAH, RAL */      DATA_REGS, DATA_REGS,
    /* RXH */           ALL_REGS,
    /* RXL */           ADDR_REGS,
    /* RAP,RSP,RFP */   ALL_REGS, CHIP_REGS, CHIP_REGS,
    /* RFFF8-B */       FAKE_REGS, FAKE_REGS, FAKE_REGS, FAKE_REGS,
    /* RY1, RY2 */      STACK_REGS, STACK_REGS
};

/* Operand codes passed to xap_print_operand */
typedef enum
{
   XAP_MS16OF32      = 't',
   XAP_LS16OF32      = 'b',
   XAP_ADDR          = 'f',
   XAP_MS16OF32_ADDR = 'G',
   XAP_LS16OF32_ADDR = 'F',
   XAP_NO_DECORATION = 'u',
   XAP_WORD3         = 'T',
   XAP_WORD4         = 'B'
} xap_operand_code;

enum xap_find_global_action { XAP_GLOBAL_ADD, XAP_GLOBAL_FIND };

static const char *xap_find_global(const char *name,
                                   enum xap_find_global_action action);
static void xap_maybe_globalize_next_label(rtx symref);
static void xap_dbx_output_source_line(unsigned int line, const char *file);
static char *xap_asm_mk_labelref(const char *name);

struct gcc_debug_hooks xap_debug_hooks;

static const char *xap_path_find;
static const char *xap_path_replacement;

static const char *xap_output_record_type(FILE *stream, const_tree type);

typedef struct rli_chain
{
    struct rli_chain *next;
    tree record;
}
rli_chain;

static rli_chain *rli_head;

#if 0
static void xap_note_record_layout(record_layout_info rli)
{
    rli_chain **p = &rli_head;

    while(*p) p = &(*p)->next;

    *p = xmalloc(sizeof(rli_chain));

    (*p)->next = NULL;
    (*p)->record = rli->t;
}
#endif

static void xap_output_record_layouts(void)
{
    rli_chain *p;
    for(p = rli_head; p; p = p->next)
        xap_output_record_type(asm_out_file, p->record);
}

extern struct tree_opt_pass *current_pass;
static void xap_current_pass(FILE *file)
{
    if (current_pass)
        fprintf (file, "%s (%d)", 
                 current_pass->name, current_pass->static_pass_number);
}

void xap_override_options(void)
{
    /* can't use struc or output LIF in 'as' mode.
     * also if we're making debug info, it has to be stabs */
    if(TARGET_AS_MODE)
    {
        target_flags |= MASK_NO_LIF;
        target_flags |= MASK_NO_STRUC;
        if(write_symbols == DBX_DEBUG)
            target_flags |= MASK_STABS;

        /* The names of the pseudo-registers need to be adjusted to avoid H' */
        /* Make sure we are changing the right register names! */
        gcc_assert(strncmp(reg_names[RFFF8], "@H'", 3) == 0);
        gcc_assert(strncmp(reg_names[RFFF9], "@H'", 3) == 0);
        gcc_assert(strncmp(reg_names[RFFFA], "@H'", 3) == 0);
        gcc_assert(strncmp(reg_names[RFFFB], "@H'", 3) == 0);
        reg_names[RFFF8] = "@0xfff8";
        reg_names[RFFF9] = "@0xfff9";
        reg_names[RFFFA] = "@0xfffa";
        reg_names[RFFFB] = "@0xfffb";

        if(write_symbols == DWARF2_DEBUG)
        {
            targetm.asm_out.byte_op = "\t.1byte\t";
            /* Normally these are defined by defining OBJECT_FORMAT_ELF, but
               this needs to be conditional on assembler */
            targetm.asm_out.unaligned_op.hi = "\t.2byte\t";
            targetm.asm_out.unaligned_op.si = "\t.4byte\t";
            targetm.asm_out.unaligned_op.di = "\t.8byte\t";
        }
        else
        {
            /* The only place this is used is in the DWARF code, and if DWARF is enabled it
               gets assigned above. Normally, should not be outputting single bytes */
            targetm.asm_out.byte_op = "\t.error\t";
        }
    }
    else
    {
        /* Never emit ident directives in non-AS mode */
        flag_no_ident = 1;

        /* TODO: This should probably generate an error (see comment above) but I am reluctant to
                 make changes that do not affect the TARGET_AS_MODE path */
        targetm.asm_out.byte_op = "\tDC\t";
    }

    if(!TARGET_AS_MODE &&
       debug_info_level != DINFO_LEVEL_NONE &&
       write_symbols == DWARF2_DEBUG)
    {
        error("DWARF2 debugging information cannot be generated unless -mas-mode is used");
    }

    if(write_symbols == DBX_DEBUG && !TARGET_AS_MODE)
    {
        if(TARGET_STABS)
            /* BlueLab style: Stabs + NCC line symbols. */
            xap_debug_hooks = dbx_debug_hooks;
        else
            /* Firmware style: Just NCC line symbols. */
            xap_debug_hooks = do_nothing_debug_hooks;

        write_symbols = OTHER_DEBUG;
        xap_debug_hooks.source_line = xap_dbx_output_source_line;
        xap_debug_hooks.begin_prologue = xap_dbx_output_source_line;
    }

    if(xap_path_substitution)
    {
        char * comma = strchr(xap_path_substitution,',');
        if(   comma
           && !strchr(comma+1,',')
           && comma != xap_path_substitution)
        {
            *comma = '\0';
            xap_path_find = xap_path_substitution;
            xap_path_replacement = comma + 1;
        }
        else
            error("Could not understand the argument to -mpath-subst=...");
    }

#if 0
    if(TARGET_EXTRA_STRUCS)
        set_lang_adjust_rli(xap_note_record_layout);
#endif

    /* function-ptr-pi can only be used in large mode */
    if(TARGET_SMALL_MODE && TARGET_FUNCTION_PTR_PI)
        error("Cannot use -mfunction-ptr-pi in small mode.");
    
}

enum reg_class xap_secondary_reload (bool in_p,
                                     rtx x,
                                     enum reg_class reload_class,
                                     enum machine_mode reload_mode,
                                     secondary_reload_info *sri)
{
    enum reg_class result;
    bool custom_code = false; /* For debugging purposes only */
    int tr;

    /* Can only handle up to SI mode */
    gcc_assert(GET_MODE_SIZE(reload_mode) <= 4);
        
    if((!XAP_MEM_REG_CLASS(reload_class) && reload_class != ALL_REGS)
       || ((REG_P(x) || GET_CODE(x) == SUBREG)
           && (tr = true_regnum(x)) >= 0
           && tr < FIRST_PSEUDO_REGISTER
           && TEST_HARD_REG_BIT(reg_class_contents[CHIP_REGS], tr)))
    {
        /* CHIP_REG <-> anything can be done directly, in any mode. */
        result = NO_REGS;
    }
    else if(GET_MODE_SIZE(reload_mode)==4)
    {
        sri->icode = reload_mode==SFmode ? CODE_FOR_movsf_via_chipreg
                                         : CODE_FOR_movsi_via_chipreg;
        sri->extra_cost = 4;
        result = NO_REGS;
        custom_code = true;
    }
    else if(GET_MODE_SIZE(reload_mode)==2)
    {        
        sri->icode = (reload_mode==HFmode)
                            ? ( (in_p) ? CODE_FOR_movhf_via_chipreg_in
                                       : CODE_FOR_movhf_via_chipreg_out)
                            : ( (in_p) ? CODE_FOR_movhi_via_chipreg_in
                                       : CODE_FOR_movhi_via_chipreg_out) ;
        sri->extra_cost = 2;
        result = NO_REGS;
        custom_code = true;
    }
    else
    {
        result = CHIP_REGS; 
    }

    if(TARGET_NOISY)
    {
        fprintf(stderr, "== SECREL[");
        xap_current_pass(stderr);
        fprintf(stderr, "]: ");
        fprintf(stderr,
                "%s %10s %s %10s %s ",
                GET_MODE_NAME(reload_mode),
                reg_class_names[reload_class],
                in_p?"<-":"->",
                (sri->icode < CODE_FOR_nothing) ? (custom_code ? "<scratch>c" : "<scratch>") : reg_class_names[result],
                in_p?"<-":"->");
        print_inline_rtx(stderr,x,16);
        fprintf(stderr,"==\n");
    }

    return result;
}

rtx xap_return_addr_rtx(int count, rtx frameaddr ATTRIBUTE_UNUSED)
{
    if (count != 0)
        return NULL_RTX;

    if (xap_leaf_function_optim(get_frame_size()))
        return gen_rtx_REG(Pmode, RXL);
    else
        return get_hard_reg_initial_val (Pmode, RXL);
}

int xap_leaf_function_optim(HOST_WIDE_INT size)
{
    return   !TARGET_ALWAYS_ENTER
          && current_function_is_leaf
          && size == 0
          && ! df_regs_ever_live_p(RXH)
          && ! df_regs_ever_live_p(RXL)
          && current_function_outgoing_args_size == 0;
}

HOST_WIDE_INT xap_total_frame_size(HOST_WIDE_INT local)
{
    return   local
           + current_function_outgoing_args_size
           + (xap_leaf_function_optim(local) ? 0 : TARGET_SMALL_MODE ? 1 : 2);
}

HOST_WIDE_INT xap_initial_elimination_offset(int fromreg, int toreg)
{
    HOST_WIDE_INT offset;
    
    if (toreg != RSP && toreg != RFP) 
        abort();

    if (fromreg == RAP)
        offset = xap_total_frame_size(get_frame_size());
    else if (fromreg == RFP || fromreg == RSP)
        offset = 0;
    else
        abort();

    if(TARGET_NOISY)
    {
        fprintf(stderr, "== INITIAL_ELIMINATION_OFFSET[");
        xap_current_pass(stderr);
        fprintf(stderr, "] Function: %s :: %s -> %s : %ld ==\n",
                IDENTIFIER_POINTER(DECL_NAME(current_function_decl)),
                reg_names[fromreg],
                reg_names[toreg],
                offset);
    }
    
    return offset;
}

/* Helper: Return size of a function argument of type TYPE and mode MODE */
HOST_WIDE_INT xap_arg_size(int mode, const_tree type)
{
    if(mode==BLKmode)
        return int_size_in_bytes(type);
    else
        return GET_MODE_SIZE(mode);
}

rtx xap_function_arg(CUMULATIVE_ARGS cum,
                     int mode,
                     tree type,
                     int named)
{
    HOST_WIDE_INT size = xap_arg_size(mode,type);

    switch (size)
    {
        case 2:
            if(cum==0)
                return gen_rtx_REG(mode,RAH);
            else if (xap_arg_partial_bytes(&cum,mode,type,named))
                return gen_rtx_REG(QImode,RAH);
            else
                return 0;
        case 1:
            if(cum < (named?2:1))
            {
                if(TARGET_ALT_CALLING_CONVENTION)
                    return gen_rtx_REG(mode,cum ? RAL:RAH);
                else
                return gen_rtx_REG(mode,cum ? RAH:RAL);
            }
            else 
                return 0;
        default:
            return 0;
    }
}

static int xap_arg_partial_bytes(CUMULATIVE_ARGS *cum,
                                         enum machine_mode mode,
                                         tree type,
                                         bool named)
{
    return    !TARGET_NO_SPLIT_ARGS
           && *cum==1
           && named
           && xap_arg_size(mode,type) == 2;
}

static bool xap_pass_by_reference(CUMULATIVE_ARGS *cum ATTRIBUTE_UNUSED,
                                         enum machine_mode mode,
                                         const_tree type,
                                         bool named ATTRIBUTE_UNUSED)
{
    return TARGET_BY_REFERENCE ? xap_arg_size(mode,type) > 2
                                    : 0;
}

static bool xap_callee_copies(CUMULATIVE_ARGS *cum ATTRIBUTE_UNUSED,
                                     enum machine_mode mode ATTRIBUTE_UNUSED,
                                     const_tree type ATTRIBUTE_UNUSED,
                                     bool named ATTRIBUTE_UNUSED)
{
    return 1;
}

rtx xap_libcall_value(int mode)
{
    switch(mode)
    {
        case QImode:
            if(!TARGET_ALT_CALLING_CONVENTION)
                return gen_rtx_REG(mode,RAL);
            /* else fall through */
        case HImode:
        case HFmode: return gen_rtx_REG(mode,RAH);
        case SFmode:
        case SImode:
            return gen_rtx_REG(mode,RFFF8);
        default:
            fprintf(stderr,"xap_libcall_value passed unhandled mode %s\n",GET_MODE_NAME(mode));
            abort();
    }
}

static rtx xap_function_value(const_tree ret_type,
                                     const_tree fn_decl_or_type ATTRIBUTE_UNUSED,
                                     bool outgoing ATTRIBUTE_UNUSED)
{
    return LIBCALL_VALUE(TYPE_MODE(ret_type));
}

static bool xap_return_in_memory(const_tree type, const_tree fntype ATTRIBUTE_UNUSED)
{
    return int_size_in_bytes(type) > 2;
}

static rtx xap_struct_value_rtx(tree fndecl ATTRIBUTE_UNUSED,
                                       int incoming ATTRIBUTE_UNUSED)
{
    return gen_rtx_REG(Pmode,RFFF8);
}

void xap_mark_frame_related(rtx insn)
{
    /* Mark INSN as being frame related.  If it is a PARALLEL
       then mark each element as being frame related as well.

       RTX_FRAME_RELATED_P is used to control optimisation, and to notify
       var-tracking.c that it should pay attention. All insns comprising
       a function's prologue should have this flag set. */

    RTX_FRAME_RELATED_P (insn) = 1;
    insn = PATTERN (insn);

    if (GET_CODE (insn) == PARALLEL)
    {
        int i;
        for (i = 0; i < XVECLEN (insn, 0); i++)
        {
                RTX_FRAME_RELATED_P (XVECEXP (insn, 0, i)) = 1;
        }
    }
}

void
xap_expand_prologue(void)
{
    rtx insn;
    HOST_WIDE_INT size = get_frame_size();
    if(!TARGET_NO_SPLIT_ARGS && current_function_pretend_args_size)
    {
        rtx rsp = gen_rtx_REG(QImode,RSP);
        insn = emit_insn(gen_subqi3(rsp,rsp,GEN_INT(current_function_pretend_args_size)));
        xap_mark_frame_related(insn);
    }
    
    if(!xap_leaf_function_optim(size))
    {
        if (TARGET_SMALL_MODE)
            insn = emit_insn(gen_enter(GEN_INT(xap_total_frame_size(size))));
        else
            insn = emit_insn(gen_enterl(GEN_INT(xap_total_frame_size(size))));
        xap_mark_frame_related(insn);
    }
}

void xap_expand_epilogue(int sibcall_p) 
{
    /* 
     * style is either 0 or 1. 0 means 'do a normal return epilogue'.
     * 1 means 'try to do a sibcall epilogue if it is worth it'.
     *
     * ---------
     *
     * A _full_ sibcall [B-26003] is composed of 4 instructions:
     * ld    X,@(?,Y)
     * ld    XH,@(?,Y)
     * add   Y,#?
     * bra   sibling
     *
     * For the optimization to be worth it (compared to a bsr/leave pair), 
     * it is important to only actually 
     * do sibcall _if_ we can eliminate 2 or 3 of these.
     */
    HOST_WIDE_INT size = get_frame_size();
    HOST_WIDE_INT total_size = xap_total_frame_size(size);
    rtx rsp = gen_rtx_REG(QImode,RSP);
    rtx rxh = gen_rtx_REG(QImode,RXH);
    rtx rxl = gen_rtx_REG(QImode,RXL);
   
    bool emit_move_rxl_p = df_regs_ever_live_p(RXL) || !current_function_is_leaf;
    bool emit_move_rxh_p = (df_regs_ever_live_p(RXH) || !current_function_is_leaf) && (!TARGET_SMALL_MODE);
    bool emit_add_p = (total_size + current_function_pretend_args_size) > 0;

    if(TARGET_NOISY)
    {
        fprintf(stderr, "== Function stats (at expand epilogue):\n\
\tName: %s\n\
\tOutgoing args size: %d\n\
\tPretend args size: %d\n\
\tFrame size: %ld\n\
\tTotal Frame Size: %ld\n\
\tSibcall?: %d\n\
\tLeaf?: %d\n\
\tXL is live?: %d\n\
\tXH is live?: %d ==\n",
                IDENTIFIER_POINTER(DECL_NAME(current_function_decl)),
                current_function_outgoing_args_size,
                current_function_pretend_args_size,
                size,
                total_size,
                sibcall_p,
                current_function_is_leaf,
                df_regs_ever_live_p(RXL),
                df_regs_ever_live_p(RXH));
    }
    
    if(sibcall_p)
    {   
        if(emit_move_rxl_p)
            emit_move_insn(rxl,gen_rtx_MEM(QImode,gen_rtx_PLUS(QImode,rsp,GEN_INT(total_size - (TARGET_SMALL_MODE ? 1 : 2)))));
        
        if(emit_move_rxh_p)
            emit_move_insn(rxh,gen_rtx_MEM(QImode,gen_rtx_PLUS(QImode,rsp,GEN_INT(total_size - 1))));
        
        if(emit_add_p)
            emit_insn(gen_addqi3(rsp,rsp,GEN_INT(total_size + current_function_pretend_args_size)));
        
        if(emit_move_rxl_p)    
            emit_insn(gen_rtx_USE(QImode,rxl));

        if(emit_move_rxh_p)    
            emit_insn(gen_rtx_USE(QImode,rxh));
    } 
    else 
    {   
        if(xap_leaf_function_optim(size))
        {
            emit_jump_insn(gen_return());
        }
        else if(!TARGET_NO_SPLIT_ARGS && current_function_pretend_args_size)
        {
            /* We pushed some extra space on the stack for args that were partially
             * passed in registers. We have to be careful here about where we find X
             * and XH */
            const int x_offset = (TARGET_SMALL_MODE ? -1 : -2) - current_function_pretend_args_size;
            rtx link = gen_rtx_MEM(HImode,
                                   gen_rtx_PLUS(QImode, rsp, GEN_INT(x_offset)));
            
            emit_insn(gen_addqi3(rsp,rsp,GEN_INT(  xap_total_frame_size(size)
                                                   + current_function_pretend_args_size)));
            emit_insn(gen_alternate_leave(link));
        }
        else
            if (TARGET_SMALL_MODE)
                emit_jump_insn(gen_leave(GEN_INT(xap_total_frame_size(size))));
            else
                emit_jump_insn(gen_leavel(GEN_INT(xap_total_frame_size(size))));
    }
    
}

static bool xap_function_ok_for_sibcall (tree decl, tree exp ATTRIBUTE_UNUSED)
{
    int ncallees = 0;
    struct cgraph_edge *edge = NULL;
    struct cgraph_node *node = NULL;
    
    /* 
     * We can only sibcall if we avoid emitting _at least one_ of the
     * three instructions:
     * ld XL, $(?,Y)
     * ld XH, $(?,Y)
     * add ?
     *
     * - ld XL ... is emitted if XL is live or if function is _not_ leaf.
     * - ld XH ... is emitted if XH is live or if function is _not_ leaf.
     * - add ? ... is emitted if the total size or the current_function_pretend_args is positive.
     *
     * By default we return true and only disallow sibcalls in very specific cases. [when we can actually 
     * potentially increase the code size. An heuristic is used to determine if this is the case.
     */
    
    /* No access to decl? Bye Bye */
    if(decl == NULL)
        return false;
    
    /* Check if XH is used at all 
     * XH is used as part of X to pass information regarding 
     * the return address of the caller.
     * It will be used if there is any other call that is not a sibcall.
     *
     * Current testing shows that under the current firmware all 'well-done' sibcalls (i.e. sibcalls
     * that reduced, or kept, the firmware size were calls that either omitted the ld XH or all of 
     * the instructions. Those sibcalls that were not well-done emitted all three instructions.
     * Therefore if we detect when XH is emitted and stop a sibcall if XH has to be emitted then
     * we can about 'bad' sibcalls.
     */

    /* First we need to find the cgraph_node for the actual function. */
    for(node = cgraph_nodes; node; node = node->next)  
        if(!strcmp(cgraph_node_name(node), IDENTIFIER_POINTER(DECL_NAME(current_function_decl))))
            break;

    /* We can't find the node? It's weird but for now it's nothing we can do!
     * Maybe we should print a warning/error?
     */
    if(cgraph_node == NULL)
        return false;

    /* Lets check if there is more than one callee from this node. */
    for(edge = node->callees; edge; edge = edge->next_callee)
        if(++ncallees > 1)
            return false;

    return true;
}


static bool xap_legitimate_base_reg(int mode ATTRIBUTE_UNUSED, rtx x, enum xap_reg_ok strictness)
{
    if(GET_CODE(x)!=REG) return false;

    if(strictness==XAP_REG_OK_STRICT)
        return REG_OK_FOR_BASE_P_STRICT(x);
    else if(strictness==XAP_REG_OK_LAX)
        return REG_OK_FOR_BASE_P_LAX(x);
    else
        abort();
}

bool xap_legitimate_address(int mode,
                            rtx x,
                            enum xap_reg_ok strictness)
{
    if(   xap_legitimate_base_reg(mode,x,strictness)
       || CONSTANT_ADDRESS_P(x)
       || (    GET_CODE(x)==PLUS
            && xap_legitimate_base_reg(mode,XEXP(x,0),strictness)
            && (   GET_CODE(XEXP(x,1)) == CONST
                || GET_CODE(XEXP(x,1)) == CONST_INT
                || GET_CODE(XEXP(x,1)) == SYMBOL_REF
                || GET_CODE(XEXP(x,1)) == LABEL_REF
               )
           )
      )
    {
        return true;
    }
    else
    {
        return false;
    }
}

void xap_notice_update_cc(rtx exp ATTRIBUTE_UNUSED, rtx insn)
{
    enum attr_cc cc = get_attr_cc(insn);
    rtx set;
        
    switch(cc)
    {
        case CC_NONE:
            /* B-127521: assume the worst and reset CC */
        case CC_CLOBBER:
            /* Insn doesn't leave CC in a usable state.  */
            CC_STATUS_INIT;
            break;

        case CC_COMPARE:
            /* The insn is a compare instruction.  */
            CC_STATUS_INIT;
            set = single_set(insn);
            if(set)
                cc_status.value1 = SET_SRC(set);
            break;

        case CC_SET_CSNZ:
        case CC_SET_NZ:
            CC_STATUS_INIT;
            set = single_set(insn);
            if(set)
            {
                rtx dest = SET_DEST(set);
                rtx source = SET_SRC(set);

                if(rtx_equal_p(dest,cc0_rtx))
                {
                    cc_status.value1 = source;
                }
                else if(!rtx_equal_p(dest, source))
                {
                    rtx sub_expr = source;
                   
                    while (GET_CODE (sub_expr) == MEM || GET_CODE (sub_expr) == PLUS)
                    {
                        sub_expr = XEXP(sub_expr,0);
                    }

                    cc_status.value1 = dest;
                 
                    /* B-155661: Don't assume the source expression is always
                     * unchanged by writing to the dest expression. Specifically,
                     * avoid cases where a write to a register changes the value 
                     * of a memory access indexed via that register.
                     */
                    if (!rtx_equal_p(dest, sub_expr))
                    {
                         /* safe to assume SET_SRC(set) is equivalent to SET_DEST(src)
                          * for purposes of condition code evaluation
                          */
                         cc_status.value2 = source;
                    }
                }
                cc_status.flags |= CC_NO_OVERFLOW;
            }
            break;

        case CC_SET_C:
            CC_STATUS_INIT;
            break;
    }
}

static bool xap_expensive_constant(rtx x)
{
    return    GET_CODE(x) == SYMBOL_REF
           || GET_CODE(x) == LABEL_REF
           || GET_CODE(x) == CODE_LABEL
           || (   GET_CODE(x) == CONST_INT 
               && (   INTVAL(x) < -128
                   || INTVAL(x) > 127));
}

/* XXX true for fast flash? Also, note that "If reload sees an insn consisting
 * of a single set between two hard registers, and if REGISTER_MOVE_COST applied
 * to their classes returns a value of 2, reload does not check to ensure that
 * the constraints of the insn are met."
 */
int xap_register_move_cost(enum machine_mode mode, int from, int to)
{
    int cost = 0;


    if((from == ALL_REGS || XAP_MEM_REG_CLASS(from))
       && (to == ALL_REGS || XAP_MEM_REG_CLASS(to)))
        cost = 4;
    else if(from == ADDR_REGS && to == ADDR_REGS)
        cost = 0;
    else
        cost = 2;
    
    cost *= GET_MODE_SIZE(mode);
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== REGMOVCOST [");
        xap_current_pass(stderr);
        fprintf(stderr, "]: %s --(%s)--> %s => %d==\n", 
                reg_class_names[from], 
                GET_MODE_NAME(mode), 
                reg_class_names[to],
                cost);
    }
    
    return cost;
}

int xap_memory_move_cost(enum machine_mode mode, int rclass, bool in)
{

    int cost = 0;
    
    if(rclass == ALL_REGS || XAP_MEM_REG_CLASS(rclass))
        cost = 4;
    else
        cost = 2;

    /* We don't like mem moves in general B-97268*/
    cost++;

    /* Bigger size... higher cost! */
    cost *= GET_MODE_SIZE(mode);
        
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== MEMMOVCOST [");
        xap_current_pass(stderr);
        fprintf(stderr, "]: %s move %s %s mem ==> %d ==\n",
                GET_MODE_NAME(mode),
                reg_class_names[rclass],
                in ? "from" : "into",
                cost);
    }
    
    return cost;
}

int xap_branch_cost(void)
{
    int cost = 0;
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== BRACOST [");
        xap_current_pass(stderr);
        fprintf(stderr, "]: ==> %d ==\n", cost);
    }

    return cost;
}

static bool xap_rtx_costs(rtx x,
                          int code,
                          int outer_code,
                          int *total)
{
    /* The hook returns true when all subexpressions of x have
     * been processed, and false when xap_rtx_cost should recurse. 
     */
    bool all_done = false;
    const enum machine_mode xmode = GET_MODE(x);
    
    if(optimize_size)
    {
        *total = 0;
        
        if(xap_expensive_constant(x))
        {
            *total += COSTS_N_INSNS(0) + 1;
            all_done = true;
        }
        else
        {
            /* Special Cases */
            if(outer_code == SET && xmode == HImode)
                *total += COSTS_N_INSNS(1);
            
            switch(code) {
                case CONST_INT: /* Integer Constants have no cost by themselves */
                    *total += COSTS_N_INSNS(0);
                    all_done = true;
                    break;
                case CONST:
                case SET:
                    *total += COSTS_N_INSNS(0);
                    break;
                case MULT:
                    if(GET_CODE(XEXP(x,1)) != ZERO_EXTEND)
                        *total += COSTS_N_INSNS(1);
                    else
                        *total += COSTS_N_INSNS(2);
                    break;
                case DIV:
                case MOD:
                    *total += COSTS_N_INSNS(1);
                    break;
                case UDIV:
                case UMOD:
                    *total += COSTS_N_INSNS(2);
                    break;
                    
                    /* Taking care of the shifts
                     * asl == lsl == asr == 1 word
                     * lsr == 2 words
                     */
                case ASHIFT: /* arith shift left (same as log shift left) */
                case ASHIFTRT: /* arith shift right */
                    *total += COSTS_N_INSNS(1);
                    break;
                case LSHIFTRT:
                    *total += COSTS_N_INSNS(2);
                    break;
                default:
                    *total += COSTS_N_INSNS(1);
            }
        }
    }
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== RTXCOST[");
        xap_current_pass(stderr);
        fprintf(stderr, "]: %s ", rtx_name[outer_code]);
        print_inline_rtx(stderr, x, 0);
        fprintf(stderr, " => %d [%s]==\n", *total, all_done ? "done" : "rec");
    }
    
    return all_done;
}

static int xap_address_cost(rtx address)
{
    int cost = 0;
    
    while(GET_CODE(address) == CONST)
        address = XEXP(address, 0);

    /* Expensive addresses:
     *
     * (sym)
     * (plus (sym) ...)
     * (plus ... (sym))
     * (plus (reg) (const_int x)) if x needs a prefix
     * (plus (reg) (plus (sym) ...))
     */
    if(   xap_expensive_constant(address)
       || (   GET_CODE(address) == PLUS
           && xap_expensive_constant(XEXP(address,0)))
       || (   GET_CODE(address) == PLUS
           && REG_P(XEXP(address,0))
           && (   xap_expensive_constant(XEXP(address,1))
               || (   GET_CODE(XEXP(address,1)) == PLUS
                      && xap_expensive_constant(XEXP(XEXP(address,1),0)))))) 
        cost = COSTS_N_INSNS(2);
    else 
        cost = COSTS_N_INSNS(1);

    if(TARGET_NOISY)
    {
        fprintf(stderr, "== ADRCOST[");
        xap_current_pass(stderr);
        fprintf(stderr, "]:");
        print_inline_rtx(stderr, address, 0);
        fprintf(stderr, " => %d==\n", cost);
    }    

    return cost;
}

section *initc_section;

static void xap_asm_init_sections(void)
{
    initc_section = get_unnamed_section (0,
                                         output_section_asm_op,
                                         TARGET_AS_MODE?"\t.rodata":"\t.SEG INITC");
    
    bss_section = get_unnamed_section (SECTION_WRITE | SECTION_BSS,
                                       xap_bss_section_asm_op,
                                       0);
}

typedef struct linkinfo
{
    struct linkinfo *next;
    char *symbol;
    bool declared;
}
linkinfo;

static linkinfo *lif;

static void xap_add_linkinfo(const char *name, bool declared)
{
    linkinfo **p = &lif;

    if(*name == '*') name ++;
    if(*name == '$') name ++;

    while(*p)
    {
        if(strcmp((*p)->symbol,name)==0)
        {
            /* Only mark undeclared things declared, not vice versa. */
            if(declared)
                (*p)->declared = declared;
            return;
        }
        p = &((*p)->next);
    }

    *p = (linkinfo*) xmalloc(sizeof(linkinfo));
    (*p)->next = 0;
    (*p)->symbol = xstrdup(name);
    (*p)->declared = declared;
    
}

static bool xap_reserved_name(const char *name);

static void xap_output_linkinfo_once(bool declared)
{
    linkinfo *p = lif;
    
    for(p=lif;p;p=p->next)
    {
        if(   p->declared == declared
           && (!declared || xap_find_global(p->symbol,XAP_GLOBAL_FIND)))
        {
            fprintf(asm_out_file,";LIF ");
            assemble_name(asm_out_file,p->symbol);
            fprintf(asm_out_file,"\n");
        }
    }

}

static void xap_free_linkinfo(void)
{
    while(lif)
    {
        linkinfo *p = lif->next;
        free(lif->symbol);
        free(lif);
        lif = p;
    }
}

static void xap_output_linkinfo(void)
{
    if(!TARGET_NO_LIF && !TARGET_AS_MODE)
    {
        fprintf(asm_out_file,"\n;LIF .DECLARED\n");
        xap_output_linkinfo_once(TRUE);
        fprintf(asm_out_file,";LIF .UNDECLARED\n");
        xap_output_linkinfo_once(FALSE);
        fprintf(asm_out_file,";LIF .END\n\n");
        xap_free_linkinfo();
    }
}

section * xap_asm_select_section (tree exp,
                                  int reloc,
                                  unsigned HOST_WIDE_INT align)
{
    if (TARGET_AS_MODE)
        return default_elf_select_section(exp, reloc, align);

    /* The following munged from default_elf_select_section in varasm.c */
    switch (categorize_decl_for_section (exp, reloc))
    {
        case SECCAT_TEXT:
            /* We're not supposed to be called on FUNCTION_DECLs.  */
            gcc_unreachable ();
        case SECCAT_RODATA:
        case SECCAT_RODATA_MERGE_STR:
        case SECCAT_RODATA_MERGE_STR_INIT:
        case SECCAT_RODATA_MERGE_CONST:
        case SECCAT_SRODATA:
        case SECCAT_DATA_REL_RO:
            return readonly_data_section;
        case SECCAT_DATA:
        case SECCAT_DATA_REL:
        case SECCAT_DATA_REL_LOCAL:
        case SECCAT_DATA_REL_RO_LOCAL:
        case SECCAT_SDATA:
        case SECCAT_TDATA:
            return data_section;
        case SECCAT_BSS:
        case SECCAT_SBSS:
        case SECCAT_TBSS:
            return bss_section;
        default:
        ;
    }

    gcc_unreachable ();
}

static void xap_encode_section_info(tree decl,
                                    rtx rtl,
                                    int first)
{
    const char *name = XSTR(XEXP(rtl,0),0);

    if(TARGET_NO_LIF) return;

    gcc_assert(name);
    gcc_assert(decl);

    xap_maybe_globalize_next_label(XEXP(rtl,0));

    if(DECL_P(decl))
    {
        if(DECL_EXTERNAL(decl) && TREE_PUBLIC(decl) && TREE_USED(decl))
            xap_add_linkinfo(name,FALSE);
        else if(!DECL_EXTERNAL(decl) && TREE_PUBLIC(decl))
            xap_add_linkinfo(name,TRUE);
    }
    
    /* Call default */
    default_encode_section_info(decl, rtl, first);
}

static char *xap_module_name = 0;

static void xap_asm_file_start(void)
{
    char *p, *tmp;
    const char * const mif = aux_base_name;

    default_file_start();

    /* Get base name of output file for module name
     * XXX This'll break if anyone has several source files with the same name.
     */

    gcc_assert(mif);
    gcc_assert(*mif);

    tmp = (char*) alloca(strlen(mif)+1);
    strcpy(tmp,mif);

    if(   (p = strrchr(tmp,'/'))
       || (p = strrchr(tmp,'\\')) ) tmp = p+1;

    gcc_assert(*tmp);
    
    free(xap_module_name);
    xap_module_name = (char *)xmalloc(strlen(tmp)+1);
    strcpy(xap_module_name,tmp);

    for(p=xap_module_name;*p;p++)
        if(!isalnum(*p)) *p = '_';

    /* First character needs to be a letter, _ or ? */
    if(!isalpha(xap_module_name[0]) && 
       xap_module_name[0] != '_' &&
       xap_module_name[0] != '?')
      xap_module_name[0] = (xap_module_name[0] % 26) + 65;

    if(TARGET_AS_MODE)
    {
        output_file_directive(asm_out_file, main_input_filename);
        fprintf(asm_out_file,"\t.variant xap2+\n\n");
        fprintf(asm_out_file,"\t.%s\n\n", TARGET_SMALL_MODE ? "small" : "large");
    }
    else
    {
        fprintf(asm_out_file,"\tMODULE\t%s\n\n",xap_module_name);
        fprintf(asm_out_file,"\t.ENHANCED\n");
        fprintf(asm_out_file,"\t%s\n\n", TARGET_SMALL_MODE ? ".SMALL" : ".LARGE");
    }
}

static void xap_maybe_globalize_next_label(rtx symref)
{
    const_tree decl = SYMBOL_REF_DECL(symref);
    if(   decl
            && (   TREE_CODE(decl)==FUNCTION_DECL
                || TREE_CODE(decl)==VAR_DECL)
            && TREE_PUBLIC(decl))
    {
        (void) xap_find_global(XSTR(symref,0),XAP_GLOBAL_ADD);
    }
}

/* Outputs code to asm_out_file to allocate space for rtx x.
   size is in words */
static bool xap_asm_integer(rtx x,
                                   unsigned int size,
                                   int aligned_p ATTRIBUTE_UNUSED)
{
    static const char *selecters[] = { "hwrd", "lwrd" };
    int i;

    if(size>2) return FALSE;

    switch(GET_CODE(x))
    {
        case CONST:
            return xap_asm_integer(XEXP(x,0),size,aligned_p);

        case CONST_INT:
            if(size>1)
                return FALSE;
            /* else fall through */
        case SYMBOL_REF:
            if(size==1)
            {
                if(TARGET_AS_MODE)
                    fprintf(asm_out_file,"\t.word\t");
                else
                    fprintf(asm_out_file,"\tDC\t");
                xap_print_operand(asm_out_file,x,XAP_NO_DECORATION);
                fprintf(asm_out_file,"\n");
            }
            else if(size==2)
            {
                for(i=0;i<2;i++)
                {
                    if(TARGET_AS_MODE)
                        fprintf(asm_out_file,"\t.word\t%s(",selecters[i]);
                    else
                        fprintf(asm_out_file,"\tDC\t%s(",selecters[i]);
                    xap_print_operand(asm_out_file,x,XAP_NO_DECORATION);
                    fprintf(asm_out_file,")\n");
                }
            }
            else
                abort();
            break;

        case PLUS:
            if(size==1)
            {
                if(TARGET_AS_MODE)
                    fprintf(asm_out_file,"\t.word\t");
                else
                    fprintf(asm_out_file,"\tDC\t");
                xap_print_operand(asm_out_file,x,XAP_NO_DECORATION);
                fprintf(asm_out_file,"\n");
            }
            else if (size==2)
            {
                for(i=0;i<2;i++)
                {
                    if(TARGET_AS_MODE)
                        fprintf(asm_out_file,"\t.word\t%s(",selecters[i]);
                    else
                        fprintf(asm_out_file,"\tDC\t%s(",selecters[i]);
                    xap_print_operand(asm_out_file,XEXP(x,0),XAP_NO_DECORATION);
                    if(GET_CODE(XEXP(x,1))==CONST_INT)
                        fprintf(asm_out_file,"%+ld",INTVAL(XEXP(x,1)));
                    else
                        xap_print_operand(asm_out_file,XEXP(x,0),XAP_NO_DECORATION);
                    fprintf(asm_out_file,")\n");
                }
            }
            else
                abort();

            break;

        default:
            print_inline_rtx(asm_out_file,x,0);
            fprintf(stderr,"xap_asm_integer failed to handle this (size %d):\n",size);
            debug_rtx(x);
            abort();
    }
    return TRUE;
}

void xap_asm_output_wchars(FILE *file, const unsigned short *ptr, unsigned int len)
{
    unsigned int i;
    for(i=0;i<len;i++)
    {
        if(TARGET_AS_MODE)
            fprintf(file,"\t.word\t0x%.4X", ptr[i]);
        else
            fprintf(file,"\tDC\tH'%.4X", ptr[i]);
        if(!(ptr[i]&0xff80) && isprint((char)ptr[i]))
            fprintf(file,"\t; \"%c\"",(char)ptr[i]);
        fprintf(file,"\n");
    }
}

void xap_asm_output_ascii(FILE *file, const char *ptr, unsigned int len)
{
    if(TARGET_AS_MODE)
    {
        unsigned i, ch;
        const unsigned char *uptr = (const unsigned char *)ptr;
        if(TARGET_PACK_STRINGS)
            fprintf(file, "\t.pascii \"");
        else
            fprintf(file, "\t.ascii \"");
        for( i=0; i<len; i++ )
        {
            ch = uptr[i];
            if(ch == '\b')
                fprintf(file, "\\b");
            else if(ch == '\t')
                fprintf(file, "\\t");
            else if(ch == '\n')
                fprintf(file, "\\n");
            else if(ch == '\f')
                fprintf(file, "\\f");
            else if(ch == '\r')
                fprintf(file, "\\r");
            else if(ch == '\0')
                fprintf(file, "\\000");
            else if(ch == '\"')
                fprintf(file, "\\\"");
            else if(ch == '\\')
                fprintf(file, "\\\\");
            else if(!isprint(ch))
                fprintf(file, "\\%03o", ch);
            else
                putc(ch, file);
        }
        fprintf(file, "\"\n");

        if(TARGET_PACK_STRINGS)
            fprintf(file, "\t.align 1\n");
    }
    else
    {
        unsigned int i;
        for(i=0;i<len;i++)
        {
            int n = flag_signed_char ? (int)(signed char) ptr[i]
                                     : (int)(unsigned char) ptr[i];
            fprintf(file,"\tDC\tH'%.2X", n);
            if(isprint(ptr[i])) fprintf(file,"\t; \"%c\"",ptr[i]);
            fprintf(file,"\n");
        }
    }
}

static void xap_asm_file_end(void)
{
    xap_output_record_layouts();
    xap_output_linkinfo();
    if(!TARGET_AS_MODE)
        fprintf(asm_out_file, "\tENDMOD\n");
}

static void xap_asm_named_section(const char *name,
                                         unsigned int flags,
                                         tree decl ATTRIBUTE_UNUSED)
{
    if(TARGET_AS_MODE)
    {
        /* Debug sections should not have allocatable attributes,
           this also has the advantage of handling the full range of flags */
        default_elf_asm_named_section(name, flags, decl);
    }
    else if(flags & SECTION_CODE)
        asm_fprintf(asm_out_file, "\t.CSEG\t%s\n", name);
    else
        asm_fprintf(asm_out_file, "\t.SEG\t%s\n", name);
}

/* These are reserved words in the assembler (copied from the user manual), so
 * can't be used as symbols. */
static const char *xap_reserved[] = 
{ /* Registers */
  "al", "sp", "uy", "xh", "ah", "ux", "x", "y", "flags",
  /* Operators */
  "abs",   "frman", "length", "pasc",  "and",   "ge",  "logic",
  "shl",   "e",     "gt",     "lt",    "shr",   "eq",  "hwrd",
  "lwrd",  "xor",   "fexp",   "index", "mod",   "+",   "fman",
  "int",   "ne",    "-",      "frbit", "ldexp", "not", "*", 
  "frexp", "le",    "or",     "/",
  0
};

static const char *xap_reserved_case_sensitive[] =
{ "$XAP_AH",  "$XAP_AL", "$XAP_UXH", "$XAP_UXL", "$XAP_UY", 0 };

static bool xap_reserved_name(const char *name)
{
    const char **p = xap_reserved;

    while(*p)
        if(!strcasecmp(name,*p++)) return TRUE;

    p = xap_reserved_case_sensitive;

    while(*p)
        if(!strcmp(name,*p++)) return TRUE;

    return FALSE;
}

static void xap_maybe_mark_public(FILE *stream, const char *name, const_tree decl)
{
    if(   TARGET_AS_MODE
       && decl
       && DECL_P(decl)
       && TREE_PUBLIC(decl)
       && DECL_ATTRIBUTES(decl)
       && lookup_attribute("public", DECL_ATTRIBUTES(decl)) != NULL_TREE)
        fprintf(stream, "\t.public %s\n", name);
}

void xap_asm_output_aligned_decl_common(FILE *stream,
                                        const_tree decl,
                                        const char *name,
                                        unsigned int size,
                                        unsigned int alignment)
{
    bool global = TREE_CODE(decl)==VAR_DECL && TREE_PUBLIC(decl);
    
    if(global)
        xap_find_global(name,XAP_GLOBAL_ADD);

    if(TARGET_AS_MODE)
    {
        if(!global)
        {
            fprintf(stream, ".local ");
            assemble_name(stream, name);
            fprintf(stream, "\n");
        }
            
        fprintf(stream, "\t.comm ");
        assemble_name(stream, name);
        fprintf(stream, ", %u, %u\n", size, alignment/BITS_PER_UNIT);

        xap_maybe_mark_public(stream, name, decl);

        fprintf(stream, "\n");
    }
    else
    {
        const_tree type;
        const char *tag = 0;

        gcc_assert(decl);
        gcc_assert(TREE_TYPE(decl));
        
        type = TREE_TYPE(decl);

        if(   !TARGET_NO_STRUC
           && TREE_CODE(type)==RECORD_TYPE)
            tag = xap_output_record_type(stream,type);
    
        switch_to_section(bss_section);
        assemble_name(stream,name);
        
        if(tag)
            fprintf(stream,"\t%s\n",tag);
        else
            fprintf(stream,":\n\n\tDS\t%d\n",size);
    }
}

/* Outputs a ".size name, size" directive. */
void xap_asm_output_size_directive(FILE *stream, const char *name, int size)
{
    if (TARGET_AS_MODE)
    {
        fputs (SIZE_ASM_OP, stream);
        assemble_name (stream, name);
        fprintf (stream, ", %d\n", size);
    }
    else
    {
        ASM_OUTPUT_LABEL(stream, name);
        fprintf(stream, "\tDS\t%d\n", size);
    }
}

/* Outputs a ".type name, @type" directive. */
void xap_asm_output_type_directive(FILE *stream, const char *name, const char *type)
{
    if(TARGET_AS_MODE)
    {
        fputs (TYPE_ASM_OP, stream);
        assemble_name (stream, name);
        fprintf (stream, ", @%s", type);
        putc ('\n', stream);
    }
}

void xap_asm_declare_function_size(FILE *stream, const char *name, tree decl) 
{
    static const char prefix[] = "__size_of_";
    char *label = alloca(strlen(name) + sizeof(prefix));
    char *fn_sym;
    size_t n_value;
    char *value;
    
    if (TARGET_AS_MODE && !flag_inhibit_size_directive)
    {
        fputs (SIZE_ASM_OP, stream);
        assemble_name (stream, name);
        fputs (", .-", stream);
        assemble_name (stream, name);
        putc ('\n', stream);
    }

    if (TARGET_AS_MODE && TARGET_NO_FUNCTION_SIZEOF)
        return;

    strcpy(label, prefix);
    strcat(label, name);
    
    if(TREE_PUBLIC(decl))
      xap_asm_globalize_label(stream, label);

    xap_maybe_mark_public(stream, label, decl);

    fn_sym = xap_asm_mk_labelref(name);

    /* 5 is the number of extra characters in the final string:
     * 2 spaces
     * 1 '-'
     * 1 TARGET_AS_MODE char
     * 1 final char \0
     */
    n_value = strlen(fn_sym) + 5;
    value = alloca(n_value);
    
    snprintf(value, n_value, "%c - %s",
             TARGET_AS_MODE ? '.' : '$',
             fn_sym);
    
    ASM_OUTPUT_DEF(stream, label, value);
    
    free(fn_sym);   
}

/* "output to the stdio stream STREAM any text necessary for declaring the name
 * name of an initialized variable which is being defined. This macro must
 * output the label definition (perhaps using ASM_OUTPUT_LABEL)." */
void xap_asm_declare_object_name(FILE *stream, const char *name, tree decl)
{
    if(TARGET_AS_MODE)
    {
        /* Write the extra assembler code needed to declare an object properly.  */
        HOST_WIDE_INT size;
        ASM_OUTPUT_TYPE_DIRECTIVE (stream, name, "object");

        size_directive_output = 0;
        if (!flag_inhibit_size_directive && decl && DECL_SIZE (decl))
        {
            size_directive_output = 1;
            size = int_size_in_bytes (TREE_TYPE (decl));
            ASM_OUTPUT_SIZE_DIRECTIVE (stream, name, size);
        }

        xap_maybe_mark_public(stream, name, decl);

        ASM_OUTPUT_LABEL(stream,name);
        return;
    }

    if(!DECL_SIZE(decl)) abort();
    
    if(   in_section == readonly_data_section
       || in_section == bss_section
       || TARGET_NO_INITC)
    {
        ASM_OUTPUT_LABEL(stream,name);
    }
    else
    {
        int size;

        ASM_OUTPUT_LABEL(stream,name);
        size = TREE_INT_CST_LOW(DECL_SIZE(decl))/BITS_PER_UNIT;

        if(TARGET_AS_MODE)
            fprintf(stream,"\t.space\t%d\n",size);
        else
            fprintf(stream,"\tDS\t%d\n",size);

        switch_to_section(initc_section);
    }
}

/* If the size of an object is not known when declare_object_name is called,
   output it at the end. size_directive_output is used for communication
   between declare_object_name and this function */
void xap_asm_finish_declare_object(FILE *stream, tree decl, int top_level, int at_end)
{
    const char *name = XSTR (XEXP (DECL_RTL (decl), 0), 0);
    HOST_WIDE_INT size;

    if (TARGET_AS_MODE)
    {
        if (!flag_inhibit_size_directive
            && DECL_SIZE (decl)
            && ! at_end && top_level
            && DECL_INITIAL (decl) == error_mark_node
            && !size_directive_output)
        {
            size_directive_output = 1;
            size = int_size_in_bytes (TREE_TYPE (decl));
            ASM_OUTPUT_SIZE_DIRECTIVE (stream, name, size);
        }
    }
}

void xap_asm_declare_function_name(FILE *stream, const char *name, tree decl)
{
    ASM_OUTPUT_TYPE_DIRECTIVE (stream, name, "function");
    xap_maybe_mark_public(stream, name, decl);
    ASM_OUTPUT_LABEL (stream, name);
}

typedef struct xap_label_set
{
    struct xap_label_set *next;
    const char *name;
}
xap_label_set;

/* Set of all labels that have been `globalized' */
xap_label_set *xap_global_label_set = NULL;

static const char *xap_find_global(const char *name,
                                   enum xap_find_global_action action)
{
    xap_label_set **p;

     for(p = &xap_global_label_set ; *p ; p = &(*p)->next)
         if(!strcmp(name,(*p)->name))
             return (*p)->name;

    /* name not found if we get here. p is left pointing to the last `next'
     * pointer, or xap_global_label_set if the set was empty. */

    if(action == XAP_GLOBAL_FIND)
       return NULL;
    else if(action == XAP_GLOBAL_ADD)
    {
        *p = (xap_label_set*) xmalloc(sizeof(xap_label_set));
        (*p)->next = 0;
        (*p)->name = xstrdup(name);
        return (*p)->name;
    }
    else abort();
}

static char *xap_asm_mk_labelref(const char *name)
{
    size_t n_sym = strlen(name) + strlen(user_label_prefix) + 10;
    char *sym = xmalloc(n_sym);

    if(TARGET_AS_MODE)
    {
        snprintf(sym, n_sym, "%s%s%s", user_label_prefix,
                 xap_reserved_name(name)?XAP_LABEL_PREFIX:"", name);
    }
    else
    {
        bool global = xap_find_global(name,XAP_GLOBAL_FIND) ? TRUE : FALSE;

        sym[0] = '\0';
        if(global)
            strcat(sym,"$");
        
        strcat(sym,user_label_prefix);
        strcat(sym,name);

        /* Protect xapasm reserved words */
        if(xap_reserved_name(sym))
            strcat(sym,"?");
    }

    return sym;
}

void xap_asm_output_labelref(FILE *stream, const char *name)
{
    char *sym = xap_asm_mk_labelref(name);
    asm_fprintf(stream, "%s", sym);
    free(sym);
}


void xap_asm_globalize_label(FILE *stream, const char *name)
{
    if(TARGET_AS_MODE)
    {
        fprintf(stream,"\t.global\t");
        assemble_name(stream, name);
        putc('\n', stream);
    }
    else
        (void)xap_find_global(name, XAP_GLOBAL_ADD);
}

void xap_asm_external_libcall(rtx symref)
{
    (void) xap_find_global(XSTR(symref,0),XAP_GLOBAL_ADD);
}


static tree
xap_handle_public_attribute (tree *node ATTRIBUTE_UNUSED,
                             tree name ATTRIBUTE_UNUSED,
                             tree args ATTRIBUTE_UNUSED,
                             int flags ATTRIBUTE_UNUSED,
                             bool *no_add_attrs ATTRIBUTE_UNUSED)
{
    gcc_assert(node && *node);

    if(!VAR_OR_FUNCTION_DECL_P(*node))
        error("Attribute \"public\" may only be used with declarations.");

    return NULL_TREE;
}

const struct attribute_spec xap_attribute_table[] =
{
  /* { name, min_len, max_len, decl_req, type_req, fn_type_req, handler } */
  { "public",   0, 0, true, false, false,  xap_handle_public_attribute },
  { NULL,        0, 0, false, false, false, NULL }
};

enum
{
    XAP_BUILTIN_FUNCTION_SIZE
};

static void xap_init_builtins(void)
{
    tree arg_type = build_pointer_type(build_function_type(void_type_node, void_list_node));
    tree function_type = build_function_type_list(size_type_node, arg_type, NULL_TREE);

    add_builtin_function("__function_size",
                         function_type,
                         XAP_BUILTIN_FUNCTION_SIZE,
                         BUILT_IN_MD,
                         NULL,
                         NULL_TREE);
}

static tree xap_fold_builtin(tree fndecl, tree arglist, 
                             bool ignore ATTRIBUTE_UNUSED) 
{
    switch(DECL_FUNCTION_CODE(fndecl))
    {
        case XAP_BUILTIN_FUNCTION_SIZE:
        {
            const_tree fsarg = TREE_VALUE(arglist);
            
            /* Hopefully arg has the function declaration of the function we want to know the size of.
             * Unfortunately this is only the case for void(*)(void) functions, therefore,
             * if this is not a function declaration we need to search through the current function
             * tree the assignment for this function and get the real function decl.
             */

            /* Read the following if sequence as follows:
             * 
             * Operand 3 is a var_decl and Operand 0 of the var_decl is an identifier_node
             * OR 
             * Operand 3 is an addr_expr and Operand 0 of the addr_expr is a function decl
             * OR
             * Operand 3 is a nop_expr and Operand 0 of the nop_expr is an addr_expr and 
             *                                          its operand 0 is a function decl
             */
            tree arg = NULL_TREE;
            
            if(TREE_CODE(fsarg) == VAR_DECL) 
            {
                
                /* OK, we need to do hard work and actually search for the function in the tree. */
                /* Here's what happens:
                 * If a function is not void(*)(void) then, it has to be cast to this type.
                 * therefore something line:
                 * void bar(int) { ... } 
                 * __function_size(bar);
                 *
                 * becomes
                 * void bar(int) { ... } == unchanged
                 * void (*bar.0)(void) = (void(*)(void) bar);
                 * __function_size(bar.0);
                 * 
                 * This is not a happy situation as we now have to find for the definition
                 * of bar.0 and look into the cast expression to finally find bar's fndecl and 
                 * get its name.
                 *
                 * It's a dirty job, I know... but someones gotta do it!
                 */
                const_tree cfndecl = current_function_decl; /* Current function declaration */
                tree stmt = DECL_SAVED_TREE(cfndecl);
                tree_stmt_iterator tsi;
                
                /* Loop through the body statements
                 * until we find the expression 'arg = void(*)(void) func'.
                 */
                for(tsi = tsi_start(stmt); !tsi_end_p(tsi); tsi_next(&tsi)) 
                {
                    const tree cstmt = tsi_stmt(tsi);
                    
                    if(TREE_CODE(cstmt) == GIMPLE_MODIFY_STMT) 
                    {
                        const_tree lhs = GENERIC_TREE_OPERAND(cstmt, 0);
                        const_tree rhs;
                        
                        if(!DECL_NAME(lhs)) 
                            continue;
                        
                        rhs = GENERIC_TREE_OPERAND(cstmt, 1);
                        
                        /* Does the lhs match our variable? */
                        if(TREE_CODE(lhs) == VAR_DECL && TREE_CODE(rhs) == NOP_EXPR) 
                        {
                            
                            const char *namelhs = IDENTIFIER_POINTER(DECL_NAME(lhs));
                            const char *namefvar = IDENTIFIER_POINTER(DECL_NAME(fsarg));
                            
                            if(!strcmp(namelhs, namefvar)) {
                                /* Found the statement with the cast */
                                         
                                /* The first operand of rhs is an addr_expr and
                                 * its first operand is the fndecl we are looking for.
                                 */
                                arg = TREE_OPERAND(TREE_OPERAND(rhs, 0), 0);
                                break;
                            }
                        }
                    }
                }
            }    
            else if(TREE_CODE(fsarg) == ADDR_EXPR &&  
                    TREE_CODE(TREE_OPERAND(fsarg, 0)) == FUNCTION_DECL) {
                arg = TREE_OPERAND(fsarg, 0); 
            } 
            else if(TREE_CODE(fsarg) == NOP_EXPR &&
                    TREE_CODE(TREE_OPERAND(fsarg, 0)) == ADDR_EXPR &&
                    TREE_CODE(TREE_OPERAND(TREE_OPERAND(fsarg, 0), 0)) == FUNCTION_DECL) {
                arg = TREE_OPERAND(TREE_OPERAND(fsarg, 0), 0); 
            }
            
            if(arg == NULL_TREE) {
                fprintf(stderr, "Found call to builtin function __function_size but could not process it.\n");
                gcc_unreachable();
            }
            

            {
                const char prefix[] = "__size_of_";
                const char *fname = IDENTIFIER_POINTER(DECL_ASSEMBLER_NAME(arg));
                char *label_name;
                tree result;
                tree decl;
                
                if(TARGET_NO_FUNCTION_SIZEOF)
                    warning0("__function_size will not work for functions built with -mno-function-sizeof.");            
                label_name = xmalloc(strlen(fname) + strlen(prefix) + 1);
                label_name = strncpy(label_name, prefix, strlen(prefix) + 1);
                label_name = strncat(label_name, fname, strlen(fname) + 1);
                
                /* We need to associate a VAR_DECL with SYMBOL_REF and make the tree
                 * public if the current function decl is public.
                 * This will allow maybe_globalize_next to know if the current symbol
                 * reference should be marked as global or not.
                 */
                decl = build_decl(VAR_DECL, get_identifier(label_name), unsigned_type_node);
                
                TREE_PUBLIC(decl) = TREE_PUBLIC(arg);
                DECL_EXTERNAL(decl) = DECL_EXTERNAL(arg);
                TREE_STATIC(decl) = TREE_STATIC(arg);
                
                mark_decl_referenced(arg);
                
                result = fold_convert(size_type_node,
                                      build_unary_op(ADDR_EXPR, decl, 0));
            
                return result;
            }
        }
        default:
            abort();
    }
}

static int xap_offset_from_letter(int code)
{
    switch(code)
    {
        case XAP_LS16OF32:
        case XAP_LS16OF32_ADDR:
            return 1;
        case XAP_WORD3:
            return 2;
        case XAP_WORD4:
            return 3;
        default:
            return 0;
    }
}

static int xap_is_address_letter(int code)
{
    switch(code)
    {
        case XAP_ADDR:
        case XAP_LS16OF32_ADDR:
        case XAP_MS16OF32_ADDR:
            return 1;
        default:
            return 0;
    }
}

static void xap_print_operand_failed(const char *msg, FILE *stream, rtx x, int code)
{
    print_inline_rtx(stream,x,0);
    fprintf(stderr,"xap_print_operand: %s\n", msg);
    fprintf(stderr,"failed on rtx: ");
    print_inline_rtx(stderr,x,15);
    fprintf(stderr,"\n");
    if(code) fprintf(stderr,"with letter %c\n",(char)code);
    abort();
}

static void xap_print_register(FILE *stream, rtx x, int code)
{
    if(REGNO(x) >= FIRST_PSEUDO_REGISTER)
        xap_print_operand_failed("Encountered a pseudo register",stream,x,code);

    if(code == XAP_ADDR
       && (TEST_HARD_REG_BIT(reg_class_contents[CHIP_REGS],REGNO(x))
           || REGNO(x) == RXH))
    {
        switch(REGNO(x))
        {
            case RAH: fprintf(stream,"@$XAP_AH"); break;
            case RAL: fprintf(stream,"@$XAP_AL"); break;
            case RXH: fprintf(stream,"@$XAP_UXH"); break;
            case RXL: fprintf(stream,"@$XAP_UXL"); break;
            case RSP: fprintf(stream,"@$XAP_UY"); break;
            case RFP: fprintf(stream,"@$XAP_UY"); break;
            default: abort();
        }
    }
    else if(xap_offset_from_letter(code)
            || (!TEST_HARD_REG_BIT(reg_class_contents[MEM_REGS], REGNO(x))
                && xap_is_address_letter(code)))
    {
        if(   REGNO(x)!=RAH
           && !TEST_HARD_REG_BIT(reg_class_contents[MEM_REGS],REGNO(x)))
        {
            xap_print_operand_failed("Offset code with invalid register",stream,x,code);
            return;
        }

        xap_print_register(stream,
                           gen_rtx_REG(QImode,REGNO(x)+xap_offset_from_letter(code)),
                           (xap_is_address_letter(code))?XAP_ADDR:0);
    }
    else
    {
        fprintf(stream,"%s",reg_names[REGNO(x)]);
    }

}

static void xap_print_memory(FILE *stream, rtx x, int code)
{
    rtx addr;

    if(GET_CODE(XEXP(x,0))==CONST)
        addr = XEXP(XEXP(x,0),0);
    else
        addr = XEXP(x,0);
   
    switch(GET_CODE(addr))
    {
        case SYMBOL_REF:
            fprintf(stream,"@");
            xap_print_operand(stream,addr,XAP_NO_DECORATION);
            if(xap_offset_from_letter(code))
                fprintf(stream,"+%d",xap_offset_from_letter(code));
            break;

        case PLUS:
            if(!CONSTANT_P(XEXP(addr,1)))
            {
                xap_print_operand_failed("Second operand of PLUS must be constant in address",stream,x,code);
                break;
            }

            if(REG_P(XEXP(addr, 0)) && REG_OK_FOR_BASE_P_STRICT(XEXP(addr, 0)))
            {
                fprintf(stream,"@(");

                xap_print_operand(
                            stream,
                            gen_rtx_PLUS(VOIDmode,
                                         XEXP(addr,1),
                                         GEN_INT(xap_offset_from_letter(code))),
                            XAP_NO_DECORATION
                                 );

                fprintf(stream,",");
                xap_print_operand(stream,XEXP(addr,0),0);
                fprintf(stream,")");

            }
            else if(GET_CODE(XEXP(addr,0))==SYMBOL_REF)
            {
                fprintf(stream,"@");

                xap_print_operand(
                         stream,
                         gen_rtx_PLUS(GET_MODE(addr),
                                        XEXP(addr,0),
                                        gen_rtx_PLUS(VOIDmode,
                                                     XEXP(addr,1),
                                                     GEN_INT(xap_offset_from_letter(code)))),
                         XAP_NO_DECORATION
                                 );

                
            }
            else
            {
                xap_print_operand_failed("Invalid first operand to PLUS in address",stream,x,code);
            }
            break;

        case REG:
            if(REG_OK_FOR_BASE_P_STRICT(addr))
            {
                fprintf(stream,"@(%d,",xap_offset_from_letter(code));
                xap_print_operand(stream,addr,0);
                fprintf(stream,")");
            }
            else
            {
                xap_print_operand_failed("Invalid register as address",stream,x,code);
            }
            break;

        case CONST_INT:
            fprintf(stream,"@");
            xap_print_operand(stream,addr,XAP_NO_DECORATION);
            break;

        default:
            xap_print_operand_failed("Invalid address",stream,x,code);
    }
}

void xap_print_operand(FILE *stream, rtx x, int code)
{
    switch(GET_CODE(x))
    {
        case REG:
            xap_print_register(stream,x,code);
            break;

        case LABEL_REF:
            if(code!=XAP_NO_DECORATION) fprintf(stream,"#");
            xap_print_operand(stream,XEXP(x,0),code);
            break;
        
        case CODE_LABEL:
            output_addr_const(stream,x);
            break;

        case MEM:
            xap_print_memory(stream,x,code);
            break;

        case CONST_INT:
            if(code==XAP_NO_DECORATION)
            {
                if(TARGET_AS_MODE)
                    fprintf(stream,"0x%04lx",INTVAL(x)&0xffff);
                else
                    fprintf(stream,"H'%04lx",INTVAL(x)&0xffff);
            }
            else
            {
                int val = INTVAL(x);
                if(code == XAP_MS16OF32_ADDR || code == XAP_MS16OF32)
                {
                    val >>= 16;
                }
                if(TARGET_AS_MODE)
                    fprintf(stream,"#0x%04x",val&0xffff);
                else
                    fprintf(stream,"#H'%04x",val&0xffff);
            }
            break;

        case CONST:
            xap_print_operand(stream,XEXP(x,0),code);
            break;

        case PLUS:
            if(code!=XAP_NO_DECORATION) fprintf(stream,"#");
            if(   GET_CODE(XEXP(x,0))==CONST_INT
               && GET_CODE(XEXP(x,1))==CONST_INT)
            {
                xap_print_operand(stream,
                                  GEN_INT(INTVAL(XEXP(x,0))+INTVAL(XEXP(x,1))),
                                  XAP_NO_DECORATION);
            }
            else
            {
                xap_print_operand(stream,XEXP(x,0),XAP_NO_DECORATION);
                if(GET_CODE(XEXP(x,1))==CONST_INT)
                    fprintf(stream,"%+hd",(short)INTVAL(XEXP(x,1)));
                else
                {
                    fprintf(stream,"+");
                    xap_print_operand(stream,XEXP(x,1),XAP_NO_DECORATION);
                }
            }
            break;

        case SYMBOL_REF:
            if(code!=XAP_NO_DECORATION) fprintf(stream,"#");
            xap_maybe_globalize_next_label(x);
            if(code == XAP_LS16OF32 || code == XAP_LS16OF32_ADDR)
            {
                fprintf(stream,"lwrd(");
                assemble_name(stream,XSTR(x,0));
                fprintf(stream,")");

            }
            else if(code == XAP_MS16OF32 || code == XAP_MS16OF32_ADDR)
            {
                fprintf(stream,"hwrd(");
                assemble_name(stream,XSTR(x,0));
                fprintf(stream,")");
            }
            else
            {
                assemble_name(stream,XSTR(x,0));
            }

            /* I don't think we *should* have to do this here, but there's
             * something broken in gcc which causes some things not to get
             * marked referenced otherwise. */
            if (SYMBOL_REF_DECL (x))
                mark_decl_referenced (SYMBOL_REF_DECL (x));

            if(xap_find_global(XSTR(x,0),XAP_GLOBAL_FIND))
                xap_add_linkinfo(XSTR(x,0),FALSE);
            
            break;
        
        default:
            xap_print_operand_failed("RTX unhandled",stream,x,code);
    }

}

void xap_print_operand_address(FILE *stream ATTRIBUTE_UNUSED, rtx x ATTRIBUTE_UNUSED)
{
    WRITEME
}

void xap_asm_output_skip(FILE *stream, int nbytes)
{
    if(TARGET_AS_MODE)
    {
        fprintf(stream,"\t.space\t%d\n",nbytes);
    }
    else
    {
        if(in_section == bss_section)
            fprintf(stream,"\tDS\t%d\n",nbytes);
        else
            while(nbytes--) fprintf(stream,"\tDC\tH'0000\n");
    }
}

void xap_asm_output_align(FILE *stream, int pow)
{
    if (TARGET_AS_MODE)
    {
        /* Allow alignment directives when writing to a debug section */
        fprintf(stream, "\t.p2align\t%i\n", pow);
    }
    else
    {
        /* Otherwise, nothing should be requiring more than word-alignment */
        gcc_assert(pow <= 1);
    }
}

void xap_expand_shift(rtx *operands, int code)
{
    rtx shift = gen_rtx_REG(QImode,(code==ASHIFT)?RAL:RAH);
    rtx clobber = gen_rtx_REG(QImode,(code==ASHIFT)?RAH:RAL);

    rtx body = gen_rtx_PARALLEL (VOIDmode, rtvec_alloc(2));
    XVECEXP(body,0,0) = gen_rtx_SET(QImode,
                                    shift,
                                    gen_rtx_fmt_ee(code,
                                                   QImode,
                                                   shift,
                                                   operands[2]));
    XVECEXP(body,0,1) = gen_rtx_CLOBBER(QImode,clobber);
    emit_insn(gen_rtx_SET(QImode,shift,operands[1]));
    emit_insn(body);
    emit_insn(gen_rtx_SET(QImode,operands[0],shift));
}

bool xap_movhi_via_reg(rtx *operands)
{
    const bool op0_mem_or_memreg =
        MEM_P(operands[0])
        || (REG_P(operands[0]) 
            && TEST_HARD_REG_BIT(reg_class_contents[MEM_REGS], REGNO(operands[0])));

    const bool op1_mem_or_memreg_or_const = 
        MEM_P(operands[1])
        || (REG_P(operands[1]) 
            && TEST_HARD_REG_BIT(reg_class_contents[MEM_REGS], REGNO(operands[1])))
        || CONSTANT_P(operands[1]);

    const bool via_reg = op0_mem_or_memreg && op1_mem_or_memreg_or_const;
   
    return via_reg;
}

#define FRAME_REG_P(x) (   GET_CODE(x) == REG \
                        && (   REGNO(x) == RFP \
                            || REGNO(x) == RSP \
                            || REGNO(x) == RAP ))

void xap_asm_output_addr_diff_elt(FILE *stream,
                                  rtx body ATTRIBUTE_UNUSED,
                                  int value,
                                  int rel)
{
    if(!TARGET_CONST_JUMP_TABLES)
    {
        fprintf(stream,"\tbra2\t%sL%d\n",XAP_LABEL_PREFIX,value);
    }
    else if(TARGET_AS_MODE)
    {
        fprintf(stream,"\t.word\t%sL%d-%sJTBASE%d\n",
                XAP_LABEL_PREFIX,value,XAP_LABEL_PREFIX,rel);
    }
    else
    {
        fprintf(stream,"\tDC\t%sL%d-%sJTBASE%d\n",
                XAP_LABEL_PREFIX,value,XAP_LABEL_PREFIX,rel);
    }
}

void xap_asm_output_case_label(FILE *stream,
                               const char* prefix ATTRIBUTE_UNUSED,
                               int num,
                               rtx table ATTRIBUTE_UNUSED)
{
    if(TARGET_CONST_JUMP_TABLES)
        switch_to_section(targetm.asm_out.function_rodata_section(current_function_decl));
    fprintf(stream,"%sL%d:\n",XAP_LABEL_PREFIX,num);
}

void xap_asm_output_case_end(FILE *stream,
                             int num,
                             rtx table ATTRIBUTE_UNUSED)
{
    if(TARGET_CONST_JUMP_TABLES)
    {
        switch_to_section(current_function_section());
        fprintf(stream,"%sJTBASE%d:\n",XAP_LABEL_PREFIX,num);
    }
}

/* Line number symbols must all be unique. We keep count of how many times
 * we've output a symbol for each line to use as a uniquificationaliser. */
static unsigned int xap_line_uniquifier(unsigned int line)
{
    static unsigned int *count = 0;
    static size_t n_count = 0;

    /* Maintain an array with count[line] == occurrences of line.
     * Double the size of the array when we run out of space.
     */
    if(n_count < line + 1)
    {
        unsigned int prev_n_count = n_count;
        n_count = (2 * n_count > line + 1) ? 2 * n_count
                                           : line + 1;

        count = (unsigned int*)xrealloc( count, sizeof(count[0]) * n_count );

        memset(count + prev_n_count,
               0,
               sizeof(count[0]) * (n_count - prev_n_count));

        gcc_assert(count[prev_n_count]==0);
        gcc_assert(count[n_count-1]==0);
    }

    return count[line]++;
}

static char nibble(int c)
{ return "0123456789abcdef"[c & 15]; }

static void convert_to_hex(const char *s, char *t)
{
    while(*s)
    {
        *t++ = nibble(*s >> 4);
        *t++ = nibble(*s);
        ++s;
    }
    *t = '\0';
}

static void xap_dbx_output_source_line(unsigned int line, const char *file)
{
    char *path;

    gcc_assert(xap_module_name);
    gcc_assert(file);

    if(IS_ABSOLUTE_PATH(file) || !TARGET_ABSOLUTE)
        path = xstrdup(file);
    else
    {
        const char *dir = get_src_pwd();
        path = (char*)xmalloc(strlen(dir) + strlen(file) + 3);
        path[0] = '\0';
        strcat(path,dir);
        strcat(path,"/");
        strcat(path,file);
    }

    if(   xap_path_find
       && strncmp(xap_path_find,path,strlen(xap_path_find)) == 0)
    {
        size_t xap_path_find_len = strlen(xap_path_find);
        char *new_path = (char*)xmalloc(  strlen(xap_path_replacement)
                                        + ( strlen(path) - xap_path_find_len )
                                        + 1);
        strcpy(new_path,xap_path_replacement);
        strcat(new_path,path + xap_path_find_len);
        free(path);
        path = new_path;
    }
    
    if(TARGET_HEX_PATHS)
    {
        char *inhex = xmalloc(strlen(path) * 2 + 1);

        convert_to_hex(path,inhex);
        free(path);
        path = inhex;
    }

    fprintf(asm_out_file,
            "^%s.'%s'.?%u.%u:\n",
            xap_module_name,
            path,
            line,
            xap_line_uniquifier(line));

    free(path);
}

unsigned int xap_pmode(const char *filename, int line)
{
    fprintf(stderr,"xap_pmode: %s +%d\n",filename,line);
    return QImode;
}

const char *xap_mulqihi3(rtx *operands, int smul)
{
    if      (REGNO(operands[1])==RAH)
        return smul ? "ld\tAL,%f1\n\tsmult\t%f2"
                    : "ld\tAL,%f1\n\tumult\t%f2";
    else if (REGNO(operands[1])==RAL)
        return smul ? "smult\t%f2"
                    : "umult\t%f2";
    else
    {
        /* Shouldn't happen - constraint should only allow AH or AL */
        fprintf(stderr,"Failed generating assembler for umulqihi3\n");
        abort();
    }
}

char *xap_asm_format_private_name(char * out, const char * name, unsigned int count)
{
    sprintf(out,"%s%s%u%s",name,XAP_LABEL_PREFIX,count,XAP_LABEL_PREFIX);
    return out;
}

void xap_asm_generate_internal_label(char *string, const char *prefix, unsigned num)
{
    sprintf(string, "*%s%s%lu", XAP_LABEL_PREFIX, prefix, (unsigned long) num);
}

void xap_asm_output_def(FILE *stream, const char *name, const char *value)
{
    if(TARGET_AS_MODE)
    {
        fprintf(stream,"\t.equ\t");
        assemble_name(stream,name);
        fprintf(stream,",");
        assemble_name(stream,value);
        putc('\n',stream);
    }
    else
    {
        assemble_name(stream,name);
        fprintf(stream,"\tEQU\t");
        assemble_name(stream,value);
        putc('\n',stream);
    }
    xap_add_linkinfo(name,TRUE);
}

typedef struct xap_record_type
{
    struct xap_record_type *next;
    char *tag;
    const_tree type;
} xap_record_type;

static const char *xap_output_record_type(FILE *stream, const_tree type)
{
    tree t;
    const_tree name;
    tree *fields = 0;
    char *tag;
    unsigned n_fields = int_size_in_bytes(type);
    unsigned i;
    xap_record_type *p;
    static unsigned next_anon_member = 1;
    static unsigned next_anon_struc = 1;
    static xap_record_type *record_types = 0;
    xap_record_type *old_head;

    gcc_assert(type);
    gcc_assert(TYPE_MAIN_VARIANT(type));
    type = TYPE_MAIN_VARIANT(type);

    name = TYPE_NAME (type);
    if (name && TREE_CODE (name) == TYPE_DECL)
        name = DECL_NAME (name);

    if(name)
    {
        tag = xmalloc(strlen(IDENTIFIER_POINTER(name))+2);
        gcc_assert(IDENTIFIER_POINTER(name));
        (void) strcpy(tag,IDENTIFIER_POINTER(name));
        if (xap_reserved_name(tag)) strcat(tag,"?");
    }
    else
    {
        char anon[] = "?Anon";
        size_t anon_sz = sizeof(anon) + 11;
        tag = xmalloc(anon_sz);
        (void) snprintf(tag,anon_sz,"%s%d",anon,next_anon_struc++);
    }

    /* Don't repeat ourselves */
    for(p=record_types;p;p=p->next)
        if(!strcmp(tag,p->tag))
        {
            gcc_assert(p->type == type);
            free(tag);
            return p->tag;
        }

    fields = (tree*)alloca(n_fields*sizeof(fields[0]));
    (void)memset(fields,0,n_fields*sizeof(fields[0]));

    for (t = TYPE_FIELDS (type); t; t = TREE_CHAIN (t))
    {
        unsigned bitpos;
        unsigned sz_bits;

        if (t == error_mark_node || TREE_TYPE (t) == error_mark_node)
            return 0;

        /* Output definitions for any embedded structures */
        if(TREE_CODE(TREE_TYPE(t))==RECORD_TYPE)
            xap_output_record_type(stream,TREE_TYPE(t));
        
        sz_bits = tree_low_cst(DECL_SIZE(t),1);
        bitpos = int_bit_position(t);
        
        gcc_assert( bitpos/16 < n_fields || !sz_bits );
        gcc_assert( bitpos/16 + sz_bits/16 <= n_fields || !sz_bits );
        if(bitpos % 16 == 0 && sz_bits>=16) fields[bitpos/16] = t;
    }
    
    /* Start outputting this structure def */
    fprintf(stream,"\n%s\tSTRUC\n",tag);

    for(i=0;i<n_fields;)
    {
        int padding_words = 0;

        /* Suck adjacent bitfields and spacing into one anonymous member */
        while(i<n_fields && !fields[i]) { padding_words++; i++; }

        if(padding_words)
            fprintf(stream,"?mem%u\tds\t%u\n", next_anon_member++,
                                                    padding_words);
        else
        {
            unsigned sz_words = tree_low_cst(DECL_SIZE_UNIT(fields[i]),1);
            const char *member_nm = IDENTIFIER_POINTER(DECL_NAME(fields[i]));
            fprintf(stream,"%s",member_nm);
            if (xap_reserved_name(member_nm)) fprintf(stream,"?");
            fprintf(stream,"\tds\t%u\n",sz_words);
            i += sz_words;
            gcc_assert( i <= n_fields );
        }
    }

    fprintf(stream,"\tENDS\n\n");

    /* Add type to a list so we don't repeat ourselves ourselves */
    old_head = record_types;
    record_types = xmalloc(sizeof(*record_types));
    record_types->next = old_head;
    record_types->type = type;
    record_types->tag = tag;

    return record_types->tag;
}

bool mem_of_reg_p(rtx x)
{
    rtx addr;

    if(!MEM_P(x))
        return false;
    
    addr = XEXP(x, 0);

    return REG_P(addr)
           || (GET_CODE(addr) == PLUS
               && REG_P(XEXP(addr, 0))
               && CONSTANT_P(XEXP(addr, 1))); /* Why do we care about the constant? */
}

const char *xap_text_section_asm_op(void)
{
    if(TARGET_AS_MODE)
        return "\t.text";
    else
        return "\t.CODE";
}

const char *xap_data_section_asm_op(void)
{
    if(TARGET_AS_MODE)
        return "\t.data";
    else
        return "\t.SEG INIT";
}

const char *xap_readonly_data_section_asm_op(void)
{
    if(TARGET_AS_MODE)
        return "\t.rodata";
    else
        return "\t.SEG CONST";
}

void xap_bss_section_asm_op(const void *ignored ATTRIBUTE_UNUSED)
{
    if(TARGET_AS_MODE)
        output_section_asm_op("\t.bss");
    else
        output_section_asm_op("\t.SEG VAR");
}


/*
 * Generates code to call a function either through
 * a direct call or a function pointer considering the existence 
 * of a MPU. B-79529
 *
 * fnaddr is a rtx that contains the function address
 * scratch1/scratch2 are different rtxs that contain a free stack operand (RY1 / RY2)
 */
const char *xap_mpu_call (rtx *operands, rtx fnaddr, rtx scratch1, rtx scratch2)
{
    gcc_assert(!rtx_equal_p(fnaddr, scratch1));
    gcc_assert(!rtx_equal_p(fnaddr, scratch2));
    gcc_assert(!rtx_equal_p(scratch1, scratch2));
        
    /* Now we put these values in default places */
    operands[1] = fnaddr;
    operands[3] = scratch1;
    operands[4] = scratch2;
    
    /* First we handle the simple case of direct calls.
     * A direct calls is made through a SYMBOL_REF. 
     * We don't need to deal with these so we just output a bsr.
     */
    
    if(GET_CODE(operands[1]) == SYMBOL_REF)
        return "bsr\t%u1";
    
    /* Now, the trickier part:
     * For all other cases we assume it is a function pointer call.
     * The function pointer can come on a register or in the stack.
     * The code that is going to be generated looks like this, where
     * S is the source of the address of the function ptr:
     *
     * bsr  <label>
     * <label>:
     * add  X, LSW(S)
     * st   X, <FIXEDREG1>
     * ld   X, XAP_UXH
     * addc X, MSW(S)
     * st   X, <FIXEDREG2>
     * ld   XH, <FIXEDREG2>
     * ld   X, <FIXEDREG1>
     * bsr  -<label>, X
     *
     * All registers are defined as call clobbered so we don't need to
     * worry about clobbering them. Choice of FIXEDREG1/2 is made through GCC
     * constraints (match_scratch) in the MD file.
     */

    
    /* We need to generate a label for the bsr trick */
    operands[5] = gen_rtx_REG(QImode, RXH);
    operands[6] = gen_rtx_REG(QImode, RXL);
    operands[7] = gen_label_rtx();
        
    output_asm_insn("bsr\t%u7\n"
                    "%u7:\n\t"
                    "add\t%6,%F1\n\t"
                    "st\t%6,%f3\n\t" 
                    "ld\t%6,%f5\n\t"
                    "addc\t%6,%G1\n\t"
                    "st\t%6,%f4\n\t" 
                    "ld\t%5,%f4\n\t" 
                    "ld\t%6,%f3\n\t" 
                    "bsr\t-%u7,%6"
                    , operands);

    return "";
}

/* Output insn cost for next insn.  */
void
final_prescan_insn (rtx insn, rtx *operand ATTRIBUTE_UNUSED,
                    int num_operands ATTRIBUTE_UNUSED)
{   
    if (TARGET_NOISY)
    {
        fprintf (asm_out_file, ";; -mnoisy: cost = %d.\n",
                 rtx_cost (PATTERN (insn), INSN));
    }    
}

/* Any mode is tieable with itself.
 * Any mode is tieable with a larger mode.
 */
int
xap_modes_tieable(enum machine_mode mode1, enum machine_mode mode2)
{
    int tieable_p = GET_MODE_SIZE(mode1) <= GET_MODE_SIZE(mode2); 
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== MODES_TIEABLE_P[");
        xap_current_pass(stderr);
        fprintf(stderr, "] %s, %s => %d\n",
                GET_MODE_NAME(mode1),
                GET_MODE_NAME(mode2),
                tieable_p);
    }
    
    return tieable_p;
}

/* This hooks implementation only adds debug information.
 * The returned value is still the default one.
 */
bool 
xap_commutative_p(rtx x, int outer_code)
{
    bool commutative_p = COMMUTATIVE_P(x);
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== COMMUTATIVE_P[");
        xap_current_pass(stderr);
        fprintf(stderr, "] %s ", rtx_name[outer_code]);
        print_inline_rtx(stderr, x, 0);
        fprintf(stderr, " => %d\n", commutative_p);
    }

    return commutative_p;
}

/* Return TRUE if int I is a valid immediate XAP constant */
static bool
const_ok_for_xap(HOST_WIDE_INT i)
{
    /* For machines with >16 bit HOST_WIDE_INT, the bits above bit 15
     * must be all zero, or all one */
    if((i & ~(unsigned HOST_WIDE_INT) 0xffff) != 0
       && ((i & ~(unsigned HOST_WIDE_INT) 0xffff)
           != ((~(unsigned HOST_WIDE_INT) 0)
               & ~(unsigned HOST_WIDE_INT) 0xffff)))
        return FALSE;
    
    return TRUE;
}

enum rtx_code
xap_canonicalize_comparison(enum rtx_code code, rtx *op0, rtx *op1)
{
    enum rtx_code newcode = code;
    
    if(TARGET_NOISY)
    {
        fprintf(stderr, "== CANONICALIZE_COMPARISON[");
        xap_current_pass(stderr);
        fprintf(stderr, "] (%s ", rtx_name[code]);
        print_inline_rtx(stderr, *op0, 0);
        fprintf(stderr, " ");
        print_inline_rtx(stderr, *op1, 0);
        fprintf(stderr, ") => ");
    }
        
    if(TARGET_NOISY)
    {
        fprintf(stderr, "(%s ", rtx_name[code]);
        print_inline_rtx(stderr, *op0, 0);
        fprintf(stderr, " ");
        print_inline_rtx(stderr, *op1, 0);
        fprintf(stderr, ")\n");
    }

    return newcode;
}

void
xap_emit_conditional_branch(enum rtx_code code, rtx branch_label)
{
    enum rtx_code cmp_code;
    int cmp_p = xap_compare.cmp;
    rtx op0 = xap_compare.op0, op1 = cmp_p ? xap_compare.op1 : 0;
    enum machine_mode cmp_mode = GET_MODE(op0);
    unsigned HOST_WIDE_INT maxval = (((unsigned HOST_WIDE_INT) 1) << (GET_MODE_BITSIZE(cmp_mode) - 1)) -1;
                                                  
#define EMIT_TST(OP0)                                   \
    emit_insn(gen_rtx_SET(VOIDmode, cc0_rtx, OP0))
#define EMIT_CMP(MODE, OP0, OP1)                                        \
    emit_insn(gen_rtx_SET(VOIDmode,                                     \
                          cc0_rtx, gen_rtx_COMPARE(VOIDmode, OP0, OP1)))
#define EMIT_JMP(CODE, MODE, LABEL)                                     \
    emit_jump_insn(gen_rtx_SET(VOIDmode,                                \
                               pc_rtx,                                  \
                               gen_rtx_IF_THEN_ELSE(VOIDmode,           \
                                                    gen_rtx_fmt_ee(CODE, VOIDmode, cc0_rtx, const0_rtx), \
                                                    LABEL, pc_rtx)))
    

    /* Emit compare or test */
    switch(code)
    {
        case GTU:
        {
            /* What we will do is:
             * substitute all comparisons of the form 
             * x > I ; (where I is integer and I+1 is representable in XAP)
             * by
             * x >= I + 1 ;
             */

            if(GET_CODE(op1) == CONST_INT
               && INTVAL(op1) != maxval
               && const_ok_for_xap(INTVAL(op1) + 1))
            {
                xap_compare.op1 = GEN_INT(INTVAL(op1) + 1);
                xap_emit_conditional_branch(GEU, branch_label);
                return;
            }
            else 
            {
                rtx code_label = gen_label_rtx();
                rtx code_label_ref = gen_rtx_LABEL_REF(VOIDmode, code_label);

                cmp_code = LEU;
                
                if(cmp_p)
                    EMIT_CMP(cmp_mode, op0, op1);
                else
                    EMIT_TST(op0);
                
                /* Emit branch */
                EMIT_JMP(cmp_code, cmp_mode, code_label_ref);
                
                emit_jump(branch_label);
                emit_barrier();
                emit_label(code_label);
            }
            
            break;
        }
        
        default:
        {
            rtx branch_label_ref = gen_rtx_LABEL_REF(VOIDmode, branch_label);
            cmp_code = code;
            
            if(cmp_p)
                EMIT_CMP(cmp_mode, op0, op1);
            else
                EMIT_TST(op0);

            /* Emit branch */
            EMIT_JMP(cmp_code, cmp_mode, branch_label_ref);
        }
    }
    
    /* Clean xap_compare */
    memset(&xap_compare, 0, sizeof(xap_compare));    

#undef EMIT_CMP
#undef EMIT_TST
#undef EMIT_JMP
}

void
xap_emit_divmodqi(rtx operands[], int sign)
{
    rtx regAH_HI = gen_rtx_REG(HImode, RAH);
    rtx regAL_QI = gen_rtx_REG(QImode, RAL);
    rtx regAH_QI = gen_rtx_REG(QImode, RAH);
    
    enum rtx_code extend = sign ? SIGN_EXTEND : ZERO_EXTEND;
    enum rtx_code div = sign ? DIV : UDIV;
    enum rtx_code mod = sign ? MOD : UMOD;
    
    rtx body = gen_rtx_PARALLEL(VOIDmode, rtvec_alloc(2));
       
    rtx divisor;
    if(GET_CODE(operands[2]) == CONST_INT)
        divisor = operands[2];
    else
        divisor = gen_rtx_fmt_e(extend, HImode, operands[2]);
    

    emit_insn(gen_rtx_SET(VOIDmode, 
                          regAH_HI,
                          gen_rtx_fmt_e(extend, HImode, operands[1])));
    
    XVECEXP(body, 0, 0) = gen_rtx_SET(VOIDmode,  
                                      regAL_QI,
                                      gen_rtx_TRUNCATE(QImode,
                                                       gen_rtx_fmt_ee(div, HImode, regAH_HI, divisor)));
    XVECEXP(body, 0, 1) = gen_rtx_SET(VOIDmode,
                                      regAH_QI,
                                      gen_rtx_TRUNCATE(QImode,
                                                       gen_rtx_fmt_ee(mod, HImode, regAH_HI, divisor)));
    emit_insn(body);
    
    emit_insn(gen_rtx_SET(VOIDmode, operands[0], regAL_QI));
    emit_insn(gen_rtx_SET(VOIDmode, operands[3], regAH_QI));
        
}

void
xap_expand_HIoperation(enum rtx_code op, rtx operands[])
{
    rtx regAH_HI = gen_rtx_REG(HImode, RAH);
    
    switch(op)
    {
        case PLUS:
        {
            /* Move operand1 to AH/AL 
               Expand to an addhi */
            emit_insn(gen_movhi(regAH_HI, operands[1]));
            emit_insn(gen_rtx_SET(VOIDmode,
                                  regAH_HI,
                                  gen_rtx_PLUS(HImode, regAH_HI, operands[2])));
            emit_insn(gen_movhi(operands[0], regAH_HI));
            break;
        }
        case ASHIFT:
        {
            emit_insn(gen_movhi(regAH_HI, operands[1]));
            emit_insn(gen_rtx_SET(VOIDmode,
                                  regAH_HI,
                                  gen_rtx_ASHIFT(HImode, regAH_HI, operands[2])));
            emit_insn(gen_movhi(operands[0], regAH_HI));
            break;
        }
        default:
            gcc_unreachable();
    }
    
}

/* B-164290: Helpers for generating low and high parts of a HIMODE 
 * operand for XAP. Need to handle CONST_INT and SYMBOL_REF directly
 * since the middle end seemingly can't accept these in gen_lowpart()
 * or gen_highpart().
 */
static rtx
xap_gen_lowpart(rtx operand)
{
    unsigned HOST_WIDE_INT mask = 0xffff;

    if (GET_CODE(operand) == CONST_INT)
        return gen_int_mode(INTVAL(operand) & mask, QImode);
    else if (GET_CODE(operand) == SYMBOL_REF)
        return gen_rtx_SUBREG(QImode, operand, 1);
    else
        return gen_lowpart(QImode, operand);
}

static rtx
xap_gen_highpart(rtx operand)
{
    if (GET_CODE(operand) == CONST_INT)
        return gen_int_mode(INTVAL(operand) >> 16, QImode);
    else if (GET_CODE(operand) == SYMBOL_REF)
        return gen_rtx_SUBREG(QImode, operand, 0);
    else
        return gen_highpart(QImode, operand);
}

void
xap_expand_bitwise_HIoperation(enum rtx_code op, rtx operands[])
{
    rtx regAL_QI = gen_rtx_REG(QImode, RAL);
    rtx regAH_QI = gen_rtx_REG(QImode, RAH);
    rtx lowpart_op1, highpart_op1, lowpart_op2, highpart_op2;

    lowpart_op1 = xap_gen_lowpart(operands[1]);
    highpart_op1 = xap_gen_highpart(operands[1]);
    
    lowpart_op2 = xap_gen_lowpart(operands[2]);
    highpart_op2 = xap_gen_highpart(operands[2]);

    emit_insn(gen_movqi(regAL_QI, lowpart_op1));
    emit_insn(gen_movqi(regAH_QI, highpart_op1));

    switch(op)
    {
        case IOR:
        {
            emit_insn(gen_iorqi3(regAL_QI, regAL_QI, lowpart_op2));
            emit_insn(gen_iorqi3(regAH_QI, regAH_QI, highpart_op2));
            
            break;
        }
        case AND:
        {
            emit_insn(gen_andqi3(regAL_QI, regAL_QI, lowpart_op2));
            emit_insn(gen_andqi3(regAH_QI, regAH_QI, highpart_op2));

            break;
        }
        case XOR:
        {
            emit_insn(gen_xorqi3(regAL_QI, regAL_QI, lowpart_op2));
            emit_insn(gen_xorqi3(regAH_QI, regAH_QI, highpart_op2));

            break;
        }
        default:
            gcc_unreachable();
    }

    emit_insn(gen_movqi(gen_lowpart(QImode, operands[0]), regAL_QI));
    emit_insn(gen_movqi(gen_highpart(QImode, operands[0]), regAH_QI));
}

