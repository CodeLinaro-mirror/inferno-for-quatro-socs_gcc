/*
   xap-protos.h
  
   Prototypes for functions in xap.c.
   Contributed by CSR plc.
   
   Copyright (c) ????-2010, The Linux Foundation.
   Portions Copyright (C) 2010 Cambridge Consultants Ltd

This file is part of GCC.

GCC is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 3, or (at your option) any later
version.

GCC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with GCC; see the file COPYING3.  If not see
<http://www.gnu.org/licenses/>
 */


void xap_debug_expand(rtx *operands, unsigned int n_operands, const char *name);
enum reg_class xap_secondary_reload_class(enum reg_class, int mode, rtx x);
rtx xap_return_addr_rtx(int count, rtx frameaddr);
HOST_WIDE_INT xap_initial_elimination_offset(int fromreg, int toreg);
rtx xap_function_arg(CUMULATIVE_ARGS cum, int mode, tree type, int named);
HOST_WIDE_INT xap_arg_size(int mode, const_tree type);
rtx xap_libcall_value(int mode);
bool xap_legitimate_address(int mode,
                            rtx x,
                            enum xap_reg_ok strictness);
void xap_notice_update_cc(rtx exp, rtx insn);
void xap_asm_output_ascii(FILE *file, const char *ptr, unsigned int len);
void xap_asm_output_aligned_decl_common(FILE *stream,
                                        const_tree decl,
                                        const char *name,
                                        unsigned int size,
                                        unsigned int alignment);
void xap_print_operand(FILE *stream, rtx x, int code);
void xap_print_operand_address(FILE *stream, rtx x);
void xap_asm_output_skip(FILE *stream, int nbytes);
void xap_asm_output_align(FILE *stream, int pow);
void xap_asm_output_labelref(FILE *stream, const char *name);
void xap_asm_declare_object_name(FILE *stream, const char *name, tree decl);
void xap_asm_declare_function_size(FILE *stream, const char *name, tree decl);
void xap_asm_output_size_directive(FILE *stream, const char *name, int size);
void xap_expand_shift(rtx *operands, int code);
bool xap_movhi_via_reg(rtx *operands);
bool xap_extra_constraint(rtx value, char letter);
void xap_asm_output_addr_diff_elt(FILE *stream, rtx body, int value, int rel);
void xap_asm_output_case_label(FILE *stream, const char* prefix, int num, rtx table);
void xap_asm_output_case_end(FILE *stream, int num, rtx table);
unsigned int xap_pmode(const char *filename, int line);
const char *xap_mulqihi3(rtx *operands, int smul);
char *xap_asm_format_private_name(char * out, const char * name, unsigned int count);
void xap_asm_generate_internal_label(char *string, const char *prefix, unsigned num);
const char *xap_text_section_asm_op(void);
const char *xap_data_section_asm_op(void);
const char *xap_readonly_data_section_asm_op(void);
void xap_bss_section_asm_op(const void *ignored);
void xap_asm_output_wchars(FILE *file, const unsigned short *ptr, unsigned int len);
void xap_asm_output_def(FILE *stream, const char *name, const char *value);
void xap_override_options(void);
int xap_leaf_function_optim(HOST_WIDE_INT size);
HOST_WIDE_INT xap_total_frame_size(HOST_WIDE_INT local);
void xap_mark_frame_related(rtx insn);
void xap_expand_epilogue(int sibcall_p);
const char *xap_mpu_call(rtx *operands, rtx fnaddr, rtx scratch1, rtx scratch2);

void xap_asm_output_type_directive(FILE *stream, const char *name, const char *type);
void xap_asm_finish_declare_object(FILE *stream, tree decl, int top_level, int at_end);
void xap_asm_declare_function_size(FILE *stream, const char *name, tree decl);

bool mem_of_reg_p(rtx x);

int xap_register_move_cost(enum machine_mode mode, int from, int to);
int xap_memory_move_cost(enum machine_mode mode, int rclass, bool in);
int xap_branch_cost(void);
int xap_modes_tieable(enum machine_mode mode1, enum machine_mode mode2);

void xap_asm_declare_function_name(FILE *stream, const char *name, tree decl);
void final_prescan_insn (rtx insn, rtx *operand, int num_operands);

#ifdef RTX_CODE
enum rtx_code xap_canonicalize_comparison(enum rtx_code code, rtx *op0, rtx *op1);
void xap_emit_conditional_branch(enum rtx_code code, rtx branch_label);
void xap_expand_HIoperation(enum rtx_code op, rtx operands[]);
void xap_expand_bitwise_HIoperation(enum rtx_code op, rtx operands[]);
#endif

void xap_emit_divmodqi(rtx operands[], int sign);
